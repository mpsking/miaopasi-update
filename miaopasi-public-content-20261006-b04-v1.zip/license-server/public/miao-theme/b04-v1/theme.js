/* B04: presentation-only motion and in-page navigation. Order submission stays in portal-ui.mjs. */
(() => {
  'use strict';
  if (!document.body.classList.contains('b04-page')) return;
  const $ = selector => document.querySelector(selector);
  const canvas = $('[data-b04-stars]');
  const ctx = canvas && canvas.getContext('2d', { alpha: true });
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  const toggle = $('[data-b04-motion-toggle]');
  const reduce = $('[data-b04-reduce-motion]');
  const status = $('[data-b04-motion-status]');
  const tail = $('[data-b04-tail]');
  const tailGlow = $('[data-b04-tail-glow]');
  const state = { t: 0, frames: 0, paused: false, reduced: media.matches, active: false, stars: [], w: 0, h: 0, mobile: false, totalDrawMs: 0, raf: 0, last: 0, drawLast: 0 };
  let seed = 8304;
  const random = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const reduced = () => state.reduced || media.matches;
  const active = () => !!ctx && !state.paused && !reduced() && !document.hidden;

  function draw() {
    if (!ctx) return;
    const start = performance.now(), t = state.t, w = state.w, h = state.h;
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < 3; i++) {
      const x = w * (.16 + i * .34) + Math.sin(t * .025 + i * 2) * w * .04;
      const y = h * (.15 + i * .17) + Math.cos(t * .03 + i) * h * .03;
      const glow = ctx.createRadialGradient(x, y, 0, x, y, w * (state.mobile ? .3 : .22));
      glow.addColorStop(0, i === 1 ? 'rgba(137,69,187,.075)' : 'rgba(72,60,169,.065)');
      glow.addColorStop(1, 'rgba(38,18,62,0)');
      ctx.fillStyle = glow; ctx.fillRect(0, 0, w, h);
    }
    for (const star of state.stars) {
      const x = (star.x + Math.sin(t * star.speed + star.phase) * star.drift + w) % w;
      const y = star.y + Math.cos(t * star.speed * .7 + star.phase) * star.drift * .45;
      ctx.globalAlpha = .2 + (Math.sin(t * star.pulse + star.phase) + 1) * .35;
      ctx.fillStyle = star.color; ctx.beginPath(); ctx.arc(x, y, star.r, 0, Math.PI * 2); ctx.fill();
      if (star.r > 1.2) {
        ctx.strokeStyle = '#d9bdff'; ctx.lineWidth = .55; ctx.beginPath();
        ctx.moveTo(x - star.r * 3, y); ctx.lineTo(x + star.r * 3, y);
        ctx.moveTo(x, y - star.r * 3); ctx.lineTo(x, y + star.r * 3); ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
    const meteorPhase = (t + 2) % 13;
    if (meteorPhase < 1.4) {
      const f = meteorPhase / 1.4, x = w * (.22 + f * .5), y = h * (.03 + f * .18);
      const glow = ctx.createLinearGradient(x - 130, y - 50, x, y);
      glow.addColorStop(0, 'rgba(180,125,255,0)');
      glow.addColorStop(1, 'rgba(236,216,255,' + (Math.sin(f * Math.PI) * .7) + ')');
      ctx.strokeStyle = glow; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(x - 130, y - 50); ctx.lineTo(x, y); ctx.stroke();
    }
    const a = Math.sin(t * 1.35) * 12, b = Math.cos(t * .95) * 7;
    const path = 'M72 124 C108 ' + (132 + a * .25).toFixed(2) + ' ' + (145 + a).toFixed(2) + ' ' + (126 + b).toFixed(2) + ' ' + (151 + a).toFixed(2) + ' ' + (101 + b).toFixed(2) + ' C' + (157 + a).toFixed(2) + ' ' + (78 + b).toFixed(2) + ' ' + (130 + a * .6).toFixed(2) + ' ' + (73 + b * .5).toFixed(2) + ' ' + (131 + a * .4).toFixed(2) + ' ' + (94 + b * .5).toFixed(2);
    tail?.setAttribute('d', path); tailGlow?.setAttribute('d', path);
    state.totalDrawMs += performance.now() - start;
  }

  function tick(now) {
    state.raf = 0;
    if (!active()) { state.last = 0; return; }
    const interval = 1000 / (state.mobile ? 24 : 30);
    if (!state.drawLast || now - state.drawLast >= interval - 1) {
      state.t += state.last ? Math.min((now - state.last) / 1000, .1) : 0;
      state.last = now; state.drawLast = now; state.frames++; draw();
    }
    state.raf = requestAnimationFrame(tick);
  }

  function sync() {
    state.active = active();
    document.body.classList.toggle('b04-motion-paused', !state.active);
    document.body.classList.toggle('b04-motion-reduced', reduced());
    if (reduce) reduce.checked = reduced();
    if (toggle) {
      toggle.setAttribute('aria-pressed', String(state.paused));
      toggle.textContent = state.paused ? '▶ 继续动效' : 'Ⅱ 暂停动效';
    }
    if (status) status.innerHTML = '<i></i>' + (reduced() ? '静态模式' : state.paused ? '动效已暂停' : document.hidden ? '后台休眠' : !ctx ? '静态模式' : '动态已开启');
    if (state.active && !state.raf) { state.last = 0; state.drawLast = 0; state.raf = requestAnimationFrame(tick); }
    if (!state.active && state.raf) { cancelAnimationFrame(state.raf); state.raf = 0; state.last = 0; }
  }

  function resize() {
    if (!ctx) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    state.w = rect.width; state.h = rect.height; state.mobile = innerWidth < 800;
    const dpr = Math.min(devicePixelRatio || 1, state.mobile ? 1 : 1.25);
    canvas.width = Math.ceil(state.w * dpr); canvas.height = Math.ceil(state.h * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    state.stars = Array.from({ length: state.mobile ? 70 : 150 }, () => ({ x: random() * state.w, y: random() * Math.min(state.h, innerHeight * 1.3), r: .35 + random() * 1.3, phase: random() * 6.28, speed: .1 + random() * .12, pulse: .65 + random() * 1.5, drift: 3 + random() * 7, color: random() > .4 ? '#c7b2f7' : '#e8d9ff' }));
    draw();
  }

  toggle?.addEventListener('click', () => { state.paused = !state.paused; sync(); });
  reduce?.addEventListener('change', event => { state.reduced = event.target.checked; sync(); });
  media.addEventListener('change', event => { state.reduced = event.matches; sync(); });
  document.addEventListener('visibilitychange', sync);
  let resizeTimer;
  addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(resize, 120); });

  let toastTimer;
  function toast(message) {
    const element = $('[data-b04-toast]'); if (!element) return;
    element.textContent = message; element.classList.add('b04-show'); clearTimeout(toastTimer);
    toastTimer = setTimeout(() => element.classList.remove('b04-show'), 2600);
  }
  let petTimer;
  $('[data-b04-cat]')?.addEventListener('click', event => {
    const cat = event.currentTarget;
    if (!reduced() && !state.paused) cat.classList.add('b04-petted');
    toast('喵～一起把想象变成作品'); clearTimeout(petTimer);
    petTimer = setTimeout(() => cat.classList.remove('b04-petted'), 1800);
  });
  document.querySelectorAll('.b04-tool-card').forEach(card => {
    card.addEventListener('pointermove', event => {
      if (reduced() || state.mobile) return;
      const rect = card.getBoundingClientRect();
      card.style.setProperty('--b04-mx', (event.clientX - rect.left) + 'px');
      card.style.setProperty('--b04-my', (event.clientY - rect.top) + 'px');
    });
  });
  let orderFlashTimer;
  document.addEventListener('click', event => {
    const choice = event.target.closest('[data-b04-product-id]');
    if (choice) {
      const form = $('#buy'), field = form?.querySelector('[name="productId"]');
      if (field) {
        field.value = choice.dataset.b04ProductId;
        field.dispatchEvent(new Event('change', { bubbles: true }));
        const name = choice.closest('.b04-tool-card')?.dataset.b04ToolName || '此插件';
        const selection = $('[data-b04-selection]');
        if (selection) selection.textContent = '已选择：' + name;
        form.classList.add('b04-order-flash'); clearTimeout(orderFlashTimer);
        orderFlashTimer = setTimeout(() => form.classList.remove('b04-order-flash'), 2800);
        toast('已选择 ' + name + '，请填写购买信息');
      }
    }
    const anchor = event.target.closest('.b04-nav a, .b04-button, .b04-detail-button, .b04-guide-link, .b04-brand');
    if (anchor?.hash && anchor.origin === location.origin && anchor.pathname === location.pathname) {
      const target = document.getElementById(anchor.hash.slice(1));
      if (target) {
        event.preventDefault(); target.scrollIntoView({ behavior: reduced() ? 'auto' : 'smooth', block: 'start' });
        history.replaceState(null, '', anchor.hash);
        document.querySelectorAll('.b04-nav a').forEach(link => link.classList.toggle('b04-active', link.hash === anchor.hash));
      }
    }
    const button = event.target.closest('.b04-button,.b04-page .btn');
    if (button && !reduced() && !state.paused) {
      const rect = button.getBoundingClientRect(), ripple = document.createElement('span');
      ripple.className = 'b04-ripple'; ripple.style.left = ((event.clientX - rect.left) || rect.width / 2) + 'px'; ripple.style.top = ((event.clientY - rect.top) || rect.height / 2) + 'px';
      button.appendChild(ripple); setTimeout(() => ripple.remove(), 700);
    }
  });
  // Read-only local motion diagnostics for render/QA; no storage or network calls.
  window.__miaoB04Debug = () => ({ t: state.t, frames: state.frames, active: state.active, paused: state.paused, reduced: reduced(), mobile: state.mobile, particleCount: state.stars.length, averageDrawMs: state.frames ? state.totalDrawMs / state.frames : 0, width: state.w, height: state.h });
  resize(); sync();
})();