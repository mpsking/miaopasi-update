#!/usr/bin/env node
import { spawn } from 'node:child_process';
import { randomBytes, scryptSync } from 'node:crypto';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const tmp = await mkdtemp(path.join(os.tmpdir(), 'miaomiao-license-server-'));
const dataDir = path.join(tmp, 'data');
const port = 19000 + Math.floor(Math.random() * 1000);
const adminToken = 'self-test-admin-token';
const env = {
  ...process.env,
  LICENSE_SERVER_DATA: dataDir,
  LICENSE_SERVER_CONFIG: path.join(tmp, 'config.json'),
  LICENSE_SERVER_LOCAL_ADMIN: '1',
  LICENSE_ADMIN_TOKEN: adminToken,
  PUBLIC_BASE_URL: `http://127.0.0.1:${port}`,
  PORT: String(port),
  HOST: '127.0.0.1'
};

let server;
try {
  await writeOwnerAccount(dataDir, 'self-test-owner', 'self-test-password');
  await runNode(['src/admin.mjs', 'init'], env);
  const issueOutput = await runNode(['src/admin.mjs', 'issue', '--customer', 'self-test', '--days', '7', '--max-devices', '1'], env);
  const activationCode = matchLine(issueOutput, 'ACTIVATION_CODE');
  server = spawn(process.execPath, ['src/server.mjs'], {
    cwd: root,
    env,
    stdio: ['ignore', 'pipe', 'pipe']
  });
  server.stderr.on('data', (chunk) => process.stderr.write(chunk));
  await waitForHealth(port);

  const webIssued = await post(port, '/api/v1/admin/issue', {
    customerName: 'self-test-web-issue',
    days: 7,
    maxDevices: 1,
    maxProfilesPerDevice: 20,
    productId: 'miaomiao-flow'
  }, adminToken);
  assert(webIssued.ok && webIssued.license?.activationCode?.startsWith('MM-'), 'admin issue activation code missing');
  assert(webIssued.downloadCode?.code?.startsWith('DL-'), 'admin issue download code missing');

  const machineId = 'SF-SELFTEST-0001';
  const secondMachineId = 'SF-SELFTEST-0002';
  const sharedDeviceId = 'WIN-SELFTEST-DEVICE-0001';
  const extensionId = 'abcdefghijklmnopqrstuvwxyzabcdef';
  const extensionVersion = '2.17.2';
  const activated = await post(port, '/api/v1/activate', {
    activationCode,
    machineId,
    deviceId: sharedDeviceId,
    profileId: 'chrome-profile-a',
    profileLabel: '入口 A',
    extensionId,
    extensionVersion,
    action: 'START_BATCH'
  });
  assert(activated.ok && activated.refreshToken && activated.runToken, 'activate failed');

  const secondActivated = await post(port, '/api/v1/activate', {
    activationCode,
    machineId: secondMachineId,
    deviceId: sharedDeviceId,
    profileId: 'chrome-profile-b',
    profileLabel: '入口 B',
    extensionId,
    extensionVersion,
    action: 'START_BATCH'
  });
  assert(secondActivated.ok && secondActivated.refreshToken && secondActivated.runToken, 'same-device second profile activate failed');

  const adminState = await get(port, '/api/v1/admin/state', adminToken);
  assert(adminState.ok, 'admin state failed');
  assert(adminState.summary.activeDeviceGroupCount === 1, 'same device should count as one active device');
  assert(adminState.summary.activeProfileCount === 2, 'same device should show two active profiles');
  assert(adminState.devices?.[0]?.activeProfileCount === 2, 'device profile count missing');

  const releaseUpload = await post(port, '/api/v1/admin/releases/upload', {
    fileName: 'self-test-plugin.zip',
    contentBase64: Buffer.from([0x50, 0x4b, 0x05, 0x06, ...Array(18).fill(0)]).toString('base64'),
    publicGroup: 'miaomiao-flow',
    productId: 'miaomiao-flow',
    name: 'Self Test Plugin',
    channel: 'self-test',
    version: extensionVersion,
    buildId: 'self-test-download-build'
  }, adminToken);
  assert(releaseUpload.ok && releaseUpload.release?.releaseId, 'release upload failed');

  const updaterDeviceId = 'MMDEV-11111111111111111111111111111111';
  const updaterAuthorized = await post(port, '/api/v1/updater/check', {
    downloadCode: webIssued.downloadCode.code,
    productId: 'miaomiao-flow',
    currentVersion: '',
    deviceId: updaterDeviceId,
    forceDownload: false
  });
  assert(updaterAuthorized.ok, 'updater device authorization failed');
  const restoredFromUpdater = await post(port, '/api/v1/device-restore', {
    machineId: 'SF-UPDATER-PROFILE-1',
    deviceId: updaterDeviceId,
    profileId: 'chrome-updater-profile-1',
    profileLabel: '更新小助手入口 1',
    productId: 'miaomiao-flow',
    extensionId,
    extensionVersion,
    action: 'START_BATCH'
  });
  assert(restoredFromUpdater.ok && restoredFromUpdater.refreshToken, 'browser entry did not inherit updater authorization');

  const directDownload = await fetch(`http://127.0.0.1:${port}${releaseUpload.release.downloadPath}`);
  assert(directDownload.status === 403, 'public direct download should require a ticket');

  const activationCodeDownload = await post(port, '/api/v1/downloads/authorize', {
    downloadCode: activationCode,
    releaseId: releaseUpload.release.releaseId
  });
  assert(activationCodeDownload.ok === false && activationCodeDownload.code === 'download_code_not_found', 'activation code should not authorize downloads');

  const downloadCodeIssue = await post(port, '/api/v1/admin/download-codes/issue', {
    activationCode
  }, adminToken);
  assert(downloadCodeIssue.ok && downloadCodeIssue.downloadCode?.code?.startsWith('DL-'), 'download code issue failed');
  const downloadCode = downloadCodeIssue.downloadCode.code;

  const authorizedDownload = await post(port, '/api/v1/downloads/authorize', {
    downloadCode,
    releaseId: releaseUpload.release.releaseId
  });
  assert(authorizedDownload.ok && authorizedDownload.downloadUrl, 'download authorize failed');
  const downloaded = await fetch(`http://127.0.0.1:${port}${authorizedDownload.downloadUrl}`);
  assert(downloaded.status === 200, 'ticketed download failed');
  const downloadState = await get(port, '/api/v1/admin/state', adminToken);
  const downloadRecord = downloadState.downloads?.find((item) => item.downloadId === authorizedDownload.download.downloadId);
  assert(downloadRecord?.status === 'downloaded', 'download record missing');
  assert(downloadRecord?.buildId === 'self-test-download-build', 'download record build id missing');
  assert(downloadRecord?.downloadCodeId === downloadCodeIssue.downloadCode.downloadCodeId, 'download record download code id missing');
  const usedDownloadCode = downloadState.downloadCodes?.find((item) => item.downloadCodeId === downloadCodeIssue.downloadCode.downloadCodeId);
  assert(usedDownloadCode?.downloadCount === 1, 'download code usage count missing');

  const updaterCheck = await post(port, '/api/v1/updater/check', {
    downloadCode,
    productId: 'miaomiao-flow',
    currentVersion: '0.0.1',
    currentBuildId: '',
    forceDownload: false
  });
  assert(updaterCheck.ok && updaterCheck.updateAvailable === true, 'updater should report update available');
  assert(updaterCheck.release?.releaseId === releaseUpload.release.releaseId, 'updater release mismatch');
  assert(updaterCheck.release?.sha256 === releaseUpload.release.sha256, 'updater sha256 missing');
  assert(/^http:\/\/127\.0\.0\.1:\d+\/downloads\//.test(updaterCheck.downloadUrl || ''), 'updater download url should be absolute local url');
  const updaterDownloaded = await fetch(updaterCheck.downloadUrl);
  assert(updaterDownloaded.status === 200, 'updater ticketed download failed');

  const updaterCurrent = await post(port, '/api/v1/updater/check', {
    downloadCode,
    productId: 'miaomiao-flow',
    currentVersion: releaseUpload.release.version,
    currentBuildId: releaseUpload.release.buildId,
    currentReleaseId: releaseUpload.release.releaseId,
    forceDownload: false
  });
  assert(updaterCurrent.ok && updaterCurrent.updateAvailable === false, 'updater should not redownload current version');
  assert(!updaterCurrent.downloadUrl, 'updater current version should not issue download url');

  const updaterActivationCode = await post(port, '/api/v1/updater/check', {
    downloadCode: activationCode,
    productId: 'miaomiao-flow',
    currentVersion: '0.0.1'
  });
  assert(updaterActivationCode.ok === false && updaterActivationCode.code === 'download_code_not_found', 'activation code should not authorize updater');

  const buildId = 'flow-image-video-2.17.5-self-test-build';
  const securityEvent = await post(port, '/api/v1/security-events', {
    eventType: 'refresh_failed',
    severity: 'warning',
    productId: 'miaomiao-flow-image-video',
    extensionId,
    extensionVersion: '2.17.5',
    buildId,
    sourcePackage: 'flow-image-video-auth-2.17.5-source-corrected',
    machineId,
    action: 'START_BATCH',
    code: 'extension_not_allowed',
    message: 'self-test security event'
  });
  assert(securityEvent.ok, 'security event failed');
  const securityState = await get(port, '/api/v1/admin/state', adminToken);
  const latestSecurityEvent = securityState.securityEvents?.find((event) => event.eventId === securityEvent.eventId);
  assert(latestSecurityEvent?.buildId === buildId, 'security event build id missing');
  assert(latestSecurityEvent?.sourcePackage === 'flow-image-video-auth-2.17.5-source-corrected', 'security event source package missing');

  const refreshed = await post(port, '/api/v1/refresh', {
    refreshToken: activated.refreshToken,
    machineId,
    deviceId: sharedDeviceId,
    profileId: 'chrome-profile-a',
    action: 'DOWNLOAD_SINGLE'
  });
  assert(refreshed.ok && refreshed.runToken, 'refresh failed');

  const validated = await post(port, '/api/v1/validate', {
    runToken: refreshed.runToken,
    machineId,
    action: 'DOWNLOAD_SINGLE'
  });
  assert(validated.ok, 'validate failed');

  const revoked = await post(port, '/api/v1/revoke', {
    activationCode,
    reason: 'self-test'
  }, adminToken);
  assert(revoked.ok, 'revoke failed');

  const afterRevoke = await post(port, '/api/v1/validate', {
    runToken: refreshed.runToken,
    machineId,
    action: 'DOWNLOAD_SINGLE'
  });
  assert(afterRevoke.ok === false && afterRevoke.code === 'activation_inactive', 'revoked token still valid');

  console.log('SELF_TEST_PASS');
} finally {
  if (server) server.kill();
  await rm(tmp, { recursive: true, force: true });
}

function runNode(args, runEnv) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, args, { cwd: root, env: runEnv, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk; });
    child.stderr.on('data', (chunk) => { stderr += chunk; });
    child.on('close', (code) => {
      if (code === 0) resolve(stdout);
      else reject(new Error(`${args.join(' ')} exited ${code}\n${stderr}`));
    });
  });
}

function matchLine(text, key) {
  const line = text.split(/\r?\n/).find((item) => item.startsWith(`${key}=`));
  if (!line) throw new Error(`${key} missing`);
  return line.slice(key.length + 1).trim();
}

async function waitForHealth(testPort) {
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${testPort}/health`);
      if (res.ok) return;
    } catch {
      await new Promise((resolve) => setTimeout(resolve, 150));
    }
  }
  throw new Error('server health check timed out');
}

async function post(testPort, pathname, body, adminToken = '') {
  const headers = { 'Content-Type': 'application/json' };
  if (adminToken) headers.Authorization = `Bearer ${adminToken}`;
  const res = await fetch(`http://127.0.0.1:${testPort}${pathname}`, {
    method: 'POST',
    headers,
    body: JSON.stringify(body)
  });
  return res.json();
}

async function get(testPort, pathname, adminToken = '') {
  const headers = {};
  if (adminToken) headers.Authorization = `Bearer ${adminToken}`;
  const res = await fetch(`http://127.0.0.1:${testPort}${pathname}`, { headers });
  return res.json();
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function writeOwnerAccount(targetDataDir, username, password) {
  const salt = randomBytes(16).toString('hex');
  await mkdir(targetDataDir, { recursive: true });
  await writeFile(path.join(targetDataDir, 'owner-account.json'), `${JSON.stringify({
    username,
    algorithm: 'scrypt',
    passwordSalt: salt,
    passwordHash: scryptSync(password, salt, 32).toString('hex'),
    updatedAt: new Date().toISOString()
  }, null, 2)}\n`, 'utf8');
}
