import { promises as fs } from 'node:fs';
import { getConfigPath, readJson } from './util.mjs';

export const DEFAULT_CONFIG = Object.freeze({
  issuer: 'miaomiao-license-server',
  productId: 'miaomiao-flow',
  productName: '妙妙工具 - Google Flow 批量生成',
  tokenTtlSeconds: 60,
  offlineGraceSeconds: 86400,
  defaultMaxProfilesPerDevice: 20,
  minExtensionVersion: '2.17.2',
  allowedExtensionIds: [],
  allowedActions: [
    'START_BATCH',
    'DOWNLOAD_SINGLE',
    'UNATTENDED_CREATE',
    'UNATTENDED_PAUSE',
    'UNATTENDED_RESUME',
    'UNATTENDED_CANCEL',
    'EXPORT_TEMPLATES',
    'IMPORT_TEMPLATES',
    'SCAN_FLOW_IMAGES',
    'UPLOAD_IMAGE'
  ]
});

export async function loadConfig() {
  const file = getConfigPath();
  const disk = await readJson(file, null);
  return {
    ...DEFAULT_CONFIG,
    ...(disk || {}),
    tokenTtlSeconds: Number(disk?.tokenTtlSeconds || process.env.TOKEN_TTL_SECONDS || DEFAULT_CONFIG.tokenTtlSeconds),
    offlineGraceSeconds: Number(disk?.offlineGraceSeconds || process.env.OFFLINE_GRACE_SECONDS || DEFAULT_CONFIG.offlineGraceSeconds),
    defaultMaxProfilesPerDevice: Number(disk?.defaultMaxProfilesPerDevice || DEFAULT_CONFIG.defaultMaxProfilesPerDevice)
  };
}

export async function writeDefaultConfigIfMissing(targetPath = getConfigPath()) {
  try {
    await fs.access(targetPath);
    return false;
  } catch {
    await fs.writeFile(targetPath, `${JSON.stringify(DEFAULT_CONFIG, null, 2)}\n`, 'utf8');
    return true;
  }
}

export async function saveConfig(config, targetPath = getConfigPath()) {
  await fs.writeFile(targetPath, `${JSON.stringify(config, null, 2)}\n`, 'utf8');
}
