#!/usr/bin/env node
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { loadConfig } from './config.mjs';
import { Store } from './store.mjs';
import { issueLicense, revokeLicenseOrActivation } from './license-core.mjs';
import { getDataDir } from './util.mjs';

const extensionDir = path.resolve(process.argv[2] || '');
if (!extensionDir) {
  console.error('Usage: node src/test-extension-client-live.mjs <extension-dir>');
  process.exit(1);
}

const store = new Store(getDataDir());
const config = await loadConfig();
const license = await issueLicense(store, {
  customerName: 'extension-client-live-test',
  days: 1,
  maxDevices: 1
}, config);

try {
  const clientUrl = pathToFileURL(path.join(extensionDir, 'lib', 'license-online.js')).href + `?t=${Date.now()}`;
  const client = await import(clientUrl);
  const memory = {};
  const storage = {
    async get(keys) {
      const out = {};
      for (const key of keys) out[key] = memory[key];
      return out;
    },
    async set(values) {
      Object.assign(memory, values);
    },
    async remove(keys) {
      for (const key of keys) delete memory[key];
    }
  };
  const runtime = { id: 'abcdefghijklmnopqrstuvwxyzabcdef' };
  const machineId = 'SF-EXTENSION-LIVE-TEST-0001';
  const activated = await client.activateOnlineLicense({
    storage,
    runtime,
    activationCode: license.activationCode,
    machineId,
    action: 'START_BATCH'
  });
  const runToken = await client.requireOnlineRunToken({
    storage,
    machineId,
    action: 'DOWNLOAD_SINGLE'
  });
  console.log(JSON.stringify({
    ok: Boolean(activated.ok && runToken),
    activationCode: license.activationCode,
    activationId: activated.activation?.activationId || '',
    daysRemaining: activated.daysRemaining,
    runTokenParts: String(runToken).split('.').length
  }, null, 2));
} finally {
  await revokeLicenseOrActivation(store, {
    activationCode: license.activationCode,
    reason: 'extension-client-live-test'
  });
}
