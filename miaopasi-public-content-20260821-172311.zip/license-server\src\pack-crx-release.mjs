#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { createHash, createPrivateKey, createPublicKey, generateKeyPairSync } from 'node:crypto';
import { promises as fs } from 'node:fs';
import fsSync from 'node:fs';
import path from 'node:path';
import { getDataDir, nowIso, parseArgs, SERVER_ROOT, writeJsonAtomic } from './util.mjs';

const args = parseArgs(process.argv.slice(2));
const sourceDir = args._[0] ? path.resolve(args._[0]) : '';
if (!sourceDir) {
  throw new Error('usage: node src/pack-crx-release.mjs <locked-extension-dir> [--output <dir>] [--key <pem>] [--chrome <exe>] [--update-url <url>] [--build-id <id>]');
}

const outputDir = path.resolve(args.output || path.join(SERVER_ROOT, 'dist', 'crx'));
const keyPath = path.resolve(args.key || path.join(getDataDir(), 'crx-update-key.pem'));
const updateUrl = String(args['update-url'] || 'https://xn--i2ru8q2qg.top/updates.xml').trim();
const namePrefix = safeName(String(args['name-prefix'] || 'miaomiao-flow'));
const chromePath = String(args.chrome || findPackBrowser() || '').trim();
if (!chromePath) throw new Error('Chrome or Edge executable was not found');

await fs.access(sourceDir);
await fs.mkdir(outputDir, { recursive: true });
const privatePem = await ensureCrxPrivateKey(keyPath);
const publicDer = createPublicKey(privatePem).export({ type: 'spki', format: 'der' });
const publicKeyBase64 = publicDer.toString('base64');
const extensionId = extensionIdFromPublicKey(publicDer);

const sourceName = path.basename(sourceDir).replace(/[^\w.-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '') || 'extension';
const stamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
const stagingDir = path.join(outputDir, `${sourceName}-crx-${stamp}`);
await fs.cp(sourceDir, stagingDir, {
  recursive: true,
  filter: (entry) => shouldCopy(entry)
});

const manifestPath = path.join(stagingDir, 'manifest.json');
const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
const version = String(manifest.version || '0.0.0');
const buildId = String(args['build-id'] || `${namePrefix}-${version}-${stamp}`).trim();
await stampPackageProvenance(stagingDir, {
  buildId,
  releaseId: '',
  sourcePackage: sourceName,
  packageSha256: ''
});
manifest.key = publicKeyBase64;
manifest.update_url = updateUrl;
await fs.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');

const packResult = spawnSync(chromePath, [
  `--pack-extension=${stagingDir}`,
  `--pack-extension-key=${keyPath}`
], {
  cwd: outputDir,
  encoding: 'utf8',
  windowsHide: true
});
if (packResult.error) throw packResult.error;
if (packResult.status !== 0) {
  throw new Error([
    `CRX pack failed with exit ${packResult.status}`,
    packResult.stdout,
    packResult.stderr
  ].filter(Boolean).join('\n'));
}

const chromeCrxPath = `${stagingDir}.crx`;
await fs.access(chromeCrxPath);
const finalCrxName = `${namePrefix}-${version}-autoupdate.crx`;
const finalCrxPath = uniquePath(path.join(outputDir, finalCrxName));
await fs.rename(chromeCrxPath, finalCrxPath);

const crx = await fs.readFile(finalCrxPath);
const crxExtensionId = extensionIdFromCrxBuffer(crx);
if (crxExtensionId !== extensionId) {
  throw new Error(`packed CRX id mismatch: expected ${extensionId}, got ${crxExtensionId || '<empty>'}`);
}

const build = {
  ok: true,
  builtAt: nowIso(),
  sourceDir,
  stagingDir,
  crxPath: finalCrxPath,
  privateKeyPath: keyPath,
  extensionId,
  updateUrl,
  version,
  buildId,
  sourcePackage: sourceName,
  sizeBytes: crx.length,
  sha256: createHash('sha256').update(crx).digest('hex').toUpperCase()
};
const buildInfoPath = path.join(outputDir, `${namePrefix}-${version}-autoupdate.build.json`);
await writeJsonAtomic(buildInfoPath, build);
console.log(JSON.stringify({ ...build, buildInfoPath }, null, 2));

async function stampPackageProvenance(rootDir, provenance) {
  const candidates = [
    path.join(rootDir, 'lib', 'license-online.js'),
    path.join(rootDir, 'license-online-global.js')
  ];
  for (const file of candidates) {
    if (!fsSync.existsSync(file)) continue;
    const original = await fs.readFile(file, 'utf8');
    const next = upsertPackageProvenanceText(original, provenance);
    if (next !== original) await fs.writeFile(file, next, 'utf8');
  }
}

function upsertPackageProvenanceText(text, provenance) {
  const fields = {
    buildId: provenance.buildId || '',
    releaseId: provenance.releaseId || '',
    sourcePackage: provenance.sourcePackage || '',
    packageSha256: provenance.packageSha256 || ''
  };
  for (const key of Object.keys(fields)) {
    text = text.replace(new RegExp(`\\n\\s*${key}:\\s*(['"])[^'"]*\\1,?`, 'g'), '');
  }
  return text.replace(/(\n)(\s*)extensionVersion:\s*(['"])[^'"]*\3,\s*\n/, (match, newline, indent) => {
    const inserted = Object.entries(fields)
      .map(([key, value]) => `${indent}${key}: ${JSON.stringify(value)},`)
      .join('\n');
    return `${match}${inserted}\n`;
  });
}

function shouldCopy(entry) {
  const normalized = path.normalize(entry);
  const parts = normalized.split(path.sep);
  if (parts.includes('.git') || parts.includes('tests') || parts.includes('node_modules')) return false;
  const name = path.basename(entry).toLowerCase();
  if (name.endsWith('.zip') || name.endsWith('.crx') || name.endsWith('.pem')) return false;
  return true;
}

async function ensureCrxPrivateKey(file) {
  try {
    const existing = await fs.readFile(file, 'utf8');
    const normalized = normalizePrivateKeyPem(existing);
    if (normalized !== existing) await fs.writeFile(file, normalized, 'utf8');
    return normalized;
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
  }
  const { privateKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
  const pem = privateKey.export({ type: 'pkcs8', format: 'pem' });
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, pem, { encoding: 'utf8', flag: 'wx' });
  return pem;
}

function normalizePrivateKeyPem(pem) {
  return createPrivateKey(pem).export({ type: 'pkcs8', format: 'pem' });
}

function findPackBrowser() {
  const candidates = [
    path.join(process.env.ProgramFiles || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(process.env['ProgramFiles(x86)'] || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(process.env.ProgramFiles || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(process.env['ProgramFiles(x86)'] || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe')
  ];
  return candidates.find((candidate) => candidate && fsSync.existsSync(candidate)) || '';
}

function uniquePath(target) {
  if (!fsSync.existsSync(target)) return target;
  const parsed = path.parse(target);
  for (let index = 2; index < 1000; index += 1) {
    const candidate = path.join(parsed.dir, `${parsed.name}-${index}${parsed.ext}`);
    if (!fsSync.existsSync(candidate)) return candidate;
  }
  throw new Error(`could not allocate output path for ${target}`);
}

function safeName(value) {
  return value.replace(/[^\w.-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '') || 'extension';
}

function extensionIdFromCrxBuffer(buffer) {
  if (buffer.length < 16 || buffer.subarray(0, 4).toString('utf8') !== 'Cr24') return '';
  const version = buffer.readUInt32LE(4);
  if (version !== 3) return '';
  const headerSize = buffer.readUInt32LE(8);
  const header = buffer.subarray(12, 12 + headerSize);
  const publicKey = firstCrxPublicKey(header);
  return publicKey ? extensionIdFromPublicKey(publicKey) : '';
}

function firstCrxPublicKey(buffer) {
  let offset = 0;
  while (offset < buffer.length) {
    const key = readVarint(buffer, offset);
    if (!key) return null;
    offset = key.next;
    const field = Number(key.value >> 3n);
    const wire = Number(key.value & 7n);
    if (wire !== 2) return null;
    const length = readVarint(buffer, offset);
    if (!length) return null;
    offset = length.next;
    const end = offset + Number(length.value);
    if (end > buffer.length) return null;
    if (field === 2 || field === 3) {
      const publicKey = publicKeyFromProof(buffer.subarray(offset, end));
      if (publicKey) return publicKey;
    }
    offset = end;
  }
  return null;
}

function publicKeyFromProof(buffer) {
  let offset = 0;
  while (offset < buffer.length) {
    const key = readVarint(buffer, offset);
    if (!key) return null;
    offset = key.next;
    const field = Number(key.value >> 3n);
    const wire = Number(key.value & 7n);
    if (wire !== 2) return null;
    const length = readVarint(buffer, offset);
    if (!length) return null;
    offset = length.next;
    const end = offset + Number(length.value);
    if (end > buffer.length) return null;
    if (field === 1) return buffer.subarray(offset, end);
    offset = end;
  }
  return null;
}

function readVarint(buffer, offset) {
  let value = 0n;
  let shift = 0n;
  for (let index = offset; index < buffer.length && index < offset + 10; index += 1) {
    const byte = BigInt(buffer[index]);
    value |= (byte & 0x7fn) << shift;
    if ((byte & 0x80n) === 0n) return { value, next: index + 1 };
    shift += 7n;
  }
  return null;
}

function extensionIdFromPublicKey(publicKey) {
  const digest = createHash('sha256').update(publicKey).digest();
  const alphabet = 'abcdefghijklmnop';
  return Array.from(digest.subarray(0, 16))
    .map((byte) => alphabet[byte >> 4] + alphabet[byte & 15])
    .join('');
}
