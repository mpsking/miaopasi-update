import { promises as fs } from 'node:fs';
import path from 'node:path';
import { createHash, randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const SERVER_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DEFAULT_PRODUCT_ID = 'miaomiao-flow';

export function getDataDir() {
  return path.resolve(process.env.LICENSE_SERVER_DATA || path.join(SERVER_ROOT, 'data'));
}

export function getConfigPath() {
  return path.resolve(process.env.LICENSE_SERVER_CONFIG || path.join(SERVER_ROOT, 'config.json'));
}

export async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true });
}

export async function fileExists(file) {
  try {
    await fs.access(file);
    return true;
  } catch {
    return false;
  }
}

export async function readJson(file, fallback = null) {
  try {
    return JSON.parse(await fs.readFile(file, 'utf8'));
  } catch (error) {
    if (error?.code === 'ENOENT') return fallback;
    throw error;
  }
}

export async function writeJsonAtomic(file, value) {
  await ensureDir(path.dirname(file));
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  await fs.writeFile(tmp, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
  await fs.rename(tmp, file);
}

export function nowIso() {
  return new Date().toISOString();
}

export function addSecondsIso(seconds, from = Date.now()) {
  return new Date(from + Number(seconds) * 1000).toISOString();
}

export function addDaysIso(days, from = Date.now()) {
  return new Date(from + Number(days) * 86400000).toISOString();
}

export function parseTime(value) {
  const ms = Date.parse(value);
  return Number.isFinite(ms) ? ms : NaN;
}

export function isExpired(expiresAt, atMs = Date.now()) {
  const expiresMs = parseTime(expiresAt);
  return !Number.isFinite(expiresMs) || expiresMs <= atMs;
}

export function base64UrlEncode(input) {
  const buffer = Buffer.isBuffer(input) ? input : Buffer.from(input);
  return buffer.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

export function base64UrlDecode(input) {
  const normalized = String(input).replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
  return Buffer.from(padded, 'base64');
}

export function randomId(prefix, bytes = 16) {
  return `${prefix}${base64UrlEncode(randomBytes(bytes))}`;
}

export function randomActivationCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = randomBytes(20);
  let body = '';
  for (const byte of bytes) body += alphabet[byte % alphabet.length];
  return `MM-${body.slice(0, 5)}-${body.slice(5, 10)}-${body.slice(10, 15)}-${body.slice(15, 20)}`;
}

export function randomDownloadCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = randomBytes(16);
  let body = '';
  for (const byte of bytes) body += alphabet[byte % alphabet.length];
  return `DL-${body.slice(0, 4)}-${body.slice(4, 8)}-${body.slice(8, 12)}-${body.slice(12, 16)}`;
}

export function sha256Hex(input) {
  return createHash('sha256').update(String(input), 'utf8').digest('hex').toUpperCase();
}

export function normalizeMachineId(value) {
  return typeof value === 'string' ? value.trim().toUpperCase() : '';
}

export function machineHash(machineId, pepper = '') {
  const normalized = normalizeMachineId(machineId);
  return sha256Hex(`${pepper}:${normalized}`);
}

export function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}

export function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!arg.startsWith('--')) {
      out._.push(arg);
      continue;
    }
    const key = arg.slice(2);
    const next = argv[i + 1];
    if (!next || next.startsWith('--')) {
      out[key] = true;
    } else {
      out[key] = next;
      i += 1;
    }
  }
  return out;
}

export function requireField(body, field) {
  const value = body?.[field];
  if (typeof value !== 'string' || !value.trim()) {
    const error = new Error(`${field} is required`);
    error.status = 400;
    throw error;
  }
  return value.trim();
}

export function publicLicenseView(license) {
  if (!license) return null;
  const { activationCode, ...rest } = license;
  return rest;
}

export function assertVersionAtLeast(version, minVersion) {
  if (!minVersion || !version) return true;
  const a = String(version).split('.').map((part) => Number.parseInt(part, 10) || 0);
  const b = String(minVersion).split('.').map((part) => Number.parseInt(part, 10) || 0);
  const max = Math.max(a.length, b.length);
  for (let i = 0; i < max; i += 1) {
    if ((a[i] || 0) > (b[i] || 0)) return true;
    if ((a[i] || 0) < (b[i] || 0)) return false;
  }
  return true;
}
