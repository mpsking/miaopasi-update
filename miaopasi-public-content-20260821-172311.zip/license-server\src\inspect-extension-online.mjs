#!/usr/bin/env node
import { promises as fs } from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.argv[2] || '');
const expectedApiBase = process.argv[3] || '';
if (!root) {
  console.error('Usage: node src/inspect-extension-online.mjs <extension-dir> [expected-api-base]');
  process.exit(1);
}

const manifest = JSON.parse(await fs.readFile(path.join(root, 'manifest.json'), 'utf8'));
const client = await fs.readFile(path.join(root, 'lib', 'license-online.js'), 'utf8');
console.log(JSON.stringify({
  host_permissions: manifest.host_permissions || [],
  apiBaseFound: expectedApiBase ? client.includes(`apiBase: '${expectedApiBase}'`) : null,
  hasLocalhost: client.includes('127.0.0.1') || JSON.stringify(manifest).includes('127.0.0.1')
}, null, 2));
