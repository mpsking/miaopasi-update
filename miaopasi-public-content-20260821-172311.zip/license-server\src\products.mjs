import { DEFAULT_PRODUCT_ID } from './util.mjs';

const FALLBACK_PRODUCTS = Object.freeze([
  {
    productId: DEFAULT_PRODUCT_ID,
    name: '妙妙工具 - Google Flow 批量生成',
    extensionIds: [
      'ikjniklakciohiehlfpanfjkndpjccem',
      'kefmpkkiglgmanjnigdbcphgppnhiomk'
    ],
    minExtensionVersion: '2.17.3'
  },
  {
    productId: 'jimeng-agent',
    name: '即梦 Agent 自动跑图',
    extensionIds: [
      'iiniilocbdjpmebcelliidencdegmekb'
    ],
    minExtensionVersion: '2.6.2'
  }
]);

export function listProducts(config = {}, releases = []) {
  const products = new Map();
  const addProduct = (product = {}) => {
    const productId = String(product.productId || product.id || '').trim();
    if (!productId) return;
    const existing = products.get(productId) || {};
    const extensionIds = unique([
      ...(existing.extensionIds || []),
      ...(Array.isArray(product.extensionIds) ? product.extensionIds : [])
    ]);
    products.set(productId, {
      ...existing,
      ...product,
      productId,
      name: String(product.name || product.productName || existing.name || productId).trim(),
      extensionIds,
      minExtensionVersion: String(product.minExtensionVersion || existing.minExtensionVersion || '').trim()
    });
  };

  addProduct({
    productId: config.productId || DEFAULT_PRODUCT_ID,
    name: config.productName || '妙妙工具 - Google Flow 批量生成',
    extensionIds: [],
    minExtensionVersion: config.minExtensionVersion || ''
  });

  for (const product of FALLBACK_PRODUCTS) addProduct(product);

  if (Array.isArray(config.products)) {
    for (const product of config.products) addProduct(product);
  } else if (config.products && typeof config.products === 'object') {
    for (const [productId, product] of Object.entries(config.products)) {
      addProduct({ productId, ...(product || {}) });
    }
  }

  for (const release of releases || []) {
    addProduct({
      productId: release.publicGroup || release.productId,
      name: release.name,
      extensionIds: release.extensionId ? [release.extensionId] : [],
      minExtensionVersion: release.version || ''
    });
  }

  const minByExtension = config.extensionMinVersions && typeof config.extensionMinVersions === 'object'
    ? config.extensionMinVersions
    : {};
  return [...products.values()].map((product) => {
    const extensionMins = (product.extensionIds || [])
      .map((id) => String(minByExtension[id] || '').trim())
      .filter(Boolean);
    return {
      ...product,
      extensionIds: unique(product.extensionIds || []),
      minExtensionVersion: extensionMins[0] || product.minExtensionVersion || config.minExtensionVersion || ''
    };
  });
}

export function productById(config = {}, productId = '') {
  const id = String(productId || '').trim();
  return listProducts(config).find((product) => product.productId === id) || null;
}

export function isKnownProductId(config = {}, productId = '') {
  return Boolean(productById(config, productId));
}

export function productIdForExtension(config = {}, extensionId = '') {
  const id = String(extensionId || '').trim();
  if (!id) return '';
  const product = listProducts(config).find((item) => (item.extensionIds || []).includes(id));
  return product?.productId || '';
}

export function normalizeProductId(config = {}, requestedProductId = '', extensionId = '') {
  const requested = String(requestedProductId || '').trim();
  if (requested && isKnownProductId(config, requested)) return requested;
  return productIdForExtension(config, extensionId) || config.productId || DEFAULT_PRODUCT_ID;
}

export function productNameForId(config = {}, productId = '') {
  const product = productById(config, productId);
  return product?.name || productId || '';
}

export function productAllowsExtension(config = {}, productId = '', extensionId = '') {
  const allowedExtensionIds = Array.isArray(config.allowedExtensionIds) ? config.allowedExtensionIds.filter(Boolean) : [];
  if (!allowedExtensionIds.length) return true;
  const product = productById(config, productId);
  if (!product || !Array.isArray(product.extensionIds) || !product.extensionIds.length) return true;
  return product.extensionIds.includes(extensionId);
}

function unique(values) {
  return [...new Set(values.map((value) => String(value || '').trim()).filter(Boolean))];
}
