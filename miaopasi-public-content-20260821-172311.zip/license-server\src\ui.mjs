export function wantsHtml(req) {
  const accept = String(req.headers.accept || '');
  return accept.includes('text/html');
}

export function renderHome({ config, publicJwk }) {
  const keyId = escapeHtml(publicJwk.kid || 'p256-local');
  const product = escapeHtml(config.productId);
  const minVersion = escapeHtml(config.minExtensionVersion);
  const tokenTtl = escapeHtml(String(config.tokenTtlSeconds));
  return pageShell({
    title: '妙妙授权服务',
    active: 'overview',
    body: `
      <section class="hero" aria-label="授权服务概览">
        <div class="hero-copy">
          <p class="eyebrow">妙妙授权服务</p>
          <h1 class="hero-title"><span>妙妙授权服务</span><span>在线</span></h1>
          <p class="lede">面向客户包的在线激活、短期执行票据、设备绑定和吊销控制已经接入当前域名。</p>
          <div class="actions">
            <a class="btn btn-primary" href="/health">查看健康检查</a>
            <a class="btn btn-ghost" href="/api/v1/public-key">查看授权公钥</a>
          </div>
        </div>
        <div class="status-panel glass">
          <div class="panel-head">
            <span class="pulse"></span>
            <span>在线网关</span>
          </div>
          <dl class="metrics">
            <div><dt>产品</dt><dd>${product}</dd></div>
            <div><dt>最低版本</dt><dd>${minVersion}</dd></div>
            <div><dt>执行票据有效期</dt><dd>${tokenTtl}s</dd></div>
            <div><dt>签名密钥</dt><dd>${keyId}</dd></div>
          </dl>
        </div>
      </section>

      <section class="grid" aria-label="授权能力">
        ${featureCard('01', '在线激活', '客户输入 MM 激活码后，服务端绑定设备并返回刷新凭证与短期执行票据。')}
        ${featureCard('02', '执行票据', '批量生成、下载、无人值守、模板导入导出等入口按动作名刷新票据。')}
        ${featureCard('03', '远程吊销', '授权、设备、过期时间和版本门槛都由服务端控制，旧包可停止发票据。')}
      </section>

      <section class="console glass" aria-label="接口路径">
        <div>
          <p class="eyebrow">接口概览</p>
          <h2>机器接口保持干净</h2>
        </div>
        <div class="endpoint-list">
          ${endpoint('GET', '/health', '服务健康状态')}
          ${endpoint('GET', '/api/v1/public-key?format=json', '扩展验签公钥 JSON')}
          ${endpoint('POST', '/api/v1/activate', '激活设备')}
          ${endpoint('POST', '/api/v1/refresh', '刷新执行票据')}
        </div>
      </section>`
  });
}

export function renderPublicKey({ config, publicJwk }) {
  const json = JSON.stringify({ ok: true, publicJwk }, null, 2);
  return pageShell({
    title: '授权公钥',
    active: 'key',
    body: `
      <section class="hero compact" aria-label="授权公钥">
        <div class="hero-copy">
          <p class="eyebrow">公钥验签</p>
          <h1 class="hero-title"><span>授权公钥</span></h1>
          <p class="lede">这个密钥用于扩展校验服务端签发的短期执行票据。私钥只保存在服务器，不会下发到客户包。</p>
          <div class="actions">
            <a class="btn btn-primary" href="/api/v1/public-key?format=json">查看原始数据</a>
            <a class="btn btn-ghost" href="/">返回主页</a>
          </div>
        </div>
        <div class="status-panel glass">
          <div class="panel-head">
            <span class="pulse"></span>
            <span>${escapeHtml(config.productName || '妙妙工具')}</span>
          </div>
          <dl class="metrics">
            <div><dt>算法</dt><dd>ES256 / P-256</dd></div>
            <div><dt>密钥编号</dt><dd>${escapeHtml(publicJwk.kid || 'p256-local')}</dd></div>
            <div><dt>曲线</dt><dd>${escapeHtml(publicJwk.crv || 'P-256')}</dd></div>
          </dl>
        </div>
      </section>

      <section class="key-card glass" aria-label="公钥 JSON">
        <div class="key-toolbar">
          <div>
            <p class="eyebrow">执行票据验签</p>
            <h2>公钥内容</h2>
          </div>
          <button class="btn btn-ghost" type="button" data-copy="public-key-json">复制</button>
        </div>
        <pre id="public-key-json"><code>${escapeHtml(json)}</code></pre>
      </section>`
  });
}

export function renderAdmin({ config }) {
  return pageShell({
    title: '授权控制台',
    active: 'admin',
    body: `
      <style>
        .admin-wrap{display:grid;gap:16px;margin-top:-40px}
        .admin-hero{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:16px;align-items:stretch}
        .admin-card{padding:22px}
        .admin-card h2{font-size:30px;margin-bottom:8px}
        .admin-card h3{margin:0 0 16px;font-size:16px}
        .admin-copy{font-family:var(--serif);font-size:16px;line-height:1.78;color:#e8e8e8;margin:0}
        .form-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
        .form-grid.two{grid-template-columns:repeat(2,minmax(0,1fr))}
        .field{display:grid;gap:6px}
        label{font-size:10px;color:var(--mist);text-transform:uppercase}
        input,textarea,select{width:100%;min-height:38px;border:1px solid rgba(255,255,255,.22);border-radius:6px;background:rgba(255,255,255,.07);color:#fff;padding:8px 10px;font:14px/1.4 var(--sans);outline:none}
        textarea{min-height:86px;resize:vertical}
        input:focus,textarea:focus{border-color:rgba(255,255,255,.62);background:rgba(255,255,255,.1)}
        .toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:12px}
        .result{min-height:44px;border:1px solid rgba(255,255,255,.14);border-radius:8px;background:rgba(255,255,255,.05);padding:12px;color:#e8e8e8;font-family:Consolas,"SFMono-Regular",monospace;font-size:12px;line-height:1.55;white-space:pre-wrap;overflow:auto}
        .stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px}
        .stat{padding:18px}
        .stat span{display:block;color:var(--mist);font-size:10px;text-transform:uppercase;margin-bottom:10px}
        .stat strong{font-size:28px;font-weight:400}
        .table-card{padding:0;overflow:hidden}
        .table-head{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.14)}
        .table-head h3{margin:0;font-size:15px}
        table{width:100%;border-collapse:collapse}
        th,td{border-bottom:1px solid rgba(255,255,255,.1);padding:12px 14px;text-align:left;font-size:12px;vertical-align:top}
        th{color:var(--mist);font-weight:400;text-transform:uppercase}
        td{color:#f2f2f2}
        tr:last-child td{border-bottom:0}
        .mono{font-family:Consolas,"SFMono-Regular",monospace;word-break:break-all}
        .tag{display:inline-flex;align-items:center;border:1px solid rgba(255,255,255,.22);border-radius:999px;padding:3px 8px;font-size:11px}
        .tag.active{background:rgba(146,255,205,.1);border-color:rgba(146,255,205,.35);color:#b9ffd9}
        .tag.revoked{background:rgba(255,120,120,.1);border-color:rgba(255,120,120,.35);color:#ffc4c4}
        .row-actions{display:flex;gap:6px;flex-wrap:wrap}
        .mini{min-height:26px;border-radius:5px;padding:3px 8px;font-size:11px}
        .danger{border-color:rgba(255,120,120,.42);color:#ffd0d0}
        .muted{color:var(--mist)}
        @media(max-width:980px){.admin-hero,.form-grid,.form-grid.two,.stats{grid-template-columns:1fr}.table-card{overflow:auto}table{min-width:900px}}
      </style>

      <section class="admin-wrap" aria-label="授权控制台">
        <div class="admin-hero">
          <div class="admin-card glass">
            <p class="eyebrow">控制中心</p>
            <h1 class="hero-title"><span>授权控制台</span></h1>
            <p class="admin-copy">这里可以直接发授权码、查看设备激活、远程吊销，并用真实接口测试客户激活链路。</p>
            <div class="toolbar">
              <button class="btn btn-primary" id="refresh-state" type="button">刷新数据</button>
              <a class="btn btn-ghost" href="/">返回首页</a>
            </div>
          </div>
          <div class="admin-card glass">
            <h3>管理令牌</h3>
            <div class="field">
              <label for="admin-token">本机管理令牌</label>
              <input id="admin-token" type="password" autocomplete="off" placeholder="粘贴 data/admin-token.txt 里的 token">
            </div>
            <div class="toolbar">
              <button class="btn btn-primary" id="save-token" type="button">保存并连接</button>
              <button class="btn btn-ghost" id="clear-token" type="button">清除</button>
            </div>
            <p class="admin-copy muted">管理令牌只保存在当前浏览器本地存储，不会写进网页源码。</p>
          </div>
        </div>

        <div class="stats" id="stats"></div>

        <div class="admin-card glass">
          <h3>新建授权码</h3>
          <form id="issue-form">
            <div class="form-grid">
              <div class="field"><label>客户名</label><input name="customerName" placeholder="例如：测试客户" required></div>
              <div class="field"><label>有效天数</label><input name="days" type="number" min="1" value="30" required></div>
              <div class="field"><label>设备数</label><input name="maxDevices" type="number" min="1" value="1" required></div>
              <div class="field"><label>备注</label><input name="notes" placeholder="订单号 / 渠道 / 售后备注"></div>
            </div>
            <div class="toolbar">
              <button class="btn btn-primary" type="submit">生成授权码</button>
            </div>
          </form>
          <div class="result" id="issue-result">等待生成。</div>
        </div>

        <div class="admin-card glass">
          <h3>客户激活测试</h3>
          <form id="activate-form">
            <div class="form-grid">
              <div class="field"><label>激活码</label><input name="activationCode" placeholder="MM-XXXXX-XXXXX-XXXXX-XXXXX" required></div>
              <div class="field"><label>机器码</label><input name="machineId" id="machine-id" required></div>
              <div class="field"><label>扩展 ID</label><input name="extensionId" value="abcdefghijklmnopqrstuvwxyzabcdef" required></div>
              <div class="field"><label>扩展版本</label><input name="extensionVersion" value="${escapeHtml(config.minExtensionVersion)}" required></div>
            </div>
            <div class="toolbar">
              <button class="btn btn-primary" type="submit">测试激活</button>
            </div>
          </form>
          <div class="result" id="activate-result">这里会调用真实 /api/v1/activate。测试会占用一个设备名。</div>
        </div>

        <section class="table-card glass">
          <div class="table-head"><h3>授权列表</h3><span class="muted" id="license-count">-</span></div>
          <table>
            <thead><tr><th>状态</th><th>客户</th><th>授权码</th><th>设备</th><th>到期</th><th>操作</th></tr></thead>
            <tbody id="licenses-body"><tr><td colspan="6">等待连接。</td></tr></tbody>
          </table>
        </section>

        <section class="table-card glass">
          <div class="table-head"><h3>设备激活</h3><span class="muted" id="activation-count">-</span></div>
          <table>
            <thead><tr><th>状态</th><th>激活编号</th><th>授权编号</th><th>扩展</th><th>最近在线</th><th>操作</th></tr></thead>
            <tbody id="activations-body"><tr><td colspan="6">等待连接。</td></tr></tbody>
          </table>
        </section>

        <section class="table-card glass">
          <div class="table-head"><h3>审计日志</h3><span class="muted">最近 80 条</span></div>
          <table>
            <thead><tr><th>时间</th><th>事件</th><th>详情</th></tr></thead>
            <tbody id="audit-body"><tr><td colspan="3">等待连接。</td></tr></tbody>
          </table>
        </section>
      </section>

      <script>
        const tokenInput = document.getElementById('admin-token');
        const saved = localStorage.getItem('miaomiaoAdminToken') || '';
        tokenInput.value = saved;
        document.getElementById('machine-id').value = 'SF-WEB-TEST-' + Math.random().toString(16).slice(2, 10).toUpperCase();

        const el = id => document.getElementById(id);
        const fmt = value => {
          if (!value) return '-';
          const date = new Date(value);
          return Number.isFinite(date.getTime()) ? date.toLocaleString('zh-CN', { hour12:false }) : String(value);
        };
        const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        const statusText = { active:'有效', revoked:'已吊销', banned:'已封禁', pending:'待处理', fulfilled:'已完成', cancelled:'已取消' };
        const tag = status => '<span class="tag ' + h(status) + '">' + h(statusText[status] || status || '-') + '</span>';
        const token = () => tokenInput.value.trim();

        async function adminApi(path, options = {}) {
          const headers = { Authorization: 'Bearer ' + token(), ...(options.headers || {}) };
          if (options.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
          const res = await fetch(path, { ...options, headers });
          const data = await res.json().catch(() => ({}));
          if (!res.ok || data.ok === false) throw new Error(data.error || data.code || ('HTTP ' + res.status));
          return data;
        }

        async function publicApi(path, body) {
          const res = await fetch(path, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body) });
          const data = await res.json().catch(() => ({}));
          if (!res.ok || data.ok === false) throw new Error(data.error || data.code || ('HTTP ' + res.status));
          return data;
        }

        async function loadState() {
          if (!token()) {
            el('stats').innerHTML = '';
            el('licenses-body').innerHTML = '<tr><td colspan="6">先输入管理令牌。</td></tr>';
            return;
          }
          const state = await adminApi('/api/v1/admin/state');
          renderStats(state.summary);
          renderLicenses(state.licenses || []);
          renderActivations(state.activations || []);
          renderAudit(state.audit || []);
        }

        function renderStats(summary) {
          const cards = [
            ['授权总数', summary.licenseCount],
            ['有效授权', summary.activeLicenseCount],
            ['设备总数', summary.activationCount],
            ['在线设备', summary.activeActivationCount],
            ['已吊销', summary.revokedLicenseCount]
          ];
          el('stats').innerHTML = cards.map(([label, value]) => '<div class="stat glass"><span>' + h(label) + '</span><strong>' + h(value) + '</strong></div>').join('');
        }

        function renderLicenses(licenses) {
          el('license-count').textContent = licenses.length + ' 条';
          el('licenses-body').innerHTML = licenses.length ? licenses.map(license => {
            const code = h(license.activationCode);
            return '<tr>' +
              '<td>' + tag(license.status) + '</td>' +
              '<td><strong>' + h(license.customerName || '-') + '</strong><br><span class="muted mono">' + h(license.licenseId) + '</span></td>' +
              '<td><span class="mono">' + code + '</span></td>' +
              '<td>' + h(license.maxDevices) + '</td>' +
              '<td>' + h(fmt(license.expiresAt)) + '</td>' +
              '<td><div class="row-actions">' +
                '<button class="btn btn-ghost mini" data-copy="' + code + '">复制</button>' +
                (license.status === 'active' ? '<button class="btn btn-ghost mini danger" data-revoke-license="' + h(license.licenseId) + '">吊销</button>' : '') +
              '</div></td>' +
            '</tr>';
          }).join('') : '<tr><td colspan="6">暂无授权。</td></tr>';
        }

        function renderActivations(activations) {
          el('activation-count').textContent = activations.length + ' 条';
          el('activations-body').innerHTML = activations.length ? activations.map(activation =>
            '<tr>' +
              '<td>' + tag(activation.status) + '</td>' +
              '<td class="mono">' + h(activation.activationId) + '</td>' +
              '<td class="mono">' + h(activation.licenseId) + '</td>' +
              '<td>' + h(activation.extensionVersion) + '<br><span class="muted mono">' + h(activation.extensionId) + '</span></td>' +
              '<td>' + h(fmt(activation.lastSeenAt || activation.createdAt)) + '</td>' +
              '<td>' + (activation.status === 'active' ? '<button class="btn btn-ghost mini danger" data-revoke-activation="' + h(activation.activationId) + '">吊销设备</button>' : '-') + '</td>' +
            '</tr>'
          ).join('') : '<tr><td colspan="6">暂无设备激活。</td></tr>';
        }

        function renderAudit(audit) {
          el('audit-body').innerHTML = audit.length ? audit.map(item =>
            '<tr><td>' + h(fmt(item.at)) + '</td><td>' + h(item.event) + '</td><td><pre><code>' + h(JSON.stringify(item.details || {}, null, 2)) + '</code></pre></td></tr>'
          ).join('') : '<tr><td colspan="3">暂无日志。</td></tr>';
        }

        el('save-token').addEventListener('click', async () => {
          localStorage.setItem('miaomiaoAdminToken', token());
          try { await loadState(); } catch (error) { alert(error.message); }
        });
        el('clear-token').addEventListener('click', () => {
          localStorage.removeItem('miaomiaoAdminToken');
          tokenInput.value = '';
        });
        el('refresh-state').addEventListener('click', () => loadState().catch(error => alert(error.message)));

        el('issue-form').addEventListener('submit', async event => {
          event.preventDefault();
          const form = new FormData(event.currentTarget);
          const body = Object.fromEntries(form.entries());
          body.days = Number(body.days || 30);
          body.maxDevices = Number(body.maxDevices || 1);
          el('issue-result').textContent = '生成中...';
          try {
            const data = await adminApi('/api/v1/admin/issue', { method:'POST', body:JSON.stringify(body) });
            el('issue-result').textContent = '授权码：' + data.license.activationCode + '\\n到期：' + fmt(data.license.expiresAt) + '\\n授权编号：' + data.license.licenseId;
            await navigator.clipboard.writeText(data.license.activationCode).catch(() => {});
            await loadState();
          } catch (error) {
            el('issue-result').textContent = '失败：' + error.message;
          }
        });

        el('activate-form').addEventListener('submit', async event => {
          event.preventDefault();
          const body = Object.fromEntries(new FormData(event.currentTarget).entries());
          body.action = 'START_BATCH';
          el('activate-result').textContent = '激活中...';
          try {
            const data = await publicApi('/api/v1/activate', body);
            el('activate-result').textContent = '激活成功\\n激活编号：' + data.activation.activationId + '\\n授权编号：' + data.license.licenseId + '\\n执行票据：' + data.runToken.slice(0, 48) + '...';
            await loadState().catch(() => {});
          } catch (error) {
            el('activate-result').textContent = '失败：' + error.message;
          }
        });

        document.addEventListener('click', async event => {
          const copy = event.target.closest('[data-copy]');
          if (copy) {
            await navigator.clipboard.writeText(copy.dataset.copy);
            copy.textContent = '已复制';
            setTimeout(() => copy.textContent = '复制', 1000);
            return;
          }
          const licenseButton = event.target.closest('[data-revoke-license]');
          if (licenseButton && confirm('确认吊销这个授权？')) {
            await adminApi('/api/v1/admin/revoke', { method:'POST', body:JSON.stringify({ licenseId: licenseButton.dataset.revokeLicense, reason:'admin-ui' }) });
            await loadState();
            return;
          }
          const activationButton = event.target.closest('[data-revoke-activation]');
          if (activationButton && confirm('确认吊销这个设备？')) {
            await adminApi('/api/v1/admin/revoke', { method:'POST', body:JSON.stringify({ activationId: activationButton.dataset.revokeActivation, reason:'admin-ui' }) });
            await loadState();
          }
        });

        if (saved) loadState().catch(() => {});
      </script>`
  });
}

export function renderDownload({ config, release }) {
  const sizeMb = (release.sizeBytes / 1024 / 1024).toFixed(2);
  return pageShell({
    title: '下载妙妙工具',
    active: 'download',
    body: `
      <style>
        .download-wrap{display:grid;gap:16px;width:100%;max-width:100%;min-width:0;margin-top:-24px}
        .download-wrap>*{min-width:0}
        .download-hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,360px);gap:18px;align-items:stretch;width:100%;max-width:100%;min-width:0}
        .download-card{width:100%;max-width:100%;padding:24px;min-width:0}
        .download-card h2{font-size:30px;margin-bottom:10px}
        .download-copy{font-family:var(--serif);font-size:17px;line-height:1.82;color:#e8e8e8;margin:0;overflow-wrap:anywhere}
        .release-name{font-size:16px;font-weight:700;margin:0 0 14px}
        .release-meta{display:grid;gap:12px;margin:0}
        .release-meta div{display:grid;gap:5px;border-bottom:1px solid rgba(255,255,255,.12);padding-bottom:12px}
        .release-meta div:last-child{border-bottom:0;padding-bottom:0}
        .release-meta dt{font-size:10px;color:var(--mist);text-transform:uppercase}
        .release-meta dd{font-size:13px;line-height:1.48;margin:0;word-break:break-all}
        .download-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:26px}
        .steps{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;width:100%;max-width:100%;min-width:0}
        .step{padding:24px;min-height:190px;min-width:0}
        .step span{display:block;color:var(--mist);font-size:10px;margin-bottom:34px}
        .step h3{font-size:16px;margin:0 0 12px}
        .step p{font-family:var(--serif);font-size:16px;line-height:1.76;color:#e8e8e8;margin:0}
        .checksum{padding:24px;min-width:0}
        .checksum pre{margin-top:14px}
        @media(max-width:920px){
          .download-hero,.steps{grid-template-columns:minmax(0,1fr)}
          .download-actions{display:grid;grid-template-columns:minmax(0,1fr)}
          .download-actions .btn{width:100%;padding-left:12px;padding-right:12px}
        }
      </style>
      <section class="download-wrap" aria-label="扩展下载">
        <div class="download-hero">
          <div class="download-card glass">
            <p class="eyebrow">插件版本</p>
            <h1 class="hero-title"><span>下载妙妙工具</span></h1>
            <p class="download-copy">这是接入喵帕斯在线授权服务的客户包。下载后在 Chrome 或 Edge 的扩展管理页加载即可测试授权激活。</p>
            <div class="download-actions">
              <a class="btn btn-primary" href="${escapeHtml(release.downloadPath)}" download>下载安装包</a>
              <a class="btn btn-ghost" href="/admin">打开控制台</a>
              <a class="btn btn-ghost" href="/api/v1/releases/latest">查看版本数据</a>
            </div>
          </div>
          <div class="download-card glass">
            <p class="release-name">${escapeHtml(release.name)}</p>
            <dl class="release-meta">
              <div><dt>版本</dt><dd>${escapeHtml(release.version)}</dd></div>
              <div><dt>渠道</dt><dd>${escapeHtml(release.channel)}</dd></div>
              <div><dt>大小</dt><dd>${escapeHtml(sizeMb)} MB</dd></div>
              <div><dt>接口地址</dt><dd>${escapeHtml(release.apiBase)}</dd></div>
              <div><dt>更新时间</dt><dd>${escapeHtml(new Date(release.updatedAt).toLocaleString('zh-CN', { hour12:false }))}</dd></div>
            </dl>
          </div>
        </div>

        <section class="steps" aria-label="安装步骤">
          <article class="step glass"><span>01</span><h3>下载安装包</h3><p>点击下载按钮，把扩展包保存到本地。建议先保留原始安装包作为交付备份。</p></article>
          <article class="step glass"><span>02</span><h3>解压并加载</h3><p>打开 Chrome/Edge 扩展管理页，启用开发者模式，选择解压后的扩展目录。</p></article>
          <article class="step glass"><span>03</span><h3>输入激活码</h3><p>在扩展侧边栏输入 MM 开头的授权码，服务端会绑定设备并签发执行票据。</p></article>
        </section>

        <section class="checksum glass">
          <p class="eyebrow">安装包校验</p>
          <h2>校验信息</h2>
          <pre><code>文件：${escapeHtml(release.fileName)}
校验值：${escapeHtml(release.sha256)}
下载地址：${escapeHtml(release.downloadUrl)}</code></pre>
        </section>
      </section>`
  });
}

function pageShell({ title, active, body }) {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>
    :root{
      --void:#000;
      --white:#fff;
      --mist:#c6c6c6;
      --fog:#999;
      --smoke:#808080;
      --border:#4d4d4d;
      --violet:#343755;
      --glass:rgba(0,0,0,.52);
      --wash:rgba(255,255,255,.08);
      --sans:"Space Grotesk","Inter","Segoe UI",Arial,sans-serif;
      --serif:"Times New Roman",Georgia,serif;
    }
    *{box-sizing:border-box}
    html,body{min-height:100%;margin:0;background:var(--void);color:var(--white)}
    body{font-family:var(--sans);overflow-x:hidden}
    body::selection{background:#343755;color:#fff}
    #scene{position:fixed;inset:0;width:100%;height:100%;z-index:0;background:#000}
    .vignette{position:fixed;inset:0;z-index:1;pointer-events:none;background:
      radial-gradient(circle at 50% 42%, rgba(160,172,255,.14), transparent 20rem),
      radial-gradient(circle at 14% 12%, rgba(74,145,129,.18), transparent 22rem),
      linear-gradient(180deg, rgba(0,0,0,.2), #000 82%)}
    .shell{position:relative;z-index:2;min-height:100vh;padding:28px clamp(18px,4vw,56px) 42px}
    header{display:flex;align-items:center;justify-content:space-between;gap:16px}
    .brand{display:flex;align-items:center;gap:12px;text-decoration:none;color:#fff}
    .mark{width:36px;height:36px;border:1px solid rgba(255,255,255,.48);border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.06);backdrop-filter:blur(4px)}
    .mark::before{content:"";width:12px;height:12px;border:1px solid #fff;transform:rotate(45deg)}
    .brand-text{display:flex;flex-direction:column;gap:2px}
    .brand-text strong{font-size:14px;line-height:1.2}
    .brand-text span{font-size:10px;color:var(--mist);line-height:1.5}
    nav{display:flex;align-items:center;gap:6px}
    nav a{color:#fff;text-decoration:none;border:1px solid rgba(255,255,255,.52);border-radius:5px;padding:3px 8px;font-size:11px;line-height:1.2;background:rgba(0,0,0,.18);backdrop-filter:blur(4px)}
    nav a.active{background:rgba(255,255,255,.12)}
    main{max-width:1180px;width:100%;margin:0 auto;padding-top:12vh}
    .hero{min-height:52vh;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,360px);gap:32px;align-items:center}
    .hero.compact{min-height:38vh}
    .hero-copy{max-width:660px}
    .eyebrow{margin:0 0 13px;color:var(--mist);font-size:10px;line-height:1.5;text-transform:uppercase}
    h1{font-family:var(--serif);font-weight:400;font-size:clamp(46px,7.4vw,108px);line-height:.94;margin:0 0 22px;letter-spacing:0}
    .hero-title span{display:block}
    h2{font-family:var(--serif);font-size:32px;font-weight:400;line-height:1.1;margin:0}
    .lede{font-family:var(--serif);font-size:18px;line-height:1.88;color:#eee;max-width:610px;margin:0}
    .actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:28px}
    .btn{display:inline-flex;align-items:center;justify-content:center;min-height:34px;max-width:100%;border-radius:500px;padding:6px 20px;font-size:14px;line-height:1.2;font-weight:700;text-align:center;text-decoration:none;border:1px solid rgba(255,255,255,.62);cursor:pointer}
    .btn-primary{background:var(--violet);border-color:var(--violet);color:#fff}
    .btn-ghost{background:rgba(0,0,0,.34);color:#fff;backdrop-filter:blur(4px)}
    .glass{min-width:0;border:1px solid var(--border);border-radius:12px;background:var(--glass);backdrop-filter:blur(4px)}
    .status-panel{padding:28px;min-width:0}
    .panel-head{display:flex;align-items:center;gap:9px;color:#fff;font-size:10px;line-height:1.5;margin-bottom:22px;text-transform:uppercase}
    .pulse{width:8px;height:8px;border-radius:50%;background:#fff;box-shadow:0 0 22px rgba(255,255,255,.9)}
    .metrics{display:grid;gap:16px;margin:0}
    .metrics div{display:grid;gap:6px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.14)}
    .metrics div:last-child{border-bottom:0;padding-bottom:0}
    dt{font-size:10px;color:var(--mist);text-transform:uppercase}
    dd{margin:0;font-size:14px;line-height:1.5;word-break:break-word}
    .grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:20px}
    .feature{padding:28px;min-height:210px}
    .feature .num{color:var(--mist);font-size:10px;margin-bottom:42px}
    .feature h3{margin:0 0 14px;font-size:16px;line-height:1.2}
    .feature p{font-family:var(--serif);font-size:16px;line-height:1.88;margin:0;color:#e8e8e8}
    .console{display:grid;grid-template-columns:280px 1fr;gap:24px;padding:28px;margin-top:14px}
    .endpoint-list{display:grid;gap:8px}
    .endpoint{display:grid;grid-template-columns:70px 1fr auto;gap:12px;align-items:center;border:1px solid rgba(255,255,255,.12);border-radius:5px;padding:10px 12px;background:rgba(255,255,255,.05)}
    .method{font-size:10px;color:#fff}
    .path{font-family:Consolas,"SFMono-Regular",monospace;font-size:13px;color:#fff;overflow-wrap:anywhere}
    .desc{font-size:12px;color:var(--mist)}
    .key-card{padding:28px;margin-top:16px}
    .key-toolbar{display:flex;justify-content:space-between;gap:20px;align-items:start;margin-bottom:18px}
    pre{max-width:100%;margin:0;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;border:1px solid rgba(255,255,255,.14);border-radius:8px;background:rgba(255,255,255,.06);padding:18px;max-height:420px}
    code{font-family:Consolas,"SFMono-Regular",monospace;font-size:13px;line-height:1.65;color:#f4f4f4;overflow-wrap:anywhere}
    footer{max-width:1180px;margin:38px auto 0;color:var(--mist);font-size:10px;line-height:1.5;display:flex;justify-content:space-between;gap:16px}
    @media (max-width:880px){
      .shell{padding:20px 16px 32px}
      header{align-items:flex-start;flex-direction:column}
      nav{width:100%;flex-wrap:wrap;justify-content:flex-start}
      main{padding-top:56px}
      .hero,.hero.compact{grid-template-columns:1fr;min-height:auto}
      .grid{grid-template-columns:1fr}
      .console{grid-template-columns:1fr}
      h1{font-size:44px;line-height:1}
      .endpoint{grid-template-columns:1fr;gap:6px}
      footer{flex-direction:column}
    }
  </style>
</head>
<body>
  <canvas id="scene" aria-hidden="true"></canvas>
  <div class="vignette" aria-hidden="true"></div>
  <div class="shell">
    <header>
      <a class="brand" href="/">
        <span class="mark" aria-hidden="true"></span>
        <span class="brand-text"><strong>妙妙授权服务</strong><span>授权网关</span></span>
      </a>
      <nav aria-label="授权服务导航">
        <a class="${active === 'overview' ? 'active' : ''}" href="/">概览</a>
        <a class="${active === 'download' ? 'active' : ''}" href="/download">下载</a>
        <a class="${active === 'admin' ? 'active' : ''}" href="/admin">后台</a>
        <a class="${active === 'key' ? 'active' : ''}" href="/api/v1/public-key">公钥</a>
        <a href="/health">状态</a>
      </nav>
    </header>
    <main>${body}</main>
    <footer>
      <span>喵帕斯.top · 加密隧道 · 短期执行票据</span>
      <span>签名私钥只保存在服务端。</span>
    </footer>
  </div>
  <script>
    const canvas=document.getElementById('scene');
    const ctx=canvas.getContext('2d');
    let w=0,h=0,dpr=1,particles=[];
    function resize(){
      dpr=Math.min(window.devicePixelRatio||1,2);
      w=canvas.width=Math.floor(innerWidth*dpr);
      h=canvas.height=Math.floor(innerHeight*dpr);
      canvas.style.width=innerWidth+'px';
      canvas.style.height=innerHeight+'px';
      particles=Array.from({length:Math.min(150,Math.floor(innerWidth/9))},()=>({
        x:Math.random()*w,
        y:Math.random()*h,
        r:(Math.random()*1.7+.45)*dpr,
        a:Math.random()*Math.PI*2,
        s:(Math.random()*.32+.08)*dpr
      }));
    }
    function draw(t){
      ctx.clearRect(0,0,w,h);
      ctx.fillStyle='#000';
      ctx.fillRect(0,0,w,h);
      const cx=w*.5,cy=h*.43;
      const radius=Math.min(w,h)*.16;
      const glow=ctx.createRadialGradient(cx,cy,radius*.25,cx,cy,radius*2.3);
      glow.addColorStop(0,'rgba(138,150,255,.28)');
      glow.addColorStop(.36,'rgba(52,55,85,.18)');
      glow.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle=glow;
      ctx.beginPath();
      ctx.arc(cx,cy,radius*2.3,0,Math.PI*2);
      ctx.fill();
      ctx.save();
      ctx.translate(cx,cy);
      ctx.rotate(t*.00008);
      ctx.strokeStyle='rgba(255,255,255,.72)';
      ctx.lineWidth=1*dpr;
      for(let i=0;i<3;i++){
        ctx.beginPath();
        ctx.ellipse(0,0,radius*(1+i*.08),radius*(.72+i*.06),i*.52,0,Math.PI*2);
        ctx.stroke();
      }
      ctx.restore();
      for(const p of particles){
        p.a+=p.s*.01;
        p.y+=Math.sin(p.a)*.1*dpr+p.s*.12;
        if(p.y>h+20*dpr){p.y=-20*dpr;p.x=Math.random()*w}
        ctx.fillStyle='rgba(210,214,255,.72)';
        ctx.beginPath();
        ctx.arc(p.x+Math.cos(p.a)*8*dpr,p.y,p.r,0,Math.PI*2);
        ctx.fill();
      }
      requestAnimationFrame(draw);
    }
    resize();
    addEventListener('resize',resize);
    requestAnimationFrame(draw);
    document.querySelectorAll('[data-copy]').forEach(btn=>{
      btn.addEventListener('click',async()=>{
        const node=document.getElementById(btn.dataset.copy);
        if(!node)return;
        await navigator.clipboard.writeText(node.innerText);
        const old=btn.textContent;
        btn.textContent='已复制';
        setTimeout(()=>btn.textContent=old,1200);
      });
    });
  </script>
</body>
</html>`;
}

function featureCard(num, title, copy) {
  return `<article class="feature glass">
    <div class="num">${escapeHtml(num)}</div>
    <h3>${escapeHtml(title)}</h3>
    <p>${escapeHtml(copy)}</p>
  </article>`;
}

function endpoint(method, path, desc) {
  return `<div class="endpoint">
    <span class="method">${escapeHtml(method)}</span>
    <span class="path">${escapeHtml(path)}</span>
    <span class="desc">${escapeHtml(desc)}</span>
  </div>`;
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
