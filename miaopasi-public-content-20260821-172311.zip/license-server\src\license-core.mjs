import {
  addDaysIso,
  addSecondsIso,
  assertVersionAtLeast,
  isExpired,
  machineHash,
  nowIso,
  publicLicenseView,
  randomActivationCode,
  randomDownloadCode,
  randomId,
  requireField,
  sha256Hex
} from './util.mjs';
import { appendAudit } from './store.mjs';
import { signToken, verifyToken } from './signing.mjs';
import {
  isKnownProductId,
  normalizeProductId,
  productAllowsExtension,
  productById
} from './products.mjs';

function publicActivationView(activation) {
  if (!activation) return null;
  const { refreshTokenHash, machineHash, deviceHash, profileHash, ...rest } = activation;
  return rest;
}

function activeLicenseOrThrow(license) {
  if (!license) throw httpError(404, 'license_not_found', 'license not found');
  if (license.status !== 'active') throw httpError(403, 'license_inactive', 'license is not active');
  if (isExpired(license.expiresAt)) throw httpError(403, 'license_expired', 'license expired');
  return license;
}

function assertExtensionAllowed(config, extensionId, extensionVersion, productId = '') {
  const ids = Array.isArray(config.allowedExtensionIds) ? config.allowedExtensionIds.filter(Boolean) : [];
  if (ids.length && !ids.includes(extensionId)) {
    throw httpError(403, 'extension_not_allowed', 'extension id is not allowed');
  }
  if (productId && !productAllowsExtension(config, productId, extensionId)) {
    throw httpError(403, 'product_mismatch', 'extension is not allowed for this product');
  }
  if (!assertVersionAtLeast(extensionVersion, minExtensionVersionFor(config, extensionId))) {
    throw httpError(403, 'extension_version_blocked', 'extension version is below minimum');
  }
}

function minExtensionVersionFor(config, extensionId) {
  const rules = config.extensionMinVersions && typeof config.extensionMinVersions === 'object'
    ? config.extensionMinVersions
    : {};
  return String(rules[extensionId] || config.minExtensionVersion || '').trim();
}

export function httpError(status, code, message) {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  return error;
}

export function createLicenseRecord(db, options = {}, config = {}) {
  const days = Math.max(1, Number(options.durationDays || options.days || 30));
  const maxDevices = Math.max(1, Number(options.maxDevices || 1));
  const maxProfilesPerDevice = Math.max(1, Number(options.maxProfilesPerDevice || config.defaultMaxProfilesPerDevice || 20));
  const startOnActivation = options.startOnActivation !== false;
  const now = nowIso();
  const customerId = options.customerId || randomId('cus_', 8);
  const licenseId = options.licenseId || randomId('lic_', 10);
  const license = {
    licenseId,
    productId: options.productId || config.productId || 'miaomiao-flow',
    customerId,
    customerName: options.customerName || options.customer || '',
    contact: options.contact || '',
    activationCode: options.activationCode || randomActivationCode(),
    maxDevices,
    maxProfilesPerDevice,
    days,
    startOnActivation,
    status: startOnActivation ? 'pending' : 'active',
    validFrom: startOnActivation ? null : now,
    expiresAt: startOnActivation ? null : (options.expiresAt || addDaysIso(days)),
    source: options.source || 'manual',
    batchId: options.batchId || '',
    batchName: options.batchName || '',
    batchIndex: Number.isInteger(Number(options.batchIndex)) ? Number(options.batchIndex) : null,
    planLabel: String(options.planLabel || '').trim(),
    notes: options.notes || '',
    createdAt: now,
    updatedAt: now
  };
  if (Object.values(db.licenses).some((item) => item.activationCode === license.activationCode)) {
    throw httpError(409, 'activation_code_exists', 'activation code already exists');
  }
  db.licenses[license.licenseId] = license;
  appendAudit(db, 'license.issued', {
    licenseId: license.licenseId,
    customerId: license.customerId,
    status: license.status,
    expiresAt: license.expiresAt || null,
    startOnActivation: license.startOnActivation,
    days: license.days,
    maxDevices: license.maxDevices,
    maxProfilesPerDevice: license.maxProfilesPerDevice
  });
  return license;
}

export async function issueLicense(store, options = {}, config = {}) {
  return store.mutate((db) => createLicenseRecord(db, options, config));
}

const BATCH_PLANS = Object.freeze({
  trial7: { key: 'trial7', label: '7天体验', days: 7 },
  month1: { key: 'month1', label: '1个月', days: 30 },
  month2: { key: 'month2', label: '2个月', days: 60 },
  month3: { key: 'month3', label: '3个月', days: 90 },
  month4: { key: 'month4', label: '4个月', days: 120 },
  month5: { key: 'month5', label: '5个月', days: 150 },
  month6: { key: 'month6', label: '6个月', days: 180 },
  month7: { key: 'month7', label: '7个月', days: 210 },
  month8: { key: 'month8', label: '8个月', days: 240 },
  month9: { key: 'month9', label: '9个月', days: 270 },
  month10: { key: 'month10', label: '10个月', days: 300 },
  month11: { key: 'month11', label: '11个月', days: 330 },
  month12: { key: 'month12', label: '12个月', days: 365 }
});

export function resolveBatchPlan(plan = 'month1', daysOverride = 0) {
  if (Number(daysOverride) > 0) {
    return { key: 'custom', label: String(Number(daysOverride)) + '天', days: Number(daysOverride) };
  }
  const raw = String(plan || '').trim().toLowerCase();
  const aliases = {
    '7': 'trial7', '7d': 'trial7', 'trial': 'trial7', 'trial7': 'trial7', '体验': 'trial7', '7天': 'trial7',
    '1': 'month1', '1m': 'month1', 'month1': 'month1', '1个月': 'month1',
    '2': 'month2', '2m': 'month2', 'month2': 'month2', '2个月': 'month2',
    '3': 'month3', '3m': 'month3', 'month3': 'month3', '3个月': 'month3',
    '4': 'month4', '4m': 'month4', 'month4': 'month4', '4个月': 'month4',
    '5': 'month5', '5m': 'month5', 'month5': 'month5', '5个月': 'month5',
    '6': 'month6', '6m': 'month6', 'month6': 'month6', '6个月': 'month6',
    '7m': 'month7', 'month7': 'month7', '7个月': 'month7',
    '8m': 'month8', 'month8': 'month8', '8个月': 'month8',
    '9m': 'month9', 'month9': 'month9', '9个月': 'month9',
    '10m': 'month10', 'month10': 'month10', '10个月': 'month10',
    '11m': 'month11', 'month11': 'month11', '11个月': 'month11',
    '12m': 'month12', 'month12': 'month12', '12个月': 'month12', '12': 'month12'
  };
  return BATCH_PLANS[aliases[raw] || raw] || BATCH_PLANS.month1;
}

export function createDownloadCodeRecord(db, license, config = {}, options = {}) {
  let code = String(options.code || '').trim().toUpperCase();
  for (let attempt = 0; attempt < 10; attempt += 1) {
    if (!code) code = randomDownloadCode();
    const exists = Object.values(db.downloadCodes || {}).some((item) => item.code === code);
    if (!exists) break;
    code = '';
  }
  if (!code || Object.values(db.downloadCodes || {}).some((item) => item.code === code)) {
    throw httpError(409, 'download_code_collision', 'download code collision');
  }
  const downloadCode = {
    downloadCodeId: randomId('dcode_', 8),
    code,
    status: 'active',
    licenseId: license.licenseId,
    customerId: license.customerId || '',
    customerName: license.customerName || '',
    contact: license.contact || '',
    productId: license.productId || normalizeProductId(config, options.productId),
    notes: String(options.notes || '').trim(),
    downloadCount: 0,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    expiresAt: options.expiresAt || license.expiresAt || ''
  };
  db.downloadCodes[downloadCode.downloadCodeId] = downloadCode;
  appendAudit(db, 'download_code.issued', {
    downloadCodeId: downloadCode.downloadCodeId,
    licenseId: downloadCode.licenseId,
    productId: downloadCode.productId
  });
  return downloadCode;
}

export async function issueBatchLicenses(store, options = {}, config = {}) {
  const name = String(options.name || '').trim();
  if (!name) throw httpError(400, 'batch_name_required', 'batch name is required');
  const plan = resolveBatchPlan(options.plan || 'month1', options.days || 0);
  const count = Math.max(1, Math.min(Number(options.count || 1), 5000));
  const maxDevices = Math.max(1, Number(options.maxDevices || 1));
  const maxProfilesPerDevice = Math.max(1, Number(options.maxProfilesPerDevice || config.defaultMaxProfilesPerDevice || 20));
  const productId = normalizeProductId(config, options.productId);
  const batchId = options.batchId || randomId('bat_', 8);
  const now = nowIso();
  return store.mutate((db) => {
    const batch = {
      batchId,
      name,
      productId,
      planLabel: plan.label,
      durationDays: plan.days,
      maxDevices,
      maxProfilesPerDevice,
      count,
      status: 'active',
      notes: String(options.notes || '').trim(),
      createdAt: now,
      updatedAt: now
    };
    db.batches[batchId] = batch;
    const items = [];
    for (let index = 1; index <= count; index += 1) {
      const customerName = name + index;
      const license = createLicenseRecord(db, {
        productId,
        customerName,
        customerId: 'batch:' + batchId + ':' + index,
        days: plan.days,
        durationDays: plan.days,
        startOnActivation: true,
        source: 'batch',
        batchId,
        batchName: name,
        batchIndex: index,
        planLabel: plan.label,
        maxDevices,
        maxProfilesPerDevice,
        notes: 'batch:' + name + ' #' + index
      }, config);
      const downloadCode = createDownloadCodeRecord(db, license, config, {
        notes: 'batch:' + name + ' #' + index
      });
      items.push({ license: { ...license }, downloadCode: { ...downloadCode } });
    }
    appendAudit(db, 'batch.issued', {
      batchId,
      name,
      productId,
      planLabel: plan.label,
      durationDays: plan.days,
      count,
      maxDevices,
      maxProfilesPerDevice
    });
    return { batch: { ...batch }, items };
  });
}


export async function activateLicense({ store, privateJwk, config, body }) {
  const activationCode = requireField(body, 'activationCode');
  const machineId = requireField(body, 'machineId');
  const extensionId = requireField(body, 'extensionId');
  const extensionVersion = requireField(body, 'extensionVersion');
  const productId = normalizeProductId(config, body.productId, extensionId);
  assertExtensionAllowed(config, extensionId, extensionVersion, productId);
  const normalizedHash = machineHash(machineId, process.env.LICENSE_MACHINE_PEPPER || '');
  const deviceHash = machineHash(body.deviceId || machineId, process.env.LICENSE_MACHINE_PEPPER || '');
  const profileHash = machineHash(body.profileId || machineId, process.env.LICENSE_MACHINE_PEPPER || '');
  const profileLabel = normalizeProfileLabel(body.profileLabel);
  const refreshToken = randomId('rt_', 32);
  const refreshTokenHash = sha256Hex(refreshToken);

  const result = await store.mutate((db) => {
    const license = Object.values(db.licenses).find((item) => item.activationCode === activationCode);
    if (!license) throw httpError(404, 'license_not_found', 'license not found');
    if (license.status === 'pending' && license.startOnActivation !== false) {
      const activationNow = nowIso();
      license.status = 'active';
      license.validFrom = activationNow;
      license.expiresAt = addDaysIso(Math.max(1, Number(license.days || 30)));
      license.updatedAt = activationNow;
      appendAudit(db, 'license.activated', {
        licenseId: license.licenseId,
        validFrom: license.validFrom,
        expiresAt: license.expiresAt,
        days: license.days
      });
    }
    activeLicenseOrThrow(license);
    if (license.productId !== productId) {
      throw httpError(403, 'product_mismatch', 'license product mismatch');
    }
    let activation = Object.values(db.activations).find((item) => (
      item.licenseId === license.licenseId &&
      activationDeviceKey(item) === deviceHash &&
      activationProfileKey(item) === profileHash &&
      item.status === 'active'
    )) || Object.values(db.activations).find((item) => (
      item.licenseId === license.licenseId &&
      item.machineHash === normalizedHash &&
      item.status === 'active'
    ));
    if (!activation) {
      const activeActivations = Object.values(db.activations).filter((item) => (
        item.licenseId === license.licenseId &&
        item.status === 'active'
      ));
      const activeDeviceHashes = new Set(activeActivations.map(activationDeviceKey));
      const deviceAlreadyActive = activeDeviceHashes.has(deviceHash);
      if (!deviceAlreadyActive && activeDeviceHashes.size >= license.maxDevices) {
        throw httpError(403, 'device_limit_reached', 'device limit reached');
      }
      const profileCountOnDevice = activeActivations
        .filter((item) => activationDeviceKey(item) === deviceHash)
        .length;
      if (profileCountOnDevice >= maxProfilesPerDeviceForLicense(license, config)) {
        throw httpError(403, 'profile_limit_reached', 'profile limit reached for this device');
      }
      activation = {
        activationId: randomId('act_', 10),
        licenseId: license.licenseId,
        customerId: license.customerId,
        productId: license.productId,
        machineHash: normalizedHash,
        deviceHash,
        profileHash,
        profileLabel,
        extensionId,
        extensionVersion,
        status: 'active',
        refreshTokenHash,
        createdAt: nowIso(),
        lastSeenAt: nowIso(),
        revokedAt: null,
        revokeReason: ''
      };
      db.activations[activation.activationId] = activation;
      appendAudit(db, 'activation.created', {
        activationId: activation.activationId,
        licenseId: license.licenseId,
        extensionId,
        extensionVersion,
        deviceAdded: !deviceAlreadyActive,
        profileCountOnDevice: profileCountOnDevice + 1
      });
    } else {
      activation.refreshTokenHash = refreshTokenHash;
      activation.machineHash = normalizedHash;
      if (activationDeviceKey(activation) !== deviceHash) {
        assertDeviceMoveAllowed(db, license, activation, deviceHash, config);
        activation.deviceHash = deviceHash;
      } else {
        activation.deviceHash = activation.deviceHash || deviceHash;
      }
      activation.profileHash = activation.profileHash || profileHash;
      if (profileLabel) activation.profileLabel = profileLabel;
      activation.extensionId = extensionId;
      activation.extensionVersion = extensionVersion;
      activation.lastSeenAt = nowIso();
      appendAudit(db, 'activation.refreshed_secret', {
        activationId: activation.activationId,
        licenseId: license.licenseId
      });
    }
    return { license, activation };
  });

  return {
    ok: true,
    refreshToken,
    runToken: issueRunToken(privateJwk, config, result.license, result.activation, body.action || 'START_BATCH'),
    license: publicLicenseView(result.license),
    activation: publicActivationView(result.activation)
  };
}

export async function restoreDeviceLicense({ store, privateJwk, config, body }) {
  const machineId = requireField(body, 'machineId');
  const deviceId = requireField(body, 'deviceId');
  const profileId = requireField(body, 'profileId');
  const extensionId = requireField(body, 'extensionId');
  const extensionVersion = requireField(body, 'extensionVersion');
  const productId = normalizeProductId(config, body.productId, extensionId);
  assertExtensionAllowed(config, extensionId, extensionVersion, productId);
  const pepper = process.env.LICENSE_MACHINE_PEPPER || '';
  const normalizedHash = machineHash(machineId, pepper);
  const deviceHash = machineHash(deviceId, pepper);
  const profileHash = machineHash(profileId, pepper);
  const profileLabel = normalizeProfileLabel(body.profileLabel);
  const refreshToken = randomId('rt_', 32);
  const refreshTokenHash = sha256Hex(refreshToken);

  const result = await store.mutate((db) => {
    const deviceActivations = Object.values(db.activations || {}).filter((item) => (
      item.status === 'active' && activationDeviceKey(item) === deviceHash
    ));
    const source = deviceActivations.find((item) => db.licenses?.[item.licenseId]?.productId === productId);
    const deviceAuthorization = Object.values(db.deviceAuthorizations || {}).find((item) => (
      item.status === 'active' && item.deviceHash === deviceHash && db.licenses?.[item.licenseId]?.productId === productId
    ));
    const licenseId = source?.licenseId || deviceAuthorization?.licenseId;
    if (!licenseId) throw httpError(404, 'device_license_not_found', 'no active license is registered for this device');
    const license = db.licenses[licenseId];
    activeLicenseOrThrow(license);
    let activation = deviceActivations.find((item) => (
      item.licenseId === license.licenseId && activationProfileKey(item) === profileHash
    ));
    if (!activation) {
      const activeProfiles = deviceActivations.filter((item) => item.licenseId === license.licenseId);
      if (activeProfiles.length >= maxProfilesPerDeviceForLicense(license, config)) {
        throw httpError(403, 'profile_limit_reached', 'profile limit reached for this device');
      }
      activation = {
        activationId: randomId('act_', 10), licenseId: license.licenseId,
        customerId: license.customerId, productId: license.productId,
        machineHash: normalizedHash, deviceHash, profileHash, profileLabel,
        extensionId, extensionVersion, status: 'active', refreshTokenHash,
        createdAt: nowIso(), lastSeenAt: nowIso(), revokedAt: null, revokeReason: ''
      };
      db.activations[activation.activationId] = activation;
      appendAudit(db, 'activation.device_restored', { activationId: activation.activationId, licenseId: license.licenseId });
    } else {
      activation.refreshTokenHash = refreshTokenHash;
      activation.machineHash = normalizedHash;
      activation.extensionId = extensionId;
      activation.extensionVersion = extensionVersion;
      activation.lastSeenAt = nowIso();
    }
    return { license, activation };
  });
  return {
    ok: true, refreshToken,
    runToken: issueRunToken(privateJwk, config, result.license, result.activation, body.action || 'START_BATCH'),
    license: publicLicenseView(result.license), activation: publicActivationView(result.activation)
  };
}

export async function refreshRunToken({ store, privateJwk, config, body }) {
  const refreshToken = requireField(body, 'refreshToken');
  const machineId = requireField(body, 'machineId');
  const action = body.action || 'START_BATCH';
  const nextExtensionId = String(body.extensionId || '').trim();
  const nextExtensionVersion = String(body.extensionVersion || '').trim();
  const normalizedHash = machineHash(machineId, process.env.LICENSE_MACHINE_PEPPER || '');
  const nextDeviceHash = body.deviceId
    ? machineHash(body.deviceId, process.env.LICENSE_MACHINE_PEPPER || '')
    : '';
  const nextProfileHash = body.profileId
    ? machineHash(body.profileId, process.env.LICENSE_MACHINE_PEPPER || '')
    : '';
  const nextProfileLabel = normalizeProfileLabel(body.profileLabel);
  const tokenHash = sha256Hex(refreshToken);
  const result = await store.mutate((db) => {
    const activation = Object.values(db.activations).find((item) => item.refreshTokenHash === tokenHash);
    if (!activation || activation.status !== 'active') {
      throw httpError(403, 'activation_inactive', 'activation is not active');
    }
    if (activation.machineHash !== normalizedHash) {
      throw httpError(403, 'machine_mismatch', 'machine mismatch');
    }
    const license = db.licenses[activation.licenseId];
    activeLicenseOrThrow(license);
    if (nextDeviceHash && nextDeviceHash !== activationDeviceKey(activation)) {
      assertDeviceMoveAllowed(db, license, activation, nextDeviceHash, config);
      activation.deviceHash = nextDeviceHash;
    } else {
      activation.deviceHash = activation.deviceHash || activation.machineHash;
    }
    activation.profileHash = nextProfileHash || activation.profileHash || activation.machineHash;
    if (nextProfileLabel) activation.profileLabel = nextProfileLabel;
    if (nextExtensionId || nextExtensionVersion) {
      const extensionId = nextExtensionId || activation.extensionId;
      const extensionVersion = nextExtensionVersion || activation.extensionVersion;
      assertExtensionAllowed(config, extensionId, extensionVersion, license.productId || activation.productId);
      if (activation.extensionId !== extensionId || activation.extensionVersion !== extensionVersion) {
        activation.extensionId = extensionId;
        activation.extensionVersion = extensionVersion;
        appendAudit(db, 'activation.version_refreshed', {
          activationId: activation.activationId,
          licenseId: license.licenseId,
          extensionId,
          extensionVersion
        });
      }
    }
    assertExtensionAllowed(config, activation.extensionId, activation.extensionVersion, license.productId || activation.productId);
    activation.lastSeenAt = nowIso();
    appendAudit(db, 'token.refreshed', {
      activationId: activation.activationId,
      licenseId: license.licenseId,
      action
    });
    return { license, activation };
  });
  return {
    ok: true,
    runToken: issueRunToken(privateJwk, config, result.license, result.activation, action),
    expiresInSeconds: config.tokenTtlSeconds,
    offlineGraceSeconds: config.offlineGraceSeconds
  };
}

export function maxProfilesPerDeviceForLicense(license, config = {}) {
  return Math.max(1, Number(license?.maxProfilesPerDevice || config.defaultMaxProfilesPerDevice || 20));
}

export async function validateRunToken({ store, publicJwk, config, body }) {
  const token = requireField(body, 'runToken');
  const action = body.action || '';
  const machineId = body.machineId || '';
  const checked = verifyToken(publicJwk, token);
  if (!checked.ok) throw httpError(403, checked.code, checked.error);
  const payload = checked.payload;
  if (payload.iss !== config.issuer || !isKnownProductId(config, payload.productId)) {
    throw httpError(403, 'token_scope', 'runToken scope mismatch');
  }
  assertExtensionAllowed(config, payload.extensionId, payload.extensionVersion, payload.productId);
  if (machineId) {
    const normalizedHash = machineHash(machineId, process.env.LICENSE_MACHINE_PEPPER || '');
    if (payload.machineHash !== normalizedHash) throw httpError(403, 'machine_mismatch', 'machine mismatch');
  }
  if (action && !payload.actions.includes('*') && !payload.actions.includes(action)) {
    throw httpError(403, 'action_not_allowed', 'action is not allowed by runToken');
  }
  const db = await store.read();
  const activation = db.activations[payload.activationId];
  if (!activation || activation.status !== 'active') throw httpError(403, 'activation_inactive', 'activation is not active');
  if (activation.productId && activation.productId !== payload.productId) throw httpError(403, 'token_scope', 'runToken activation scope mismatch');
  const license = db.licenses[payload.licenseId];
  activeLicenseOrThrow(license);
  if (license.productId !== payload.productId) throw httpError(403, 'token_scope', 'runToken license scope mismatch');
  return {
    ok: true,
    payload,
    license: publicLicenseView(license),
    activation: publicActivationView(activation)
  };
}

export async function revokeLicenseOrActivation(store, body) {
  const reason = body.reason || 'manual';
  return store.mutate((db) => {
    let changed = [];
    if (body.activationId) {
      const activation = db.activations[body.activationId];
      if (!activation) throw httpError(404, 'activation_not_found', 'activation not found');
      activation.status = 'revoked';
      activation.revokedAt = nowIso();
      activation.revokeReason = reason;
      changed.push({ type: 'activation', id: activation.activationId });
    }
    if (body.licenseId || body.activationCode) {
      const license = body.licenseId
        ? db.licenses[body.licenseId]
        : Object.values(db.licenses).find((item) => item.activationCode === body.activationCode);
      if (!license) throw httpError(404, 'license_not_found', 'license not found');
      license.status = 'revoked';
      license.updatedAt = nowIso();
      for (const activation of Object.values(db.activations)) {
        if (activation.licenseId === license.licenseId && activation.status === 'active') {
          activation.status = 'revoked';
          activation.revokedAt = nowIso();
          activation.revokeReason = reason;
          changed.push({ type: 'activation', id: activation.activationId });
        }
      }
      changed.push({ type: 'license', id: license.licenseId });
    }
    if (!changed.length) throw httpError(400, 'revoke_target_missing', 'revoke target is required');
    appendAudit(db, 'revoke', { reason, changed });
    return { ok: true, changed };
  });
}

export async function extendLicense(store, body) {
  const days = Math.max(1, Number(body.days || 30));
  const reason = body.reason || 'manual-renewal';
  return store.mutate((db) => {
    const license = findLicense(db, body);
    if (!license) throw httpError(404, 'license_not_found', 'license not found');
    if (license.status === 'banned' && !body.force) {
      throw httpError(403, 'license_banned', 'license is banned');
    }
    if (license.status === 'pending') {
      license.days = Math.max(1, Number(license.days || 30) + days);
      if (license.planLabel) license.planLabel = license.planLabel + '+' + days + '天';
      license.updatedAt = nowIso();
      appendAudit(db, 'license.extended', {
        licenseId: license.licenseId,
        customerId: license.customerId,
        days,
        pending: true,
        totalDays: license.days,
        reason
      });
      return { ok: true, license };
    }
    const now = Date.now();
    const currentExpiry = Date.parse(license.expiresAt || '');
    const base = Number.isFinite(currentExpiry) && currentExpiry > now ? currentExpiry : now;
    license.expiresAt = addDaysIso(days, base);
    if (license.status !== 'banned') license.status = 'active';
    license.updatedAt = nowIso();
    appendAudit(db, 'license.extended', {
      licenseId: license.licenseId,
      customerId: license.customerId,
      days,
      expiresAt: license.expiresAt,
      reason
    });
    return { ok: true, license };
  });
}

export async function banLicenseOrCustomer(store, body) {
  const reason = body.reason || 'manual-ban';
  return store.mutate((db) => {
    const targets = findLicenseTargets(db, body);
    if (!targets.length) throw httpError(404, 'license_not_found', 'license not found');
    const changed = [];
    for (const license of targets) {
      license.status = 'banned';
      license.bannedAt = nowIso();
      license.banReason = reason;
      license.updatedAt = nowIso();
      changed.push({ type: 'license', id: license.licenseId });
      for (const activation of Object.values(db.activations)) {
        if (activation.licenseId === license.licenseId && activation.status === 'active') {
          activation.status = 'revoked';
          activation.revokedAt = nowIso();
          activation.revokeReason = `banned: ${reason}`;
          changed.push({ type: 'activation', id: activation.activationId });
        }
      }
    }
    appendAudit(db, 'license.banned', { reason, changed });
    return { ok: true, changed };
  });
}

export async function deleteBannedLicense(store, body) {
  return store.mutate((db) => {
    const license = findLicense(db, body);
    if (!license) throw httpError(404, 'license_not_found', 'license not found');
    if (license.status !== 'banned') {
      throw httpError(403, 'license_delete_requires_banned', 'only banned licenses can be deleted');
    }
    const removedActivations = [];
    for (const [activationId, activation] of Object.entries(db.activations || {})) {
      if (activation.licenseId === license.licenseId) {
        delete db.activations[activationId];
        removedActivations.push(activationId);
      }
    }
    delete db.licenses[license.licenseId];
    appendAudit(db, 'license.deleted', {
      licenseId: license.licenseId,
      customerId: license.customerId,
      removedActivationCount: removedActivations.length
    });
    return {
      ok: true,
      deleted: {
        licenseId: license.licenseId,
        customerId: license.customerId,
        activationIds: removedActivations
      }
    };
  });
}

function findLicense(db, body) {
  return findLicenseTargets(db, body)[0] || null;
}

function findLicenseTargets(db, body) {
  if (body.licenseId) {
    const license = db.licenses[body.licenseId];
    return license ? [license] : [];
  }
  if (body.activationCode) {
    const license = Object.values(db.licenses).find((item) => item.activationCode === body.activationCode);
    return license ? [license] : [];
  }
  if (body.customerId) {
    return Object.values(db.licenses).filter((item) => item.customerId === body.customerId);
  }
  return [];
}

function issueRunToken(privateJwk, config, license, activation, action) {
  const now = Math.floor(Date.now() / 1000);
  const allowedActions = Array.isArray(config.allowedActions) && config.allowedActions.length
    ? config.allowedActions
    : ['*'];
  const actions = allowedActions.includes(action) ? [action] : allowedActions;
  return signToken(privateJwk, {
    typ: 'run',
    iss: config.issuer,
    productId: productById(config, license.productId)?.productId || license.productId || config.productId,
    licenseId: license.licenseId,
    activationId: activation.activationId,
    customerId: license.customerId,
    machineHash: activation.machineHash,
    deviceHash: activationDeviceKey(activation),
    profileHash: activationProfileKey(activation),
    extensionId: activation.extensionId,
    extensionVersion: activation.extensionVersion,
    minExtensionVersion: minExtensionVersionFor(config, activation.extensionId),
    actions,
    iat: now,
    exp: now + Number(config.tokenTtlSeconds || 3600),
    jti: randomId('jti_', 12)
  });
}

function activationDeviceKey(activation) {
  return activation?.deviceHash || activation?.machineHash || '';
}

function activationProfileKey(activation) {
  return activation?.profileHash || activation?.machineHash || '';
}

function assertDeviceMoveAllowed(db, license, activation, nextDeviceHash, config) {
  const activeActivations = Object.values(db.activations || {}).filter((item) => (
    item.licenseId === license.licenseId &&
    item.status === 'active' &&
    item.activationId !== activation.activationId
  ));
  const activeDeviceHashes = new Set(activeActivations.map(activationDeviceKey));
  if (!activeDeviceHashes.has(nextDeviceHash) && activeDeviceHashes.size >= license.maxDevices) {
    throw httpError(403, 'device_limit_reached', 'device limit reached');
  }
  const profileCountOnDevice = activeActivations
    .filter((item) => activationDeviceKey(item) === nextDeviceHash)
    .length;
  if (profileCountOnDevice >= maxProfilesPerDeviceForLicense(license, config)) {
    throw httpError(403, 'profile_limit_reached', 'profile limit reached for this device');
  }
}

function normalizeProfileLabel(value) {
  return String(value || '').trim().slice(0, 80);
}
