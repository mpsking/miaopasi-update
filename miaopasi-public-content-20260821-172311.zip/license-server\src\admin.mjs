#!/usr/bin/env node
import path from 'node:path';
import { promises as fs } from 'node:fs';
import { writeDefaultConfigIfMissing, loadConfig } from './config.mjs';
import { Store } from './store.mjs';
import { ensureSigningKeyPair, loadPublicJwk, signingPrivatePath, signingPublicPath } from './signing.mjs';
import { getDataDir, parseArgs, publicLicenseView } from './util.mjs';
import { issueBatchLicenses, issueLicense, revokeLicenseOrActivation } from './license-core.mjs';

const command = process.argv[2] || 'help';
const args = parseArgs(process.argv.slice(3));
const store = new Store(getDataDir());

function safeFileName(value) {
  return String(value || 'batch').replace(/[\\/:*?"<>|\s]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'batch';
}

function formatBatchText(batch, items) {
  const lines = [];
  lines.push(`批次：${batch.name}`);
  lines.push(`时长：${batch.planLabel || `${batch.durationDays}天`}`);
  lines.push(`插件：${batch.productId}`);
  lines.push(`设备数：${batch.maxDevices}`);
  lines.push(`数量：${batch.count}`);
  lines.push('');
  lines.push('序号\t名称\t授权码\t下载码\t时长\t状态');
  for (let index = 0; index < items.length; index += 1) {
    const item = items[index] || {};
    const license = item.license || {};
    const downloadCode = item.downloadCode || {};
    lines.push([
      String(index + 1),
      license.customerName || '',
      license.activationCode || '',
      downloadCode.code || '',
      license.planLabel || '',
      license.status || ''
    ].join('\t'));
  }
  lines.push('');
  return lines.join('\r\n');
}

async function writeBatchExport(batch, items, requestedPath) {
  const text = formatBatchText(batch, items);
  let target = requestedPath ? String(requestedPath).trim() : '';
  if (!target) {
    const dir = path.join(getDataDir(), 'batch-exports');
    await fs.mkdir(dir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[-:TZ]/g, '').slice(0, 14);
    target = path.join(dir, `batch-${safeFileName(batch.name)}-${stamp}.txt`);
  }
  await fs.mkdir(path.dirname(path.resolve(target)), { recursive: true });
  await fs.writeFile(path.resolve(target), `\ufeff${text}`, 'utf8');
  return { path: path.resolve(target), text };
}

async function main() {
  if (command === 'init') {
    await store.init();
    const createdConfig = await writeDefaultConfigIfMissing();
    const keys = await ensureSigningKeyPair(getDataDir());
    console.log(`DATA_DIR=${getDataDir()}`);
    console.log(`DB_READY=true`);
    console.log(`CONFIG_CREATED=${createdConfig}`);
    console.log(`SIGNING_KEY_CREATED=${keys.created}`);
    console.log(`PRIVATE_KEY=${signingPrivatePath(getDataDir())}`);
    console.log(`PUBLIC_KEY=${signingPublicPath(getDataDir())}`);
    return;
  }

  if (command === 'issue') {
    await store.init();
    await ensureSigningKeyPair(getDataDir());
    const config = await loadConfig();
    const license = await issueLicense(store, {
      productId: args.product || config.productId,
      customerName: args.customer || '',
      customerId: args['customer-id'] || '',
      days: Number(args.days || 30),
      maxDevices: Number(args['max-devices'] || 1),
      maxProfilesPerDevice: Number(args['max-profiles-per-device'] || config.defaultMaxProfilesPerDevice || 20),
      notes: args.notes || ''
    }, config);
    console.log(`LICENSE_ID=${license.licenseId}`);
    console.log(`CUSTOMER_ID=${license.customerId}`);
    console.log(`ACTIVATION_CODE=${license.activationCode}`);
    console.log(`EXPIRES_AT=${license.expiresAt || '激活后开始计时'}`);
    console.log(`MAX_DEVICES=${license.maxDevices}`);
    console.log(`MAX_PROFILES_PER_DEVICE=${license.maxProfilesPerDevice}`);
    return;
  }

  if (command === 'batch-issue') {
    await store.init();
    await ensureSigningKeyPair(getDataDir());
    const config = await loadConfig();
    const name = String(args.name || '').trim();
    const count = Number(args.count || 0);
    const plan = String(args.plan || (args.months ? `month${args.months}` : 'month1'));
    if (!name) throw new Error('--name is required, e.g. --name 闲鱼');
    if (!Number.isInteger(count) || count <= 0) throw new Error('--count must be a positive integer');
    const result = await issueBatchLicenses(store, {
      name,
      count,
      plan,
      days: Number(args.days || 0),
      productId: args.product || config.productId,
      maxDevices: Number(args['max-devices'] || 1),
      maxProfilesPerDevice: Number(args['max-profiles-per-device'] || config.defaultMaxProfilesPerDevice || 20),
      notes: args.notes || ''
    }, config);
    const exported = await writeBatchExport(result.batch, result.items, args.export || args.out || '');
    console.log(`BATCH_ID=${result.batch.batchId}`);
    console.log(`BATCH_NAME=${result.batch.name}`);
    console.log(`PLAN=${result.batch.planLabel}`);
    console.log(`COUNT=${result.items.length}`);
    console.log(`PRODUCT=${result.batch.productId}`);
    console.log(`EXPORT_FILE=${exported.path}`);
    console.log('--- 前 5 条预览 ---');
    for (const item of result.items.slice(0, 5)) {
      console.log(`${item.license.customerName}\t${item.license.activationCode}\t${item.downloadCode?.code || ''}`);
    }
    return;
  }

  if (command === 'list') {
    const db = await store.read();
    console.log(JSON.stringify({
      licenses: Object.values(db.licenses).map(publicLicenseView),
      activations: Object.values(db.activations).map(({ refreshTokenHash, ...rest }) => rest),
      batches: db.batches || {}
    }, null, 2));
    return;
  }

  if (command === 'revoke') {
    const result = await revokeLicenseOrActivation(store, {
      licenseId: args['license-id'] || '',
      activationId: args['activation-id'] || '',
      activationCode: args['activation-code'] || '',
      reason: args.reason || 'admin-cli'
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (command === 'public-key') {
    await ensureSigningKeyPair(getDataDir());
    console.log(JSON.stringify(await loadPublicJwk(getDataDir()), null, 2));
    return;
  }

  console.log([
    'Usage:',
    '  npm run init',
    '  npm run issue -- --customer "客户名" --days 30 --max-devices 1',
    '  npm run batch-issue -- --name 闲鱼 --count 99 --plan month1 --product miaomiao-flow',
    '  npm run list',
    '  npm run revoke -- --activation-code MM-XXXXX-XXXXX-XXXXX-XXXXX --reason refund',
    '  npm run public-key'
  ].join('\n'));
}

main().catch((error) => {
  console.error(error?.stack || error?.message || String(error));
  process.exit(1);
});