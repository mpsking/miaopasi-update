#!/usr/bin/env node
import { createHash } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = path.resolve(process.argv[2] || '');
if (!root) {
  console.error('Usage: node src/verify-extension-hashes.mjs <extension-dir>');
  process.exit(1);
}

const integrityPath = path.join(root, 'lib', 'integrity.js');
const mod = await import(pathToFileURL(integrityPath).href + `?t=${Date.now()}`);
const mismatches = [];
for (const [file, expected] of Object.entries(mod.PACKAGE_INTEGRITY.files)) {
  const data = await fs.readFile(path.join(root, file));
  const actual = createHash('sha256').update(data).digest('hex').toUpperCase();
  if (actual !== expected) mismatches.push({ file, expected, actual });
}
console.log(JSON.stringify({
  entries: Object.keys(mod.PACKAGE_INTEGRITY.files).length,
  mismatches
}, null, 2));
if (mismatches.length) process.exit(1);
