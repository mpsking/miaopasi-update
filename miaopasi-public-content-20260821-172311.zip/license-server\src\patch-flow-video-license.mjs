#!/usr/bin/env node
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.argv[2] || '');
if (!root) {
  throw new Error('Usage: node src/patch-flow-video-license.mjs <extension-dir>');
}
const releaseVersion = String(process.env.MIAOMIAO_RELEASE_VERSION || '2.17.5').trim();
const displayVersion = String(process.env.MIAOMIAO_DISPLAY_VERSION || `${releaseVersion} 生图视频版`).trim();

const read = (rel) => readFileSync(path.join(root, rel), 'utf8');
const write = (rel, text) => writeFileSync(path.join(root, rel), text, 'utf8');
const exists = (rel) => existsSync(path.join(root, rel));

function replaceOnce(text, oldText, newText, label) {
  const count = text.split(oldText).length - 1;
  if (count !== 1) throw new Error(`${label}: expected 1 match, found ${count}`);
  return text.replace(oldText, newText);
}

patchManifest();
patchHelperBridge();
patchWindowsHelper();
patchBackground();
patchSidepanelHtml();
patchSidepanelCss();
patchSidepanelJs();

console.log(JSON.stringify({ ok: true, root }, null, 2));

function patchManifest() {
  const manifest = JSON.parse(read('manifest.json'));
  manifest.name = '妙妙工具 - Flow 批量生图/视频版';
  manifest.description = 'Google Flow 批量生图/视频自动化工具。支持自动生图、自动生视频、Veo/Omni、首尾帧、参考图、无人值守、断点恢复和 MP4 下载。';
  manifest.version = releaseVersion;
  manifest.action = { ...(manifest.action || {}), default_title: '妙妙工具 - 生图视频版' };
  const hosts = Array.isArray(manifest.host_permissions) ? manifest.host_permissions : [];
  if (!hosts.includes('https://xn--i2ru8q2qg.top/*')) hosts.push('https://xn--i2ru8q2qg.top/*');
  manifest.host_permissions = hosts;
  write('manifest.json', `${JSON.stringify(manifest, null, 2)}\n`);
}

function patchBackground() {
  let text = read('background.js').replace(/\r\n/g, '\n');
  if (!text.includes("./lib/license-online.js")) {
    text = replaceOnce(
      text,
      "import { createHelperBridge, activeSignalForTask, DEFAULT_FLOW_URL } from './lib/helper-bridge.js'",
      [
        "import { createHelperBridge, activeSignalForTask, DEFAULT_FLOW_URL } from './lib/helper-bridge.js'",
        "import {",
        "  activateOnlineLicense,",
        "  clearOnlineLicense,",
        "  getOnlineLicenseStatus,",
        "  requireOnlineRunToken,",
        "} from './lib/license-online.js'"
      ].join('\n'),
      'background license import'
    );
  }
  if (!text.includes('const LICENSE_MACHINE_ID_KEY')) {
    text = replaceOnce(
      text,
      "const UNATTENDED_HEALTH_ALARM = 'supflow-unattended-health-v216'",
      [
        "const UNATTENDED_HEALTH_ALARM = 'supflow-unattended-health-v216'",
        "const LICENSE_MACHINE_ID_KEY = 'supflowLicenseMachineIdV2172'",
        "const LICENSE_ACTION_ALIASES = Object.freeze({",
        "  SAVE_TEMPLATE: 'IMPORT_TEMPLATES',",
        "  UPDATE_TEMPLATE: 'IMPORT_TEMPLATES',",
        "  DELETE_TEMPLATES: 'IMPORT_TEMPLATES',",
        "  CONVERT_TODAY_PROMPTS: 'IMPORT_TEMPLATES',",
        "  INCREMENT_TEMPLATE_USED: 'IMPORT_TEMPLATES',",
        "  UNATTENDED_EXPORT: 'EXPORT_TEMPLATES',",
        "  UPLOAD_REFERENCE: 'UPLOAD_IMAGE',",
        "})"
      ].join('\n'),
      'background license constants'
    );
  }
  if (!text.includes('async function getOrCreateLicenseMachineId')) {
    if (!text.includes('let cachedLicenseDeviceId')) {
      text = replaceOnce(text, 'let lastAcknowledgedHelperState = null', "let lastAcknowledgedHelperState = null\nlet cachedLicenseDeviceId = ''", 'background license device cache');
    }
    text = replaceOnce(text, 'function isUnfinishedUnattendedTask(task) {', `${licenseBackgroundFunctions()}\n\nfunction isUnfinishedUnattendedTask(task) {`, 'background license functions');
  }
  if (!text.includes("msg.type === 'GET_LICENSE_STATUS'")) {
    text = replaceOnce(text, "  if (msg.type === 'CHECK_CONNECTION') {", `${licenseMessageHandlers()}\n\n  if (msg.type === 'CHECK_CONNECTION') {`, 'background license message handlers');
  }

  text = replaceOnce(
    text,
    "  if (msg.type === 'UNATTENDED_CREATE') {\n    handleUnattendedCreate(msg)\n      .then((task) => sendResponse({ ok: true, task }))",
    "  if (msg.type === 'UNATTENDED_CREATE') {\n    ;(async () => {\n      await requireLicensedAction('UNATTENDED_CREATE')\n      return handleUnattendedCreate(msg)\n    })()\n      .then((task) => sendResponse({ ok: true, task }))",
    'gate unattended create'
  );
  text = replaceOnce(text, "  if (['UNATTENDED_PAUSE', 'UNATTENDED_RESUME', 'UNATTENDED_CANCEL'].includes(msg.type)) {\n    ;(async () => {\n      const current = await unattendedStore.load()", "  if (['UNATTENDED_PAUSE', 'UNATTENDED_RESUME', 'UNATTENDED_CANCEL'].includes(msg.type)) {\n    ;(async () => {\n      await requireLicensedAction(msg.type)\n      const current = await unattendedStore.load()", 'gate unattended controls');
  text = replaceOnce(text, "  if (msg.type === 'UNATTENDED_EXPORT') {\n    ;(async () => {\n      const task = await unattendedStore.load()", "  if (msg.type === 'UNATTENDED_EXPORT') {\n    ;(async () => {\n      await requireLicensedAction('UNATTENDED_EXPORT')\n      const task = await unattendedStore.load()", 'gate unattended export');
  text = replaceOnce(text, "    ;(async () => {\n      const unattendedTask = await unattendedStore.load()", "    ;(async () => {\n      await requireLicensedAction('START_BATCH')\n      const unattendedTask = await unattendedStore.load()", 'gate start batch');
  text = replaceOnce(text, "  if (msg.type === 'DOWNLOAD_SINGLE') {\n    ;(async () => {\n      const tabId = await getOrCreateFlowTab()", "  if (msg.type === 'DOWNLOAD_SINGLE') {\n    ;(async () => {\n      await requireLicensedAction('DOWNLOAD_SINGLE')\n      const tabId = await getOrCreateFlowTab()", 'gate download single');
  text = replaceOnce(text, "  if (msg.type === 'SCAN_FLOW_IMAGES') {\n    ;(async () => {\n      const tabId = await getOrCreateFlowTab()", "  if (msg.type === 'SCAN_FLOW_IMAGES') {\n    ;(async () => {\n      await requireLicensedAction('SCAN_FLOW_IMAGES')\n      const tabId = await getOrCreateFlowTab()", 'gate scan images');
  text = replaceOnce(text, "  if (msg.type === 'UPLOAD_REFERENCE') {\n    ;(async () => {\n      const tabId = await getOrCreateFlowTab()", "  if (msg.type === 'UPLOAD_REFERENCE') {\n    ;(async () => {\n      await requireLicensedAction('UPLOAD_REFERENCE')\n      const tabId = await getOrCreateFlowTab()", 'gate upload reference');

  const templateGates = [
    ["try {\n        await Templates.saveTemplate(msg)", "try {\n        await requireLicensedAction('SAVE_TEMPLATE')\n        await Templates.saveTemplate(msg)", 'gate save template'],
    ["try {\n        await Templates.updateTemplate(msg.id, msg)", "try {\n        await requireLicensedAction('UPDATE_TEMPLATE')\n        await Templates.updateTemplate(msg.id, msg)", 'gate update template'],
    ["try {\n        await Templates.deleteTemplates(msg.ids)", "try {\n        await requireLicensedAction('DELETE_TEMPLATES')\n        await Templates.deleteTemplates(msg.ids)", 'gate delete templates'],
    ["try {\n        const result = await Templates.importTemplates(msg.jsonString)", "try {\n        await requireLicensedAction('IMPORT_TEMPLATES')\n        const result = await Templates.importTemplates(msg.jsonString)", 'gate import templates'],
    ["try {\n        const jsonString = await Templates.exportTemplates(msg.ids)", "try {\n        await requireLicensedAction('EXPORT_TEMPLATES')\n        const jsonString = await Templates.exportTemplates(msg.ids)", 'gate export templates'],
    ["try {\n        const result = await Templates.convertTodayPromptsToTemplates()", "try {\n        await requireLicensedAction('CONVERT_TODAY_PROMPTS')\n        const result = await Templates.convertTodayPromptsToTemplates()", 'gate convert prompts'],
    ["try {\n        await Templates.incrementUsedCount(msg.id)", "try {\n        await requireLicensedAction('INCREMENT_TEMPLATE_USED')\n        await Templates.incrementUsedCount(msg.id)", 'gate increment template']
  ];
  for (const [oldText, newText, label] of templateGates) {
    if (text.includes(oldText)) text = replaceOnce(text, oldText, newText, label);
  }
  write('background.js', text);
}

function patchHelperBridge() {
  const file = 'lib/helper-bridge.js';
  if (!exists(file)) return;
  let text = read(file).replace(/\r\n/g, '\n');
  if (!text.includes('async getDeviceId()')) {
    text = replaceOnce(
      text,
      `    async getStatus() {
      const response = await call({ type: 'GET_STATUS' })
      if (!response.ok) return response
      return {
        ok: true,
        installed: true,
        watchdogRunning: Boolean(response.watchdogRunning),
        awake: Boolean(response.awake),
        watchdogPid: nullableNumber(response.watchdogPid),
        browser: nullableString(response.browser),
        lastHeartbeat: nullableString(response.lastHeartbeat),
        error: nullableString(response.error),
      }
    },
  }`,
      `    async getStatus() {
      const response = await call({ type: 'GET_STATUS' })
      if (!response.ok) return response
      return {
        ok: true,
        installed: true,
        watchdogRunning: Boolean(response.watchdogRunning),
        awake: Boolean(response.awake),
        watchdogPid: nullableNumber(response.watchdogPid),
        browser: nullableString(response.browser),
        lastHeartbeat: nullableString(response.lastHeartbeat),
        error: nullableString(response.error),
      }
    },

    async getDeviceId() {
      const response = await call({ type: 'GET_DEVICE_ID' })
      if (!response.ok) return response
      return {
        ok: true,
        installed: true,
        deviceId: nullableString(response.deviceId),
      }
    },

    async getSharedLicenseCode() {
      const response = await call({ type: 'GET_SHARED_LICENSE_CODE' })
      if (!response.ok) return response
      return { ok: true, activationCode: nullableString(response.activationCode) }
    },

    async setSharedLicenseCode(activationCode) {
      return call({ type: 'SET_SHARED_LICENSE_CODE', activationCode })
    },

    async clearSharedLicenseCode() {
      return call({ type: 'CLEAR_SHARED_LICENSE_CODE' })
    },
  }`,
      'helper bridge device id'
    );
  }
  write(file, text);
}

function patchWindowsHelper() {
  patchHelperCommon();
  patchNativeHost();
}

function patchHelperCommon() {
  const file = 'windows/helper-common.ps1';
  if (!exists(file)) return;
  let text = read(file).replace(/\r\n/g, '\n');
  if (!text.includes('function Get-OrCreate-DeviceId')) {
    text = replaceOnce(
      text,
      'function Get-WatchdogMutexName {',
      `${helperDeviceIdFunction()}\n\nfunction Get-WatchdogMutexName {`,
      'windows helper device id function'
    );
  }
  if (!text.includes('function Get-SharedLicenseCode')) {
    text = replaceOnce(
      text,
      'function Get-WatchdogMutexName {',
      `${helperSharedLicenseFunctions()}\n\nfunction Get-WatchdogMutexName {`,
      'windows helper shared license functions'
    );
  }
  write(file, text);
}

function patchNativeHost() {
  const file = 'windows/native-host.ps1';
  if (!exists(file)) return;
  let text = read(file).replace(/\r\n/g, '\n');
  if (!text.includes("'GET_DEVICE_ID'")) {
    text = replaceOnce(
      text,
      `                'GET_STATUS' {
                    Write-HelperLog -Name native-host -Message 'Handled message type=GET_STATUS.'
                    Write-NativeMessage -Stream $outputStream -Message (Get-NativeStatus)
                }`,
      `                'GET_STATUS' {
                    Write-HelperLog -Name native-host -Message 'Handled message type=GET_STATUS.'
                    Write-NativeMessage -Stream $outputStream -Message (Get-NativeStatus)
                }
                'GET_DEVICE_ID' {
                    Write-HelperLog -Name native-host -Message 'Handled message type=GET_DEVICE_ID.'
                    Write-NativeMessage -Stream $outputStream -Message ([pscustomobject][ordered]@{
                        ok = $true
                        installed = $true
                        deviceId = Get-OrCreate-DeviceId
                    })
                }`,
      'native host device id'
    );
  }
  if (!text.includes("'GET_SHARED_LICENSE_CODE'")) {
    text = replaceOnce(
      text,
      "                'GET_TASK' {",
      `                'GET_SHARED_LICENSE_CODE' {
                    Write-NativeMessage -Stream $outputStream -Message ([pscustomobject][ordered]@{ ok = $true; activationCode = Get-SharedLicenseCode })
                }
                'SET_SHARED_LICENSE_CODE' {
                    $code = Set-SharedLicenseCode -ActivationCode ([string]$message.activationCode)
                    Write-NativeMessage -Stream $outputStream -Message ([pscustomobject][ordered]@{ ok = $true; activationCode = $code })
                }
                'CLEAR_SHARED_LICENSE_CODE' {
                    Clear-SharedLicenseCode
                    Write-NativeMessage -Stream $outputStream -Message ([pscustomobject][ordered]@{ ok = $true })
                }
                'GET_TASK' {`,
      'native host shared license messages'
    );
  }
  write(file, text);
}

function patchSidepanelHtml() {
  let text = read('sidepanel.html').replace(/\r\n/g, '\n');
  text = text.replace(/<title>[\s\S]*?<\/title>/, '<title>妙妙工具 - 生图视频版</title>');
  text = text.replace(/<span class="version-badge">[\s\S]*?<\/span>/, `<span class="version-badge">v${displayVersion}</span>`);
  text = text.replace(/<div class="footer-credit">[\s\S]*?<\/div>/, `<div class="footer-credit">由 喵帕斯 开发 | v${displayVersion} 自动生图 + 自动生视频</div>`);
  if (!text.includes('class="section license-card"')) {
    text = replaceOnce(text, '  <div class="section generation-tabs-section">', `${licenseCardHtml()}\n\n  <div class="section generation-tabs-section">`, 'insert license card');
  }
  write('sidepanel.html', text);
}

function patchSidepanelCss() {
  let text = read('sidepanel.css').replace(/\r\n/g, '\n');
  if (!text.includes('.license-card')) text += licenseCss();
  write('sidepanel.css', text);
}

function patchSidepanelJs() {
  let text = read('sidepanel.js').replace(/\r\n/g, '\n');
  if (!text.includes('const licenseStatusText')) {
    text = replaceOnce(
      text,
      "const btnTemplateLibrary = $('#btn-template-library')",
      [
        "const btnTemplateLibrary = $('#btn-template-library')",
        "const licenseStatusText = $('#license-status-text')",
        "const licenseStatusPill = $('#license-status-pill')",
        "const licenseMachineId = $('#license-machine-id')",
        "const licenseCodeInput = $('#license-code-input')",
        "const btnLicenseActivate = $('#btn-license-activate')",
        "const btnLicenseRefresh = $('#btn-license-refresh')",
        "const btnLicenseClear = $('#btn-license-clear')",
        "const licenseActivateRow = $('.license-activate-row')",
        "const licenseMachineRow = $('.license-machine-row')"
      ].join('\n'),
      'sidepanel license consts'
    );
  }
  if (!text.includes("let licenseState = { ok: false")) {
    text = replaceOnce(text, "let connectionState = { status: 'disconnected' }", "let connectionState = { status: 'disconnected' }\nlet licenseState = { ok: false, code: 'checking', error: '正在检查授权...' }", 'sidepanel license state');
  }
  if (!text.includes('await refreshLicenseStatus(true)')) {
    if (text.includes('  checkConnection()\n  bindEvents()')) {
      text = replaceOnce(text, '  checkConnection()\n  bindEvents()', '  checkConnection()\n  await refreshLicenseStatus(true)\n  bindEvents()', 'sidepanel initial license refresh');
    } else if (text.includes("  safeStartupStep('检测 Flow 连接', checkConnection)\n  safeStartupStep('绑定界面按钮', bindEvents)")) {
      text = replaceOnce(
        text,
        "  safeStartupStep('检测 Flow 连接', checkConnection)\n  safeStartupStep('绑定界面按钮', bindEvents)",
        "  safeStartupStep('检测 Flow 连接', checkConnection)\n  await safeStartupStep('刷新授权状态', () => refreshLicenseStatus(true))\n  safeStartupStep('绑定界面按钮', bindEvents)",
        'sidepanel initial license refresh'
      );
    } else {
      throw new Error('sidepanel initial license refresh: no supported init anchor found');
    }
    text = replaceOnce(text, '  setInterval(checkConnection, 15000)', '  setInterval(checkConnection, 15000)\n  setInterval(() => refreshLicenseStatus(true), 60000)', 'sidepanel license interval');
  }
  if (!text.includes('btnLicenseActivate.addEventListener')) {
    text = replaceOnce(
      text,
      "  btnTemplateLibrary.addEventListener('click', openTemplateLibrary)",
      [
        "  btnTemplateLibrary.addEventListener('click', openTemplateLibrary)",
        "  btnLicenseActivate?.addEventListener('click', activateLicenseFromInput)",
        "  btnLicenseRefresh?.addEventListener('click', () => refreshLicenseStatus())",
        "  btnLicenseClear?.addEventListener('click', clearLocalLicense)",
        "  licenseCodeInput?.addEventListener('keydown', (event) => {",
        "    if (event.key === 'Enter') activateLicenseFromInput()",
        "  })"
      ].join('\n'),
      'sidepanel license events'
    );
  }
  if (!text.includes('async function refreshLicenseStatus')) {
    text = replaceOnce(text, 'async function handleStart() {', `${licenseSidepanelFunctions()}\n\nasync function handleStart() {`, 'sidepanel license functions');
  }
  if (!text.includes('if (!await ensureLicenseBeforeAction()) return')) {
    text = replaceOnce(text, 'async function handleStart() {\n', 'async function handleStart() {\n  if (!await ensureLicenseBeforeAction()) return\n', 'sidepanel start precheck');
  }
  if (!text.includes('const licenseLocked = !licenseState?.ok')) {
    text = replaceOnce(
      text,
      "  btnStart.disabled = state.legacyStartDisabled\n  $('#btn-unattended-save').disabled = state.unattendedSaveDisabled\n  $('#btn-unattended-start').disabled = state.unattendedStartDisabled\n  $('#btn-unattended-schedule').disabled = state.unattendedScheduleDisabled",
      "  const licenseLocked = !licenseState?.ok\n  btnStart.disabled = state.legacyStartDisabled || licenseLocked\n  $('#btn-unattended-save').disabled = state.unattendedSaveDisabled\n  $('#btn-unattended-start').disabled = state.unattendedStartDisabled || licenseLocked\n  $('#btn-unattended-schedule').disabled = state.unattendedScheduleDisabled || licenseLocked",
      'sidepanel disable locked controls'
    );
  }
  write('sidepanel.js', text);
}

function helperDeviceIdFunction() {
  return `function Get-OrCreate-DeviceId {
    [CmdletBinding()]
    param()

    $mutex = New-Object Threading.Mutex($false, 'Local\\MiaomiaoFlow2171DeviceIdLock')
    $acquired = $false
    try {
        try {
            $acquired = $mutex.WaitOne([TimeSpan]::FromSeconds(10))
        }
        catch [Threading.AbandonedMutexException] {
            $acquired = $true
        }
        if (-not $acquired) {
            throw 'Timed out waiting for the helper device lock.'
        }

        $dataPath = Get-HelperDataPath
        [void](New-Item -ItemType Directory -Path $dataPath -Force)
        $idPath = Join-Path $dataPath 'device-id.txt'
        if (Test-Path -LiteralPath $idPath -PathType Leaf) {
            $existing = [IO.File]::ReadAllText($idPath, (New-Object Text.UTF8Encoding($false, $true))).Trim()
            if ($existing -match '^MMDEV-[A-F0-9]{32}$') {
                return $existing
            }
        }

        $deviceId = 'MMDEV-' + [Guid]::NewGuid().ToString('N').ToUpperInvariant()
        [IO.File]::WriteAllText($idPath, $deviceId, (New-Object Text.UTF8Encoding($false)))
        return $deviceId
    }
    finally {
        if ($acquired) {
            $mutex.ReleaseMutex()
        }
        $mutex.Dispose()
    }
}`;
}

function helperSharedLicenseFunctions() {
  return `function Get-SharedLicenseCode {
    $codePath = Join-Path (Get-HelperDataPath) 'shared-license-code.txt'
    if (-not (Test-Path -LiteralPath $codePath -PathType Leaf)) { return '' }
    $code = [IO.File]::ReadAllText($codePath, (New-Object Text.UTF8Encoding($false, $true))).Trim().ToUpperInvariant()
    if ($code -notmatch '^MM-[A-Z0-9-]{8,}$') { return '' }
    return $code
}

function Set-SharedLicenseCode {
    param([Parameter(Mandatory = $true)][string]$ActivationCode)
    $code = $ActivationCode.Trim().ToUpperInvariant()
    if ($code -notmatch '^MM-[A-Z0-9-]{8,}$') { throw 'Invalid activation code.' }
    $dataPath = Get-HelperDataPath
    [void](New-Item -ItemType Directory -Path $dataPath -Force)
    [IO.File]::WriteAllText((Join-Path $dataPath 'shared-license-code.txt'), $code, (New-Object Text.UTF8Encoding($false)))
    return $code
}

function Clear-SharedLicenseCode {
    $codePath = Join-Path (Get-HelperDataPath) 'shared-license-code.txt'
    Remove-Item -LiteralPath $codePath -Force -ErrorAction SilentlyContinue
}`;
}

function licenseBackgroundFunctions() {
  return `async function getOrCreateLicenseMachineId() {
  const stored = await chrome.storage.local.get([LICENSE_MACHINE_ID_KEY])
  const existing = String(stored[LICENSE_MACHINE_ID_KEY] || '').trim()
  if (existing) return existing
  const generated = \`SF-\${crypto.randomUUID().replace(/-/g, '').toUpperCase()}\`
  await chrome.storage.local.set({ [LICENSE_MACHINE_ID_KEY]: generated })
  return generated
}

async function getLicenseDeviceId(machineId) {
  if (cachedLicenseDeviceId) return cachedLicenseDeviceId
  const result = await helperBridge.getDeviceId()
  if (result.ok && result.deviceId) {
    cachedLicenseDeviceId = result.deviceId
    return cachedLicenseDeviceId
  }
  cachedLicenseDeviceId = machineId
  return cachedLicenseDeviceId
}

async function activateForProfile(activationCode, machineId, deviceId, action = 'START_BATCH') {
  return activateOnlineLicense({
    activationCode,
    machineId,
    deviceId,
    profileId: machineId,
    profileLabel: licenseProfileLabel(machineId),
    action: licenseAction(action),
  })
}

async function restoreSharedLicense(machineId, deviceId, action = 'START_BATCH') {
  const shared = await helperBridge.getSharedLicenseCode().catch(() => ({ ok: false }))
  const activationCode = String(shared?.activationCode || '').trim()
  if (!shared?.ok || !activationCode) return null
  return activateForProfile(activationCode, machineId, deviceId, action)
}

function licenseProfileLabel(machineId) {
  return \`浏览器入口 \${String(machineId || '').slice(-6)}\`
}

function licenseAction(type) {
  return LICENSE_ACTION_ALIASES[type] || type || 'START_BATCH'
}

async function requireLicensedAction(type) {
  // LICENSE_GATE: business-function
  const machineId = await getOrCreateLicenseMachineId()
  const deviceId = await getLicenseDeviceId(machineId)
  return requireOnlineRunToken({
    machineId,
    deviceId,
    profileId: machineId,
    profileLabel: licenseProfileLabel(machineId),
    action: licenseAction(type),
  })
}

async function readLicenseStatus(action = 'START_BATCH') {
  const machineId = await getOrCreateLicenseMachineId()
  const deviceId = await getLicenseDeviceId(machineId)
  let status = await getOnlineLicenseStatus({
    machineId,
    deviceId,
    profileId: machineId,
    profileLabel: licenseProfileLabel(machineId),
    action: licenseAction(action),
  })
  if (!status.ok && status.code === 'online_not_activated') {
    const restored = await restoreSharedLicense(machineId, deviceId, action).catch(() => null)
    if (restored?.ok) status = restored
  }
  return { ...status, machineId, deviceId }
}

function licenseErrorResponse(error) {
  return {
    ok: false,
    code: error?.code || 'license_required',
    error: error?.message || '需要有效授权',
    license: error?.licenseStatus || null,
  }
}`;
}

function licenseMessageHandlers() {
  return `  if (msg.type === 'GET_LICENSE_STATUS') {
    readLicenseStatus(msg.action || 'START_BATCH')
      .then(sendResponse)
      .catch((error) => sendResponse(licenseErrorResponse(error)))
    return true
  }

  if (msg.type === 'ACTIVATE_LICENSE') {
    ;(async () => {
      const machineId = await getOrCreateLicenseMachineId()
      const deviceId = await getLicenseDeviceId(machineId)
      const status = await activateForProfile(msg.activationCode, machineId, deviceId, msg.action || 'START_BATCH')
      await helperBridge.setSharedLicenseCode(msg.activationCode)
      return status
    })()
      .then((status) => sendResponse({ ...status, machineId: status.machineId, deviceId: status.deviceId || cachedLicenseDeviceId }))
      .catch((error) => sendResponse(licenseErrorResponse(error)))
    return true
  }

  if (msg.type === 'CLEAR_LICENSE') {
    Promise.all([clearOnlineLicense(), helperBridge.clearSharedLicenseCode()])
      .then(() => getOrCreateLicenseMachineId())
      .then((machineId) => sendResponse({ ok: true, machineId }))
      .catch((error) => sendResponse(licenseErrorResponse(error)))
    return true
  }`;
}

function licenseCardHtml() {
  return `  <div class="section license-card">
    <div class="license-header">
      <div>
        <label class="section-label">授权</label>
        <div id="license-status-text" class="license-status-text">正在检查授权...</div>
      </div>
      <span id="license-status-pill" class="license-pill license-pill-warn">未激活</span>
    </div>
    <div class="license-machine-row">
      <span>机器码</span>
      <code id="license-machine-id">生成中...</code>
    </div>
    <div class="license-activate-row">
      <input id="license-code-input" type="text" placeholder="输入 MM- 开头的授权码">
      <button id="btn-license-activate" class="btn-primary btn-sm" type="button">激活</button>
    </div>
    <div class="license-actions-row">
      <button id="btn-license-refresh" class="btn-icon-sm" type="button">刷新授权</button>
      <button id="btn-license-clear" class="btn-icon-sm" type="button">清除本机授权</button>
      <a class="license-buy-link" href="https://xn--i2ru8q2qg.top" target="_blank" rel="noreferrer">购买续费</a>
    </div>
  </div>`;
}

function licenseCss() {
  return `

.license-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px; }
.license-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; margin-bottom: 10px; }
.license-status-text { color: var(--text-secondary); font-size: 12px; line-height: 1.5; }
.license-pill { flex-shrink: 0; border-radius: var(--radius-pill); padding: 4px 10px; font-size: 11px; font-weight: 700; border: 1px solid transparent; }
.license-pill-ok { color: var(--green); background: var(--green-bg); border-color: rgba(86, 211, 100, .25); }
.license-pill-warn { color: var(--yellow); background: var(--yellow-bg); border-color: rgba(251, 188, 4, .25); }
.license-pill-bad { color: var(--red); background: var(--red-bg); border-color: rgba(242, 139, 130, .25); }
.license-machine-row { display: grid; gap: 5px; margin-bottom: 10px; }
.license-machine-row span { color: var(--text-muted); font-size: 11px; }
.license-machine-row code { display: block; min-height: 30px; padding: 8px 10px; border-radius: 8px; background: var(--bg-primary); border: 1px solid var(--border); color: var(--text-primary); font: 600 11px 'SF Mono', 'Consolas', monospace; word-break: break-all; }
.license-activate-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 8px; margin-bottom: 8px; }
.license-machine-row[hidden], .license-activate-row[hidden] { display: none !important; }
.license-activate-row input { min-width: 0; height: 34px; padding: 0 10px; border-radius: 8px; background: var(--bg-primary); border: 1px solid var(--border); color: var(--text-primary); font-size: 12px; }
.license-actions-row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; }
.license-buy-link { min-height: 30px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; background: #111318; border: 1px solid var(--border); color: var(--accent); font-size: 12px; font-weight: 700; text-decoration: none; }
`;
}

function licenseSidepanelFunctions() {
  return `async function refreshLicenseStatus(silent = false) {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'GET_LICENSE_STATUS', action: 'START_BATCH' })
    licenseState = res || { ok: false, code: 'license_unknown', error: '授权状态未知' }
  } catch (error) {
    licenseState = { ok: false, code: 'license_check_failed', error: error.message || '授权检查失败' }
  }
  renderLicenseStatus()
  syncExecutionEntryState()
  if (!silent && !licenseState.ok && licenseState.code && licenseState.code !== 'online_not_activated') {
    addLog(\`授权检查失败：\${licenseState.error || licenseState.code}\`, 'warn')
  }
  return licenseState
}

function renderLicenseStatus() {
  const ok = Boolean(licenseState?.ok)
  const offline = Boolean(licenseState?.offline)
  const machineId = licenseState?.machineId || ''
  if (licenseMachineId) licenseMachineId.textContent = machineId || '未生成'
  if (licenseMachineRow) licenseMachineRow.hidden = ok
  if (licenseActivateRow) licenseActivateRow.hidden = ok
  if (licenseCodeInput) licenseCodeInput.disabled = ok
  if (btnLicenseActivate) btnLicenseActivate.disabled = ok
  licenseStatusPill?.classList.remove('license-pill-ok', 'license-pill-warn', 'license-pill-bad')

  if (ok) {
    if (licenseStatusPill) {
      licenseStatusPill.textContent = offline ? '离线可用' : '已授权'
      licenseStatusPill.classList.add(offline ? 'license-pill-warn' : 'license-pill-ok')
    }
    const days = Number(licenseState.daysRemaining || 0)
    if (licenseStatusText) licenseStatusText.textContent = (offline ? '离线缓存，' : '') + '剩余 ' + days + ' 天'
    return
  }

  if (licenseStatusPill) {
    licenseStatusPill.textContent = '未授权'
    licenseStatusPill.classList.add(licenseState?.code === 'online_not_activated' ? 'license-pill-warn' : 'license-pill-bad')
  }
  if (licenseStatusText) licenseStatusText.textContent = licenseState?.error || '请先输入授权码激活'
}

async function activateLicenseFromInput() {
  const activationCode = licenseCodeInput?.value.trim() || ''
  if (!activationCode) {
    addLog('请输入授权码', 'warn')
    licenseCodeInput?.focus()
    return
  }
  if (licenseStatusText) licenseStatusText.textContent = '正在激活...'
  try {
    const res = await chrome.runtime.sendMessage({
      type: 'ACTIVATE_LICENSE',
      activationCode,
      action: 'START_BATCH',
    })
    licenseState = res || { ok: false, code: 'activate_failed', error: '激活失败' }
    renderLicenseStatus()
    syncExecutionEntryState()
    if (!licenseState.ok) throw new Error(licenseState.error || licenseState.code || '激活失败')
    if (licenseCodeInput) licenseCodeInput.value = ''
    addLog('授权激活成功', 'success')
  } catch (error) {
    addLog(\`授权激活失败：\${error.message}\`, 'error')
    await refreshLicenseStatus(true)
  }
}

async function clearLocalLicense() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'CLEAR_LICENSE' })
    licenseState = { ok: false, code: 'online_not_activated', error: '本机授权已清除', machineId: res?.machineId || '' }
    renderLicenseStatus()
    syncExecutionEntryState()
    addLog('本机授权已清除', 'warn')
  } catch (error) {
    addLog(\`清除授权失败：\${error.message}\`, 'error')
  }
}

async function ensureLicenseBeforeAction() {
  if (licenseState?.ok) return true
  await refreshLicenseStatus(true)
  if (licenseState?.ok) return true
  addLog(\`请先激活授权码：\${licenseState?.error || '未激活'}\`, 'warn')
  return false
}`;
}
