#!/usr/bin/env node
import { createHash, createPublicKey } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';

const targetDir = path.resolve(process.argv[2] || '');
const product = String(process.argv[3] || '').trim();
const version = String(process.argv[4] || '').trim();
const keyPath = path.resolve(process.argv[5] || '');
const buildStamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
const packageBuildId = String(process.env.MIAOMIAO_PACKAGE_BUILD_ID || `${product}-${version}-${buildStamp}`).trim();
const sourcePackage = path.basename(targetDir);

if (!targetDir || !product || !version || !keyPath) {
  throw new Error('Usage: node src/patch-extension-security-warning.mjs <extension-dir> <flow|jimeng> <version> <crx-key-pem>');
}

const publicDer = createPublicKey(await fs.readFile(keyPath, 'utf8')).export({ type: 'spki', format: 'der' });
const manifestKey = publicDer.toString('base64');
const extensionId = extensionIdFromPublicKey(publicDer);

await patchManifest();
if (product === 'flow') await patchFlowClient();
else if (product === 'jimeng') await patchJimengClient();
else throw new Error(`Unknown product: ${product}`);

console.log(JSON.stringify({ ok: true, targetDir, product, version, extensionId, buildId: packageBuildId, sourcePackage }, null, 2));

async function patchManifest() {
  const file = path.join(targetDir, 'manifest.json');
  const manifest = JSON.parse(await fs.readFile(file, 'utf8'));
  manifest.version = version;
  manifest.key = manifestKey;
  manifest.update_url = 'https://xn--i2ru8q2qg.top/updates.xml';
  await fs.writeFile(file, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
}

async function patchJimengClient() {
  const file = path.join(targetDir, 'license-online-global.js');
  let text = await fs.readFile(file, 'utf8');
  text = text.replace(/const STORAGE_KEY = "jimengOnlineLicense(?:V\d+)?";/, 'const STORAGE_KEY = "jimengOnlineLicense";');
  text = text.replace(/extensionVersion:\s*"[^"]+"/, `extensionVersion: "${version}"`);
  text = upsertPackageProvenance(text);
  text = replaceSecurityBlock(text, '  let importedPublicKeyPromise = null;\n', 'CONFIG');
  text = text.replace(
    '    if (!result.ok) throw serviceError(result, "\\u6388\\u6743\\u6fc0\\u6d3b\\u5931\\u8d25");',
    [
      '    if (!result.ok) {',
      '      await reportSecurityEvent({ storage, runtime, machineId, eventType: "activation_failed", code: result.code, message: result.error, action: body.action, activationCodeSuffix: body.activationCode.slice(-6) });',
      '      throw serviceError(result, securityErrorMessage(result, "\\u6388\\u6743\\u6fc0\\u6d3b\\u5931\\u8d25"));',
      '    }'
    ].join('\n')
  );
  text = text.replace(
    [
      '      if (!result.ok) {',
      '        const code = result.code || "refresh_failed";',
      '        const error = result.error || "\\u6388\\u6743\\u5237\\u65b0\\u5931\\u8d25";',
      '        if (isTerminalLicenseFailure(code)) {',
      '          await storage.remove([STORAGE_KEY]);',
      '          return invalid(code, error, { machineId });',
      '        }',
      '        return invalid(code, error, record);',
      '      }'
    ].join('\n'),
    [
      '      if (!result.ok) {',
      '        const code = result.code || "refresh_failed";',
      '        const error = result.error || "\\u6388\\u6743\\u5237\\u65b0\\u5931\\u8d25";',
      '        await reportSecurityEvent({ storage, runtime, machineId, eventType: "refresh_failed", code, message: error, action });',
      '        const displayError = securityErrorMessage({ code, error }, error);',
      '        if (isTerminalLicenseFailure(code)) {',
      '          await storage.remove([STORAGE_KEY]);',
      '          return invalid(code, displayError, { machineId });',
      '        }',
      '        return invalid(code, displayError, record);',
      '      }'
    ].join('\n')
  );
  text = normalizeServiceError(text, '  ');
  text = replaceSecurityHelpers(text, '  function daysRemaining(expiresAt) {\n', 'CONFIG', 'STORAGE_KEY');
  await fs.writeFile(file, text, 'utf8');
}

async function patchFlowClient() {
  const file = path.join(targetDir, 'lib', 'license-online.js');
  let text = await fs.readFile(file, 'utf8');
  text = text.replace(/export const ONLINE_LICENSE_STORAGE_KEY = 'supflowOnlineLicense(?:V\d+)?';/, "export const ONLINE_LICENSE_STORAGE_KEY = 'supflowOnlineLicense';");
  text = text.replace(/extensionVersion:\s*'[^']+'/, `extensionVersion: '${version}'`);
  text = upsertPackageProvenance(text);
  text = replaceSecurityBlock(text, 'let importedPublicKeyPromise = null;\n', 'ONLINE_LICENSE_CONFIG');
  text = text.replace(
    '    activationCode: String(activationCode || \'\').trim().toUpperCase(),\n    machineId: String(machineId || \'\').trim(),',
    '    activationCode: String(activationCode || \'\').trim().toUpperCase(),\n    productId: ONLINE_LICENSE_CONFIG.productId,\n    machineId: String(machineId || \'\').trim(),'
  );
  text = text.replace(
    '  if (!result.ok) throw serviceError(result, \'授权激活失败\');',
    [
      '  if (!result.ok) {',
      '    await reportSecurityEvent({ storage, runtime, machineId: body.machineId, eventType: \'activation_failed\', code: result.code, message: result.error, action, activationCodeSuffix: body.activationCode.slice(-6) });',
      '    throw serviceError(result, securityErrorMessage(result, \'授权激活失败\'));',
      '  }'
    ].join('\n')
  );
  text = text.replace(
    '      refreshToken: record.refreshToken,\n      machineId: resolvedMachineId,',
    '      refreshToken: record.refreshToken,\n      productId: ONLINE_LICENSE_CONFIG.productId,\n      machineId: resolvedMachineId,'
  );
  text = text.replace(
    [
      '    if (!result.ok) {',
      '      const code = result.code || \'refresh_failed\';',
      '      const error = result.error || \'授权刷新失败\';',
      '      if (isTerminalLicenseFailure(code)) {',
      '        await storage.remove([ONLINE_LICENSE_STORAGE_KEY]);',
      '        return invalid(code, error);',
      '      }',
      '      return invalid(code, error, record);',
      '    }'
    ].join('\n'),
    [
      '    if (!result.ok) {',
      '      const code = result.code || \'refresh_failed\';',
      '      const error = result.error || \'授权刷新失败\';',
      '      await reportSecurityEvent({ storage, runtime, machineId: resolvedMachineId, eventType: \'refresh_failed\', code, message: error, action });',
      '      const displayError = securityErrorMessage({ code, error }, error);',
      '      if (isTerminalLicenseFailure(code)) {',
      '        await storage.remove([ONLINE_LICENSE_STORAGE_KEY]);',
      '        return invalid(code, displayError);',
      '      }',
      '      return invalid(code, displayError, record);',
      '    }'
    ].join('\n')
  );
  text = normalizeServiceError(text, '');
  text = replaceSecurityHelpers(text, 'function daysRemaining(expiresAt) {\n', 'ONLINE_LICENSE_CONFIG', 'ONLINE_LICENSE_STORAGE_KEY');
  await fs.writeFile(file, text, 'utf8');
}

function securityBlock(configName) {
  return [
    '/*',
    '  拆包分析提示：你现在的行为是犯罪行为，请立即停止！！！！否则这边会追究id用户法律责任。',
    '  正常插件运行不会展示这条提示；它只放在源码里给拆包和代码分析场景看到。',
    '*/',
    'const SECURITY_WARNING = "\u4f60\u73b0\u5728\u7684\u884c\u4e3a\u662f\u72af\u7f6a\u884c\u4e3a\uff0c\u8bf7\u7acb\u5373\u505c\u6b62\uff01\uff01\uff01\uff01\u5426\u5219\u8fd9\u8fb9\u4f1a\u8ffd\u7a76id\u7528\u6237\u6cd5\u5f8b\u8d23\u4efb";',
    'const SECURITY_REPORT_WINDOW_MS = 15 * 60 * 1000;',
    `const SECURITY_REPORT_KEY = ${configName}.productId + ":securityReports";`
  ].join('\n');
}

function securityHelpers(configName, storageKeyName) {
  return [
    'function securityErrorMessage(result, fallback) {',
    '  return friendlyLicenseError(result, fallback);',
    '}',
    '',
    'function isSecurityFailureCode(code) {',
    '  return [',
    '    "extension_not_allowed",',
    '    "product_mismatch",',
    '    "token_scope",',
    '    "signature_invalid",',
    '    "invalid_signature",',
    '    "token_invalid"',
    '  ].includes(String(code || ""));',
    '}',
    '',
    'function friendlyLicenseError(result, fallback) {',
    '  const code = String(result && result.code || "");',
    '  const messages = {',
    '    extension_version_blocked: "\\u5f53\\u524d\\u63d2\\u4ef6\\u7248\\u672c\\u8fc7\\u4f4e\\uff0c\\u8bf7\\u66f4\\u65b0\\u5230\\u6700\\u65b0\\u7248\\u540e\\u518d\\u4f7f\\u7528",',
    '    online_not_activated: "\\u9700\\u8981\\u5148\\u8f93\\u5165\\u6388\\u6743\\u7801\\u6fc0\\u6d3b",',
    '    license_expired: "\\u6388\\u6743\\u5df2\\u8fc7\\u671f\\uff0c\\u8bf7\\u7eed\\u8d39\\u540e\\u7ee7\\u7eed\\u4f7f\\u7528",',
    '    license_banned: "\\u6388\\u6743\\u5df2\\u88ab\\u505c\\u7528\\uff0c\\u8bf7\\u8054\\u7cfb\\u7ad9\\u957f\\u5904\\u7406",',
    '    license_revoked: "\\u6388\\u6743\\u5df2\\u88ab\\u540a\\u9500\\uff0c\\u8bf7\\u8054\\u7cfb\\u7ad9\\u957f\\u5904\\u7406",',
    '    license_inactive: "\\u6388\\u6743\\u4e0d\\u53ef\\u7528\\uff0c\\u8bf7\\u8054\\u7cfb\\u7ad9\\u957f\\u5904\\u7406",',
    '    activation_inactive: "\\u5f53\\u524d\\u8bbe\\u5907\\u6388\\u6743\\u4e0d\\u53ef\\u7528\\uff0c\\u8bf7\\u8054\\u7cfb\\u7ad9\\u957f\\u5904\\u7406",',
    '    activation_not_found: "\\u5f53\\u524d\\u8bbe\\u5907\\u6388\\u6743\\u8bb0\\u5f55\\u4e0d\\u5b58\\u5728\\uff0c\\u8bf7\\u91cd\\u65b0\\u6fc0\\u6d3b\\u6216\\u8054\\u7cfb\\u7ad9\\u957f",',
    '    refresh_failed: "\\u6388\\u6743\\u5237\\u65b0\\u5931\\u8d25\\uff0c\\u8bf7\\u7a0d\\u540e\\u91cd\\u8bd5"',
    '  };',
    '  return messages[code] || result && result.error || fallback || "\\u6388\\u6743\\u5931\\u8d25";',
    '}',
    '',
    'async function reportSecurityEvent(details = {}) {',
    '  const code = String(details.code || "");',
    '  if (!isSecurityFailureCode(code)) return;',
    '  const storage = details.storage || chrome.storage.local;',
    '  const runtime = details.runtime || chrome.runtime;',
    `  const machineId = String(details.machineId || "").trim();`,
    `  const fingerprint = [details.eventType || "security", code, runtime.id || "", ${configName}.buildId || "", machineId, details.action || ""].join("|");`,
    '  if (!await shouldSendSecurityReport(storage, fingerprint)) return;',
    '  try {',
    `    await fetch(${configName}.apiBase + "/api/v1/security-events", {`,
    '      method: "POST",',
    '      headers: { "Content-Type": "application/json" },',
    '      body: JSON.stringify({',
    '        eventType: details.eventType || "license_security_event",',
    '        severity: "warning",',
    `        productId: ${configName}.productId,`,
    '        extensionId: runtime.id || "",',
    `        extensionVersion: ${configName}.extensionVersion,`,
    `        buildId: ${configName}.buildId || "",`,
    `        releaseId: ${configName}.releaseId || "",`,
    `        sourcePackage: ${configName}.sourcePackage || "",`,
    `        packageSha256: ${configName}.packageSha256 || "",`,
    '        machineId,',
    '        action: details.action || "",',
    '        code,',
    '        message: String(details.message || ""),',
    '        warning: SECURITY_WARNING,',
    '        activationCodeSuffix: String(details.activationCodeSuffix || "")',
    '      }),',
    '      cache: "no-store"',
    '    });',
    '  } catch {',
    '    // Reporting must never block the extension UI.',
    '  }',
    '}',
    '',
    'async function shouldSendSecurityReport(storage, fingerprint) {',
    '  try {',
    '    const data = await storage.get([SECURITY_REPORT_KEY]);',
    '    const reports = data && data[SECURITY_REPORT_KEY] && typeof data[SECURITY_REPORT_KEY] === "object" ? data[SECURITY_REPORT_KEY] : {};',
    '    const now = Date.now();',
    '    if (reports[fingerprint] && now - Number(reports[fingerprint]) < SECURITY_REPORT_WINDOW_MS) return false;',
    '    reports[fingerprint] = now;',
    '    for (const key of Object.keys(reports)) {',
    '      if (now - Number(reports[key]) > SECURITY_REPORT_WINDOW_MS * 8) delete reports[key];',
    '    }',
    '    await storage.set({ [SECURITY_REPORT_KEY]: reports });',
    '    return true;',
    '  } catch {',
    '    return true;',
    '  }',
    '}'
  ].join('\n');
}

function upsertPackageProvenance(text) {
  const fields = {
    buildId: packageBuildId,
    releaseId: '',
    sourcePackage,
    packageSha256: ''
  };
  for (const key of Object.keys(fields)) {
    text = text.replace(new RegExp(`\\n\\s*${key}:\\s*(['"])[^'"]*\\1,?`, 'g'), '');
  }
  const block = Object.entries(fields)
    .map(([key, value]) => ({ key, value }));
  return text.replace(/(\n)(\s*)extensionVersion:\s*(['"])[^'"]*\3,\s*\n/, (match, newline, indent) => {
    const inserted = block.map(({ key, value }) => `${indent}${key}: ${JSON.stringify(value)},`).join('\n');
    return `${match}${inserted}\n`;
  });
}

function replaceSecurityBlock(text, marker, configName) {
  const markerIndex = text.indexOf(marker);
  if (markerIndex < 0) throw new Error(`Expected one marker, found 0: ${marker}`);
  const before = text.slice(0, markerIndex + marker.length);
  let after = text.slice(markerIndex + marker.length);
  after = after.replace(
    /^(?:\s*(?:\/\*[\s\S]*?\*\/\s*)?const SECURITY_WARNING = [\s\S]*?;\s*const SECURITY_REPORT_WINDOW_MS = 15 \* 60 \* 1000;\s*const SECURITY_REPORT_KEY = (?:CONFIG|ONLINE_LICENSE_CONFIG)\.productId \+ ":securityReports";\s*)+/,
    ''
  );
  return `${before}${securityBlock(configName)}\n${after}`;
}

function replaceSecurityHelpers(text, daysMarker, configName, storageKeyName) {
  const replacement = `${securityHelpers(configName, storageKeyName)}\n\n${daysMarker}`;
  const existingHelperPattern = new RegExp(`\\n\\s*function securityErrorMessage[\\s\\S]*?\\n${escapeRegExp(daysMarker)}`);
  if (existingHelperPattern.test(text)) return text.replace(existingHelperPattern, `\n${replacement}`);
  return insertOnce(text, daysMarker, replacement);
}

function normalizeServiceError(text, indent) {
  const inner = indent + '  ';
  const pattern = new RegExp(
    `${escapeRegExp(indent)}function serviceError\\(result, fallback\\) \\{\\n` +
      `${escapeRegExp(inner)}(?:const message = [^\\n]+;\\n${escapeRegExp(inner)})?` +
      `const error = new Error\\((?:message|result\\.error \\|\\| fallback)\\);`
  );
  const replacement = [
    `${indent}function serviceError(result, fallback) {`,
    `${inner}const message = friendlyLicenseError(result, fallback);`,
    `${inner}const error = new Error(message);`
  ].join('\n');
  if (!pattern.test(text)) throw new Error('serviceError function shape not recognized');
  return text.replace(pattern, replacement);
}

function insertOnce(text, marker, replacement) {
  const markerLine = marker.trim();
  const sentinel = replacement
    .trim()
    .split('\n')
    .map((line) => line.trim())
    .find((line) => line && line !== markerLine);
  if (sentinel && text.includes(sentinel)) return text;
  const count = text.split(marker).length - 1;
  if (count !== 1) throw new Error(`Expected one marker, found ${count}: ${marker}`);
  return text.replace(marker, replacement);
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function extensionIdFromPublicKey(publicKey) {
  const digest = createHash('sha256').update(publicKey).digest();
  const alphabet = 'abcdefghijklmnop';
  return Array.from(digest.subarray(0, 16))
    .map((byte) => alphabet[byte >> 4] + alphabet[byte & 15])
    .join('');
}
