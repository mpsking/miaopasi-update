import path from 'node:path';
import {
  createPrivateKey,
  createPublicKey,
  generateKeyPairSync,
  sign as nodeSign,
  verify as nodeVerify
} from 'node:crypto';
import {
  base64UrlDecode,
  base64UrlEncode,
  fileExists,
  getDataDir,
  nowIso,
  readJson,
  stableStringify,
  writeJsonAtomic
} from './util.mjs';

export function signingPrivatePath(dataDir = getDataDir()) {
  return path.join(dataDir, 'signing-private.jwk');
}

export function signingPublicPath(dataDir = getDataDir()) {
  return path.join(dataDir, 'signing-public.jwk');
}

export async function ensureSigningKeyPair(dataDir = getDataDir()) {
  const privateFile = signingPrivatePath(dataDir);
  const publicFile = signingPublicPath(dataDir);
  if (await fileExists(privateFile)) {
    return {
      created: false,
      privateJwk: await readJson(privateFile),
      publicJwk: await readJson(publicFile)
    };
  }
  const pair = generateKeyPairSync('ec', { namedCurve: 'P-256' });
  const privateJwk = pair.privateKey.export({ format: 'jwk' });
  const publicJwk = pair.publicKey.export({ format: 'jwk' });
  privateJwk.use = 'sig';
  publicJwk.use = 'sig';
  privateJwk.kid = `p256-${Date.now()}`;
  publicJwk.kid = privateJwk.kid;
  await writeJsonAtomic(privateFile, privateJwk);
  await writeJsonAtomic(publicFile, publicJwk);
  return { created: true, privateJwk, publicJwk };
}

export async function loadPrivateJwk(dataDir = getDataDir()) {
  const pair = await ensureSigningKeyPair(dataDir);
  return pair.privateJwk;
}

export async function loadPublicJwk(dataDir = getDataDir()) {
  const pair = await ensureSigningKeyPair(dataDir);
  return pair.publicJwk;
}

export function signToken(privateJwk, payload) {
  const key = createPrivateKey({ key: privateJwk, format: 'jwk' });
  const header = {
    typ: 'SFT',
    alg: 'ES256',
    kid: privateJwk.kid || 'p256-local'
  };
  const encodedHeader = base64UrlEncode(stableStringify(header));
  const encodedPayload = base64UrlEncode(stableStringify(payload));
  const signingInput = `${encodedHeader}.${encodedPayload}`;
  const signature = nodeSign('sha256', Buffer.from(signingInput), {
    key,
    dsaEncoding: 'ieee-p1363'
  });
  return `${signingInput}.${base64UrlEncode(signature)}`;
}

export function verifyToken(publicJwk, token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) {
    return { ok: false, code: 'token_format', error: 'runToken format is invalid' };
  }
  const [encodedHeader, encodedPayload, encodedSignature] = parts;
  let header;
  let payload;
  try {
    header = JSON.parse(base64UrlDecode(encodedHeader).toString('utf8'));
    payload = JSON.parse(base64UrlDecode(encodedPayload).toString('utf8'));
  } catch {
    return { ok: false, code: 'token_decode', error: 'runToken payload is invalid' };
  }
  if (header.alg !== 'ES256' || header.typ !== 'SFT') {
    return { ok: false, code: 'token_header', error: 'runToken header is invalid' };
  }
  const key = createPublicKey({ key: publicJwk, format: 'jwk' });
  const valid = nodeVerify('sha256', Buffer.from(`${encodedHeader}.${encodedPayload}`), {
    key,
    dsaEncoding: 'ieee-p1363'
  }, base64UrlDecode(encodedSignature));
  if (!valid) return { ok: false, code: 'token_signature', error: 'runToken signature is invalid' };
  const now = Math.floor(Date.now() / 1000);
  if (!Number.isFinite(payload.exp) || payload.exp <= now) {
    return { ok: false, code: 'token_expired', error: 'runToken expired', payload };
  }
  return { ok: true, header, payload, checkedAt: nowIso() };
}
