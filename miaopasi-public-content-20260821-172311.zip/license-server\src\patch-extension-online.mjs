#!/usr/bin/env node
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const serverRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const extensionDir = path.resolve(process.argv[2] || '');
if (!extensionDir) {
  console.error('Usage: node src/patch-extension-online.mjs <extension-dir> [api-base]');
  process.exit(1);
}

const apiBase = process.argv[3] || 'http://127.0.0.1:8788';
const clientSource = path.join(serverRoot, 'extension-client', 'license-online.js');
const clientTarget = path.join(extensionDir, 'lib', 'license-online.js');
const backgroundFile = path.join(extensionDir, 'background.js');
const manifestFile = path.join(extensionDir, 'manifest.json');
const integrityFile = path.join(extensionDir, 'lib', 'integrity.js');

await copyOnlineClient();
await patchManifest();
await patchBackground();
await rewriteIntegrity();
console.log(`PATCH_EXTENSION_ONLINE_OK ${extensionDir}`);

async function copyOnlineClient() {
  let source = await fs.readFile(clientSource, 'utf8');
  source = source.replace("apiBase: 'http://127.0.0.1:8788'", `apiBase: '${apiBase.replace(/'/g, "\\'")}'`);
  await fs.writeFile(clientTarget, source, 'utf8');
}

async function patchManifest() {
  const manifest = JSON.parse(await fs.readFile(manifestFile, 'utf8'));
  const hosts = Array.isArray(manifest.host_permissions) ? manifest.host_permissions : [];
  const permission = `${apiBase.replace(/\/+$/g, '')}/*`;
  if (!hosts.includes(permission)) hosts.push(permission);
  manifest.host_permissions = hosts;
  await fs.writeFile(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
}

async function patchBackground() {
  let text = await fs.readFile(backgroundFile, 'utf8');
  const importNeedle = "import{LICENSE_STORAGE_KEY,clearLicenseCode,getLicenseStatus,getOrCreateBrowserMachineId,saveLicenseCode}from'./lib/license.js';";
  const importPatch = `${importNeedle}import{activateOnlineLicense,clearOnlineLicense,getOnlineLicenseStatus,requireOnlineRunToken}from'./lib/license-online.js';`;
  if (!text.includes("./lib/license-online.js")) {
    text = replaceOnce(text, importNeedle, importPatch, 'online license import');
  }

  const oldStatus = "async function readLicenseStatus(){const _0xbff06d=a0_0x27f0bc,_0x31d48f=await verifyPackageIntegrity(chrome[_0xbff06d(0x280)]);if(!_0x31d48f['ok'])return{'ok':![],'code':_0x31d48f[_0xbff06d(0x284)]||_0xbff06d(0x22b),'error':_0x31d48f[_0xbff06d(0x235)]||'Package\\x20integrity\\x20check\\x20failed.','machineId':'','codePresent':![]};const _0x9a07de=await readMachineId();return getLicenseStatus({'storage':chrome[_0xbff06d(0x265)]['local'],'machineId':_0x9a07de});}async function requireValidLicense(){const _0x195c0b=a0_0x27f0bc,_0xd4fbd1=await readLicenseStatus();if(!_0xd4fbd1['ok'])throw codedError('license_required',_0xd4fbd1[_0x195c0b(0x235)]||_0x195c0b(0x269));return _0xd4fbd1;}";
  const newStatus = "async function readLicenseStatus(){const _0xbff06d=a0_0x27f0bc,_0x31d48f=await verifyPackageIntegrity(chrome.runtime);if(!_0x31d48f['ok'])return{'ok':![],'code':_0x31d48f[_0xbff06d(0x284)]||_0xbff06d(0x22b),'error':_0x31d48f[_0xbff06d(0x235)]||'Package\\x20integrity\\x20check\\x20failed.','machineId':'','codePresent':![]};const _0x9a07de=await readMachineId(),_0x1af878=await getLicenseStatus({'storage':chrome.storage.local,'machineId':_0x9a07de}),_0x280589=await getOnlineLicenseStatus({'storage':chrome.storage.local,'machineId':_0x9a07de,'action':'START_BATCH'}).catch(_0x17d2e6=>({'ok':![],'code':'online_error','error':_0x17d2e6?.message||'Online\\x20license\\x20check\\x20failed.'}));if(_0x280589['ok'])return{..._0x1af878,..._0x280589,'ok':!![],'machineId':_0x9a07de,'codePresent':!![],'mode':_0x280589['offline']?'online-offline-grace':'online'};return{..._0x1af878,'ok':![],'machineId':_0x9a07de,'online':_0x280589,'codePresent':Boolean(_0x1af878['codePresent']),'error':_0x280589['error']||_0x1af878['error']||'Online\\x20activation\\x20is\\x20required.'};}async function requireValidLicense(action='START_BATCH'){const _0x195c0b=a0_0x27f0bc,_0xd4fbd1=await readLicenseStatus();if(!_0xd4fbd1['ok'])throw codedError('license_required',_0xd4fbd1[_0x195c0b(0x235)]||_0xd4fbd1['error']||_0x195c0b(0x269));const _0x44a7bd=_0xd4fbd1['machineId']||await readMachineId(),_0x4ce5b7=await requireOnlineRunToken({'storage':chrome.storage.local,'machineId':_0x44a7bd,'action':action});return{..._0xd4fbd1,'runToken':_0x4ce5b7};}";
  if (text.includes(oldStatus)) {
    text = replaceOnce(text, oldStatus, newStatus, 'license status gate');
  }

  const oldActivate = "if(_0x1df1d8['type']==='ACTIVATE_LICENSE'){;return(async()=>{const _0x36794a=_0xda1f7,_0x1fa1af=await readMachineId(),_0x5608c6=String(_0x1df1d8[_0x36794a(0x284)]||''),_0x4fa97e=await getLicenseStatus({'storage':{'get':async()=>({[LICENSE_STORAGE_KEY]:{'code':_0x5608c6}})},'machineId':_0x1fa1af});if(!_0x4fa97e['ok']){_0x13f320({'ok':![],'status':_0x4fa97e,'error':_0x4fa97e[_0x36794a(0x235)]});return;}await saveLicenseCode(chrome[_0x36794a(0x265)][_0x36794a(0x25d)],_0x5608c6),_0x13f320({'ok':!![],'status':_0x4fa97e});})()[_0xda1f7(0x1e2)](_0x2c9583=>_0x13f320({'ok':![],'error':_0x2c9583[_0xda1f7(0x1ad)]})),!![];}";
  const legacyOnlineActivate = "if(_0x1df1d8['type']==='ACTIVATE_LICENSE'){;return(async()=>{const _0x36794a=_0xda1f7,_0x1fa1af=await readMachineId(),_0x5608c6=String(_0x1df1d8[_0x36794a(0x284)]||'').trim();if(/^MM-/i.test(_0x5608c6)){const _0x3fd571=await activateOnlineLicense({'storage':chrome.storage.local,'runtime':chrome.runtime,'activationCode':_0x5608c6,'machineId':_0x1fa1af,'action':'START_BATCH'});_0x13f320({'ok':!![],'status':_0x3fd571});return;}const _0x4fa97e=await getLicenseStatus({'storage':{'get':async()=>({[LICENSE_STORAGE_KEY]:{'code':_0x5608c6}})},'machineId':_0x1fa1af});if(!_0x4fa97e['ok']){_0x13f320({'ok':![],'status':_0x4fa97e,'error':_0x4fa97e[_0x36794a(0x235)]});return;}await saveLicenseCode(chrome[_0x36794a(0x265)][_0x36794a(0x25d)],_0x5608c6),_0x13f320({'ok':!![],'status':_0x4fa97e});})()[_0xda1f7(0x1e2)](_0x2c9583=>_0x13f320({'ok':![],'error':_0x2c9583[_0xda1f7(0x1ad)]})),!![];}";
  const newActivate = "if(_0x1df1d8['type']==='ACTIVATE_LICENSE'){;return(async()=>{const _0x36794a=_0xda1f7,_0x1fa1af=await readMachineId(),_0x5608c6=String(_0x1df1d8[_0x36794a(0x284)]||'').trim();if(!/^MM-/i.test(_0x5608c6)){const _0x29ef1d={'ok':![],'code':'online_activation_required','error':'Online\\x20activation\\x20code\\x20is\\x20required.','machineId':_0x1fa1af,'codePresent':![]};_0x13f320({'ok':![],'status':_0x29ef1d,'error':_0x29ef1d['error']});return;}const _0x3fd571=await activateOnlineLicense({'storage':chrome.storage.local,'runtime':chrome.runtime,'activationCode':_0x5608c6,'machineId':_0x1fa1af,'action':'START_BATCH'});_0x13f320({'ok':!![],'status':_0x3fd571});})()[_0xda1f7(0x1e2)](_0x2c9583=>_0x13f320({'ok':![],'error':_0x2c9583[_0xda1f7(0x1ad)]})),!![];}";
  if (text.includes(oldActivate)) {
    text = replaceOnce(text, oldActivate, newActivate, 'online activation branch');
  } else if (text.includes(legacyOnlineActivate)) {
    text = replaceOnce(text, legacyOnlineActivate, newActivate, 'strict online activation branch');
  }

  const oldClear = "if(_0x1df1d8[_0xda1f7(0x267)]==='CLEAR_LICENSE')return clearLicenseCode(chrome[_0xda1f7(0x265)]['local'])[_0xda1f7(0x1ab)](()=>readLicenseStatus())[_0xda1f7(0x1ab)](_0x504ec5=>_0x13f320({'ok':!![],'status':_0x504ec5}))[_0xda1f7(0x1e2)](_0x2a8d04=>_0x13f320({'ok':![],'error':_0x2a8d04[_0xda1f7(0x1ad)]})),!![];";
  const newClear = "if(_0x1df1d8[_0xda1f7(0x267)]==='CLEAR_LICENSE')return Promise.all([clearLicenseCode(chrome.storage.local),clearOnlineLicense(chrome.storage.local)])[_0xda1f7(0x1ab)](()=>readLicenseStatus())[_0xda1f7(0x1ab)](_0x504ec5=>_0x13f320({'ok':!![],'status':_0x504ec5}))[_0xda1f7(0x1e2)](_0x2a8d04=>_0x13f320({'ok':![],'error':_0x2a8d04[_0xda1f7(0x1ad)]})),!![];";
  if (text.includes(oldClear)) {
    text = replaceOnce(text, oldClear, newClear, 'clear online license');
  }

  const replacements = [
    ["return requireValidLicense()[_0xda1f7(0x1ab)](()=>handleUnattendedCreate", "return requireValidLicense('UNATTENDED_CREATE')[_0xda1f7(0x1ab)](()=>handleUnattendedCreate"],
    ["await requireValidLicense();const _0x5eef9b=await unattendedStore['load']();", "await requireValidLicense({'UNATTENDED_PAUSE':'UNATTENDED_PAUSE','UNATTENDED_RESUME':'UNATTENDED_RESUME','UNATTENDED_CANCEL':'UNATTENDED_CANCEL'}[_0x1df1d8[_0x28291c(0x267)]]||'UNATTENDED_CONTROL');const _0x5eef9b=await unattendedStore['load']();"],
    ["await requireValidLicense();const _0x1f9129=await unattendedStore", "await requireValidLicense('UNATTENDED_REPORT');const _0x1f9129=await unattendedStore"],
    ["await requireValidLicense();const _0x51ea3c=await unattendedStore['load']();", "await requireValidLicense('START_BATCH');const _0x51ea3c=await unattendedStore['load']();"],
    ["await requireValidLicense();const _0x184747=await getOrCreateFlowTab();", "await requireValidLicense('DOWNLOAD_SINGLE');const _0x184747=await getOrCreateFlowTab();"],
    ["await requireValidLicense();const _0x201088=await getOrCreateFlowTab();", "await requireValidLicense('SCAN_FLOW_IMAGES');const _0x201088=await getOrCreateFlowTab();"],
    ["await requireValidLicense();const _0x5641cc=await getOrCreateFlowTab();", "await requireValidLicense('UPLOAD_IMAGE');const _0x5641cc=await getOrCreateFlowTab();"],
    ["try{await requireValidLicense(),await a0_0x32ff17[_0x2a86fe(0x22e)]", "try{await requireValidLicense('SAVE_TEMPLATE'),await a0_0x32ff17[_0x2a86fe(0x22e)]"],
    ["try{await requireValidLicense(),await a0_0x32ff17[_0x1aaf24(0x1eb)]", "try{await requireValidLicense('UPDATE_TEMPLATE'),await a0_0x32ff17[_0x1aaf24(0x1eb)]"],
    ["try{await requireValidLicense(),await a0_0x32ff17['deleteTemplates']", "try{await requireValidLicense('DELETE_TEMPLATE'),await a0_0x32ff17['deleteTemplates']"],
    ["try{await requireValidLicense();const _0x31f029=await a0_0x32ff17", "try{await requireValidLicense('IMPORT_TEMPLATES');const _0x31f029=await a0_0x32ff17"],
    ["try{await requireValidLicense();const _0x5467f9=await a0_0x32ff17", "try{await requireValidLicense('EXPORT_TEMPLATES');const _0x5467f9=await a0_0x32ff17"],
    ["try{await requireValidLicense();const _0x3ce177=await a0_0x32ff17", "try{await requireValidLicense('CONVERT_TODAY_PROMPTS');const _0x3ce177=await a0_0x32ff17"],
    ["try{await requireValidLicense(),await a0_0x32ff17[_0x593e31(0x1ec)]", "try{await requireValidLicense('DELETE_TODAY_PROMPT'),await a0_0x32ff17[_0x593e31(0x1ec)]"]
  ];
  for (const [oldText, newText] of replacements) {
    if (text.includes(oldText)) {
      text = replaceOnce(text, oldText, newText, `business gate ${oldText.slice(0, 40)}`);
    }
  }

  if ((text.match(/requireValidLicense\(\)/g) || []).length !== 0) {
    throw new Error('unmapped requireValidLicense() call remains');
  }
  await fs.writeFile(backgroundFile, text, 'utf8');
}

async function rewriteIntegrity() {
  const files = await listFiles(extensionDir);
  const map = {};
  for (const file of files) {
    const relative = path.relative(extensionDir, file).replace(/\\/g, '/');
    if (relative === 'lib/integrity.js') continue;
    const data = await fs.readFile(file);
    map[relative] = createHash('sha256').update(data).digest('hex').toUpperCase();
  }
  const code = `export const PACKAGE_INTEGRITY=Object.freeze({version:3,files:${JSON.stringify(map)}});\n` +
`let integrityPromise=null;\n` +
`export function verifyPackageIntegrity(runtime=chrome.runtime){\n` +
`  if(!integrityPromise){\n` +
`    integrityPromise=verify(runtime).catch(error=>({ok:false,code:'integrity_error',error:error?.message||'Package integrity check failed.'}));\n` +
`  }\n` +
`  return integrityPromise;\n` +
`}\n` +
`async function verify(runtime){\n` +
`  const entries=Object.entries(PACKAGE_INTEGRITY.files||{});\n` +
`  for(const [file,expected] of entries){\n` +
`    const actual=await hashExtensionFile(runtime,file);\n` +
`    if(actual!==expected){\n` +
`      return {ok:false,code:'integrity_mismatch',error:'Package integrity check failed.',file};\n` +
`    }\n` +
`  }\n` +
`  return {ok:true,checked:entries.length};\n` +
`}\n` +
`async function hashExtensionFile(runtime,file){\n` +
`  const response=await fetch(runtime.getURL(file),{cache:'no-store'});\n` +
`  if(!response.ok){\n` +
`    throw new Error('Cannot read extension file: '+file);\n` +
`  }\n` +
`  const buffer=await response.arrayBuffer();\n` +
`  const digest=await crypto.subtle.digest('SHA-256',buffer);\n` +
`  return [...new Uint8Array(digest)].map(byte=>byte.toString(16).padStart(2,'0')).join('').toUpperCase();\n` +
`}\n`;
  await fs.writeFile(integrityFile, code, 'utf8');
}

function replaceOnce(text, oldText, newText, label) {
  const count = text.split(oldText).length - 1;
  if (count !== 1) throw new Error(`${label}: expected 1 match, found ${count}`);
  return text.replace(oldText, newText);
}

async function listFiles(dir) {
  const out = [];
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...await listFiles(full));
    else if (entry.isFile()) out.push(full);
  }
  return out.sort((a, b) => a.localeCompare(b));
}
