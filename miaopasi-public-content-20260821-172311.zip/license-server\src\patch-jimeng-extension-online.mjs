#!/usr/bin/env node
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const serverRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const extensionDir = path.resolve(process.argv[2] || '');
if (!extensionDir) {
  console.error('Usage: node src/patch-jimeng-extension-online.mjs <extension-dir> [api-base]');
  process.exit(1);
}

const apiBase = String(process.argv[3] || 'https://xn--i2ru8q2qg.top').replace(/\/+$/g, '');
const manifestPath = path.join(extensionDir, 'manifest.json');
const sidepanelHtmlPath = path.join(extensionDir, 'sidepanel.html');
const sidepanelJsPath = path.join(extensionDir, 'sidepanel.js');
const serviceWorkerPath = path.join(extensionDir, 'service-worker.js');
const publicJwkPath = path.join(serverRoot, 'data', 'signing-public.jwk');

const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
const version = String(manifest.version || '2.6');
const publicJwk = JSON.parse(await fs.readFile(publicJwkPath, 'utf8'));

await writeLicenseClient();
await patchManifest();
await patchSidepanelHtml();
await patchServiceWorker();
await patchSidepanelJs();

console.log(JSON.stringify({
  ok: true,
  extensionDir,
  apiBase,
  version,
  client: path.join(extensionDir, 'license-online-global.js')
}, null, 2));

async function writeLicenseClient() {
  const code = `(function(global){
  "use strict";
  const STORAGE_KEY = "jimengOnlineLicenseV26";
  const MACHINE_KEY = "jimengOnlineMachineIdV1";
  const CONFIG = Object.freeze({
    apiBase: ${JSON.stringify(apiBase)},
    productId: "jimeng-agent",
    extensionVersion: ${JSON.stringify(version)},
    offlineGraceSeconds: 86400,
    publicJwk: Object.freeze(${JSON.stringify(publicJwk)})
  });
  let importedPublicKeyPromise = null;

  async function activateOnlineLicense(options = {}) {
    const storage = options.storage || chrome.storage.local;
    const runtime = options.runtime || chrome.runtime;
    const machineId = await getOrCreateMachineId(storage);
    const body = {
      activationCode: String(options.activationCode || "").trim().toUpperCase(),
      machineId,
      extensionId: runtime.id,
      extensionVersion: CONFIG.extensionVersion,
      action: options.action || "START_BATCH"
    };
    const result = await postJson("/api/v1/activate", body);
    if (!result.ok) throw serviceError(result, "\\u6388\\u6743\\u6fc0\\u6d3b\\u5931\\u8d25");
    const tokenPayload = await assertRunTokenTrusted(result.runToken, body.action, runtime.id);
    const record = {
      refreshToken: result.refreshToken,
      runToken: result.runToken,
      runTokenExpiresAt: tokenPayload && tokenPayload.exp ? new Date(tokenPayload.exp * 1000).toISOString() : "",
      machineId,
      license: result.license || null,
      activation: result.activation || null,
      lastOnlineAt: new Date().toISOString(),
      lastAction: body.action
    };
    await storage.set({ [STORAGE_KEY]: record, [MACHINE_KEY]: machineId });
    return toStatus(record);
  }

  async function refreshOnlineRunToken(options = {}) {
    const storage = options.storage || chrome.storage.local;
    const runtime = options.runtime || chrome.runtime;
    const record = await readOnlineLicenseRecord(storage);
    if (!record || !record.refreshToken) {
      const machineId = await getOrCreateMachineId(storage);
      return invalid("online_not_activated", "\\u9700\\u8981\\u5148\\u8f93\\u5165\\u6388\\u6743\\u7801\\u6fc0\\u6d3b", { machineId });
    }
    const action = options.action || "START_BATCH";
    const machineId = String(options.machineId || record.machineId || await getOrCreateMachineId(storage)).trim();
    if (!options.force && record.runToken && tokenStillUsable(record.runTokenExpiresAt, 120)) {
      if (await isCachedRunTokenTrusted(record, action, runtime.id)) return toStatus(record);
    }
    try {
      const result = await postJson("/api/v1/refresh", {
        refreshToken: record.refreshToken,
        machineId,
        extensionId: runtime.id,
        extensionVersion: CONFIG.extensionVersion,
        action
      });
      if (!result.ok) {
        const code = result.code || "refresh_failed";
        const error = result.error || "\\u6388\\u6743\\u5237\\u65b0\\u5931\\u8d25";
        if (isTerminalLicenseFailure(code)) {
          await storage.remove([STORAGE_KEY]);
          return invalid(code, error, { machineId });
        }
        return invalid(code, error, record);
      }
      const tokenPayload = await assertRunTokenTrusted(result.runToken, action, runtime.id);
      const next = {
        ...record,
        runToken: result.runToken,
        runTokenExpiresAt: tokenPayload && tokenPayload.exp ? new Date(tokenPayload.exp * 1000).toISOString() : "",
        machineId,
        lastOnlineAt: new Date().toISOString(),
        lastAction: action
      };
      await storage.set({ [STORAGE_KEY]: next, [MACHINE_KEY]: machineId });
      return toStatus(next);
    } catch (error) {
      if (insideOfflineGrace(record) && await isCachedRunTokenTrusted(record, action, runtime.id)) {
        return toStatus(record, { offline: true });
      }
      return invalid(error.code || "online_unreachable", error.message || "\\u6388\\u6743\\u670d\\u52a1\\u6682\\u65f6\\u4e0d\\u53ef\\u7528", record);
    }
  }

  async function requireOnlineRunToken(options = {}) {
    const status = await refreshOnlineRunToken({ ...options, force: true });
    if (!status.ok) {
      const error = new Error(status.error || "\\u9700\\u8981\\u6709\\u6548\\u6388\\u6743");
      error.code = status.code || "license_required";
      error.licenseStatus = status;
      throw error;
    }
    if (!status.runToken) throw new Error("\\u6388\\u6743\\u7968\\u636e\\u7f3a\\u5931");
    return status.runToken;
  }

  async function getOnlineLicenseStatus(options = {}) {
    return refreshOnlineRunToken({ ...options, force: true });
  }

  async function clearOnlineLicense(storage = chrome.storage.local) {
    await storage.remove([STORAGE_KEY]);
  }

  async function readOnlineLicenseRecord(storage = chrome.storage.local) {
    const data = await storage.get([STORAGE_KEY]);
    return data && data[STORAGE_KEY] ? data[STORAGE_KEY] : null;
  }

  async function getOrCreateMachineId(storage = chrome.storage.local) {
    const data = await storage.get([MACHINE_KEY]);
    const existing = String(data && data[MACHINE_KEY] || "").trim();
    if (existing) return existing;
    const id = "JM-" + randomId();
    await storage.set({ [MACHINE_KEY]: id });
    return id;
  }

  function toStatus(record, extra = {}) {
    return {
      ok: true,
      online: !extra.offline,
      offline: Boolean(extra.offline),
      runToken: record.runToken || "",
      runTokenExpiresAt: record.runTokenExpiresAt || "",
      machineId: record.machineId || "",
      daysRemaining: daysRemaining(record.license && record.license.expiresAt),
      lastOnlineAt: record.lastOnlineAt || "",
      license: record.license || null,
      activation: record.activation || null
    };
  }

  function invalid(code, error, record = null) {
    return {
      ok: false,
      code,
      error,
      online: false,
      runToken: record && record.runToken || "",
      runTokenExpiresAt: record && record.runTokenExpiresAt || "",
      machineId: record && record.machineId || "",
      daysRemaining: daysRemaining(record && record.license && record.license.expiresAt),
      lastOnlineAt: record && record.lastOnlineAt || "",
      license: record && record.license || null,
      activation: record && record.activation || null
    };
  }

  function isTerminalLicenseFailure(code) {
    return [
      "activation_inactive",
      "license_inactive",
      "license_not_found",
      "license_expired",
      "license_banned",
      "license_revoked",
      "activation_not_found"
    ].includes(code);
  }

  function daysRemaining(expiresAt) {
    const expiresMs = Date.parse(expiresAt || "");
    if (!Number.isFinite(expiresMs)) return 0;
    return Math.max(0, Math.ceil((expiresMs - Date.now()) / 86400000));
  }

  function tokenStillUsable(expiresAt, safetySeconds) {
    const expiresMs = Date.parse(expiresAt || "");
    return Number.isFinite(expiresMs) && expiresMs - Date.now() > safetySeconds * 1000;
  }

  function insideOfflineGrace(record) {
    const lastOnlineMs = Date.parse(record && record.lastOnlineAt || "");
    if (!Number.isFinite(lastOnlineMs)) return false;
    return Date.now() - lastOnlineMs <= CONFIG.offlineGraceSeconds * 1000;
  }

  async function postJson(path, body) {
    let response;
    try {
      response = await fetch(CONFIG.apiBase + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        cache: "no-store"
      });
    } catch (error) {
      const wrapped = new Error(error.message || "\\u6388\\u6743\\u670d\\u52a1\\u8fde\\u63a5\\u5931\\u8d25");
      wrapped.code = "network_error";
      throw wrapped;
    }
    const text = await response.text();
    const data = text ? JSON.parse(text) : {};
    if (!response.ok) return { ok: false, ...data };
    return data;
  }

  async function assertRunTokenTrusted(token, action, extensionId) {
    const payload = decodeTokenPayload(token);
    if (!payload) throw new Error("\\u6388\\u6743\\u7968\\u636e\\u683c\\u5f0f\\u65e0\\u6548");
    if (!await verifyRunTokenSignature(token)) throw new Error("\\u6388\\u6743\\u7968\\u636e\\u7b7e\\u540d\\u65e0\\u6548");
    if (!tokenPayloadAllowed(payload, action, extensionId)) throw new Error("\\u6388\\u6743\\u7968\\u636e\\u4e0d\\u9002\\u7528\\u4e8e\\u5f53\\u524d\\u6269\\u5c55\\u6216\\u64cd\\u4f5c");
    return payload;
  }

  async function isCachedRunTokenTrusted(record, action, extensionId, options = {}) {
    const payload = decodeTokenPayload(record.runToken);
    if (!payload) return false;
    if (!options.allowExpired && !tokenStillUsable(record.runTokenExpiresAt, 0)) return false;
    if (!await verifyRunTokenSignature(record.runToken)) return false;
    return tokenPayloadAllowed(payload, action, extensionId, options);
  }

  function tokenPayloadAllowed(payload, action, extensionId, options = {}) {
    if (payload.typ !== "run") return false;
    if (payload.productId !== CONFIG.productId) return false;
    if (payload.extensionVersion !== CONFIG.extensionVersion) return false;
    if (extensionId && payload.extensionId !== extensionId) return false;
    if (!options.allowExpired && Number(payload.exp || 0) <= Math.floor(Date.now() / 1000)) return false;
    const actions = Array.isArray(payload.actions) ? payload.actions : [];
    return actions.includes("*") || actions.includes(action);
  }

  async function verifyRunTokenSignature(token) {
    const parts = String(token || "").split(".");
    if (parts.length !== 3) return false;
    const signature = base64UrlToBytes(parts[2]);
    if (signature.length !== 64) return false;
    const data = new TextEncoder().encode(parts[0] + "." + parts[1]);
    const key = await getPublicCryptoKey();
    return crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, signature, data);
  }

  function getPublicCryptoKey() {
    if (!importedPublicKeyPromise) {
      importedPublicKeyPromise = crypto.subtle.importKey(
        "jwk",
        CONFIG.publicJwk,
        { name: "ECDSA", namedCurve: "P-256" },
        false,
        ["verify"]
      );
    }
    return importedPublicKeyPromise;
  }

  function serviceError(result, fallback) {
    const error = new Error(result.error || fallback);
    error.code = result.code || "license_service_error";
    return error;
  }

  function decodeTokenPayload(token) {
    const payload = String(token || "").split(".")[1];
    if (!payload) return null;
    try {
      return JSON.parse(new TextDecoder().decode(base64UrlToBytes(payload)));
    } catch {
      return null;
    }
  }

  function base64UrlToBytes(input) {
    const normalized = String(input || "").replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized + "=".repeat((4 - (normalized.length % 4)) % 4);
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return bytes;
  }

  function randomId() {
    if (crypto.randomUUID) return crypto.randomUUID().replace(/-/g, "").toUpperCase();
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return Array.from(bytes).map(byte => byte.toString(16).padStart(2, "0")).join("").toUpperCase();
  }

  global.MiaoOnlineLicense = Object.freeze({
    config: CONFIG,
    activateOnlineLicense,
    refreshOnlineRunToken,
    requireOnlineRunToken,
    getOnlineLicenseStatus,
    clearOnlineLicense,
    readOnlineLicenseRecord,
    getOrCreateMachineId
  });
})(globalThis);
`;
  await fs.writeFile(path.join(extensionDir, 'license-online-global.js'), code, 'utf8');
}

async function patchManifest() {
  const hosts = Array.isArray(manifest.host_permissions) ? manifest.host_permissions : [];
  const apiPermission = `${apiBase}/*`;
  if (!hosts.includes(apiPermission)) hosts.push(apiPermission);
  manifest.host_permissions = hosts;
  await fs.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
}

async function patchSidepanelHtml() {
  let html = await fs.readFile(sidepanelHtmlPath, 'utf8');
  if (!html.includes('license-online-global.js')) {
    html = replaceOnce(
      html,
      '    <script src="task-folder.js"></script>',
      '    <script src="license-online-global.js"></script>\n    <script src="task-folder.js"></script>',
      'sidepanel license script'
    );
  }
  await fs.writeFile(sidepanelHtmlPath, html, 'utf8');
}

async function patchServiceWorker() {
  let text = await fs.readFile(serviceWorkerPath, 'utf8');
  if (!text.includes('license-online-global.js')) {
    text = replaceOnce(
      text,
      'importScripts("jpg-download.js");',
      'importScripts("license-online-global.js");\nimportScripts("jpg-download.js");',
      'service worker importScripts'
    );
  }
  if (!text.includes('async function requireJimengLicense')) {
    text = replaceOnce(
      text,
      'async function findJimengTab() {',
      'async function requireJimengLicense(action) {\n  if (!globalThis.MiaoOnlineLicense) throw new Error("授权模块未加载");\n  return globalThis.MiaoOnlineLicense.requireOnlineRunToken({ action });\n}\n\nasync function findJimengTab() {',
      'service worker license helper'
    );
  }
  text = replaceOnce(
    text,
    '  if (message?.type === "START_JOB") {\n    startJob(message.job).then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message }));\n    return true;\n  }',
    '  if (message?.type === "START_JOB") {\n    requireJimengLicense("START_BATCH").then(() => startJob(message.job)).then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message }));\n    return true;\n  }',
    'START_JOB gate'
  );
  text = replaceOnce(
    text,
    '  if (message?.type === "DOWNLOAD_ONE") {\n    downloadOne(message).then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message }));\n    return true;\n  }',
    '  if (message?.type === "DOWNLOAD_ONE") {\n    requireJimengLicense("DOWNLOAD_SINGLE").then(() => downloadOne(message)).then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message }));\n    return true;\n  }',
    'DOWNLOAD_ONE gate'
  );
  text = replaceOnce(
    text,
    '  if (message?.type === "DOWNLOAD_IMAGE_AS_JPG") {\n    JimengJpgDownload.downloadImageAsJpg(\n      chrome,\n      { ...message, filename: sanitizePath(message.filename) }\n    )\n      .then(sendResponse)\n      .catch(error => sendResponse({\n        ok: false,\n        stage: error.stage || "unknown",\n        error: error.message\n      }));\n    return true;\n  }',
    '  if (message?.type === "DOWNLOAD_IMAGE_AS_JPG") {\n    requireJimengLicense("DOWNLOAD_SINGLE")\n      .then(() => JimengJpgDownload.downloadImageAsJpg(\n        chrome,\n        { ...message, filename: sanitizePath(message.filename) }\n      ))\n      .then(sendResponse)\n      .catch(error => sendResponse({\n        ok: false,\n        stage: error.stage || "unknown",\n        error: error.message\n      }));\n    return true;\n  }',
    'DOWNLOAD_IMAGE_AS_JPG gate'
  );
  await fs.writeFile(serviceWorkerPath, text, 'utf8');
}

async function patchSidepanelJs() {
  let text = await fs.readFile(sidepanelJsPath, 'utf8');
  if (!text.includes('initializeLicenseGate')) {
    text = replaceOnce(
      text,
      'async function init() {\n  bindEvents();',
      'async function init() {\n  await initializeLicenseGate();\n  bindEvents();',
      'sidepanel init license gate'
    );
  }
  text = replaceOnce(
    text,
    'async function startBatch(mode = "continue") {\n  return startLoopingBatch(mode);',
    'async function startBatch(mode = "continue") {\n  if (!await ensureLicenseGate("START_BATCH")) return;\n  return startLoopingBatch(mode);',
    'startBatch gate'
  );
  if (!text.includes('const LICENSE_PANEL_ID = "licensePanel";')) {
    text = replaceOnce(
      text,
      'async function init() {',
      `${licensePanelCode()}\n\nasync function init() {`,
      'license panel code'
    );
  }
  await fs.writeFile(sidepanelJsPath, text, 'utf8');
}

function licensePanelCode() {
  return `const LICENSE_PANEL_ID = "licensePanel";

async function initializeLicenseGate() {
  installLicensePanel();
  await refreshLicensePanel({ silent: true });
}

function installLicensePanel() {
  if (document.getElementById(LICENSE_PANEL_ID)) return;
  const style = document.createElement("style");
  style.textContent = \`
    .license-card{border:1px solid var(--line);border-radius:8px;background:#fff;padding:13px;display:grid;gap:10px}
    .license-card__head{display:flex;align-items:center;justify-content:space-between;gap:8px}
    .license-card__head strong{font-size:13px}.license-card__head span{font-size:10px;color:var(--muted)}
    .license-status{font-size:11px;color:var(--muted);line-height:1.6;overflow-wrap:anywhere}
    .license-status.ok{color:var(--green)}.license-status.bad{color:var(--red)}
    .license-row{display:grid;grid-template-columns:1fr 72px;gap:8px}
    .license-row input{min-width:0;height:38px;border:1px solid var(--line);border-radius:7px;padding:0 10px}
    .license-row button,.license-actions button{height:38px;border-radius:7px;font-weight:700;cursor:pointer}
    .license-card.is-authorized .license-row{display:none}
    .license-actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
  \`;
  document.head.appendChild(style);
  const panel = document.createElement("section");
  panel.id = LICENSE_PANEL_ID;
  panel.className = "license-card";
  panel.innerHTML = \`
    <div class="license-card__head"><div><strong>授权</strong><span>在线校验后才能开始跑图</span></div><button id="licenseRefreshButton" class="secondary" type="button">刷新</button></div>
    <div id="licenseStatus" class="license-status">正在读取授权状态...</div>
    <div class="license-row"><input id="licenseCodeInput" type="text" placeholder="输入 MM- 开头的授权码" autocomplete="off" /><button id="licenseActivateButton" class="primary" type="button">激活</button></div>
    <div class="license-actions"><button id="licenseCopyMachineButton" class="secondary" type="button">复制机器码</button><button id="licenseClearButton" class="secondary" type="button">清除本机授权</button></div>
  \`;
  document.querySelector("main").prepend(panel);
  panel.querySelector(".license-actions")?.insertAdjacentHTML("beforeend", '<button id="licenseBuyButton" class="secondary" type="button">\u8d2d\u4e70\u7eed\u8d39</button>');
  document.getElementById("licenseActivateButton").addEventListener("click", activateLicenseFromPanel);
  document.getElementById("licenseRefreshButton").addEventListener("click", () => refreshLicensePanel());
  document.getElementById("licenseClearButton").addEventListener("click", clearLicenseFromPanel);
  document.getElementById("licenseCopyMachineButton").addEventListener("click", copyLicenseMachineId);
  document.getElementById("licenseBuyButton")?.addEventListener("click", openLicensePurchasePage);
}

function openLicensePurchasePage() {
  const url = "https://xn--i2ru8q2qg.top";
  try {
    chrome.tabs.create({ url }).catch(() => window.open(url, "_blank"));
  } catch {
    window.open(url, "_blank");
  }
}

async function refreshLicensePanel(options = {}) {
  const statusEl = document.getElementById("licenseStatus");
  if (!globalThis.MiaoOnlineLicense) {
    statusEl.textContent = "授权模块未加载";
    statusEl.className = "license-status bad";
    return { ok: false, error: statusEl.textContent };
  }
  try {
    const status = await globalThis.MiaoOnlineLicense.getOnlineLicenseStatus({ action: "START_BATCH" });
    renderLicenseStatus(status);
    return status;
  } catch (error) {
    const status = { ok: false, error: error.message, machineId: await globalThis.MiaoOnlineLicense.getOrCreateMachineId().catch(() => "") };
    renderLicenseStatus(status);
    if (!options.silent) showNotice(error.message, true);
    return status;
  }
}

function renderLicenseStatus(status) {
  const statusEl = document.getElementById("licenseStatus");
  const panel = document.getElementById(LICENSE_PANEL_ID);
  panel?.classList.toggle("is-authorized", Boolean(status.ok));
  const code = status.license?.activationCode ? "" : "";
  if (status.ok) {
    statusEl.className = "license-status ok";
    statusEl.textContent = \`已授权，可用，剩余 \${status.daysRemaining || 0} 天，机器码：\${status.machineId || "-"}\`;
  } else {
    statusEl.className = "license-status bad";
    statusEl.textContent = \`\${status.error || "未授权"}，机器码：\${status.machineId || "-"}\${code}\`;
  }
}

async function activateLicenseFromPanel() {
  const input = document.getElementById("licenseCodeInput");
  const code = String(input.value || "").trim();
  if (!code) {
    showNotice("请先输入授权码", true);
    input.focus();
    return;
  }
  try {
    const status = await globalThis.MiaoOnlineLicense.activateOnlineLicense({ activationCode: code, action: "START_BATCH" });
    renderLicenseStatus(status);
    input.value = "";
    showNotice("授权激活成功");
  } catch (error) {
    renderLicenseStatus({ ok: false, error: error.message, machineId: await globalThis.MiaoOnlineLicense.getOrCreateMachineId().catch(() => "") });
    showNotice("授权激活失败：" + error.message, true);
  }
}

async function clearLicenseFromPanel() {
  await globalThis.MiaoOnlineLicense.clearOnlineLicense();
  await refreshLicensePanel({ silent: true });
  showNotice("已清除本机授权");
}

async function copyLicenseMachineId() {
  const machineId = await globalThis.MiaoOnlineLicense.getOrCreateMachineId();
  await navigator.clipboard.writeText(machineId);
  showNotice("机器码已复制");
}

async function ensureLicenseGate(action) {
  const status = await refreshLicensePanel({ silent: true });
  if (status.ok) return true;
  showNotice(status.error || "请先激活授权码", true);
  return false;
}`;
}

function replaceOnce(text, oldText, newText, label) {
  const count = text.split(oldText).length - 1;
  if (count !== 1) throw new Error(`${label}: expected 1 match, found ${count}`);
  return text.replace(oldText, newText);
}
