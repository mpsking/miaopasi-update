import path from 'node:path';
import { getDataDir, nowIso, readJson, writeJsonAtomic } from './util.mjs';

export function emptyDatabase() {
  return {
    schemaVersion: 1,
    createdAt: nowIso(),
    licenses: {},
    activations: {},
    deviceAuthorizations: {},
    orders: {},
    releases: {},
    batches: {},
    downloadCodes: {},
    downloads: {},
    securityEvents: {},
    audit: []
  };
}

export function normalizeDatabase(db) {
  const base = emptyDatabase();
  return {
    ...base,
    ...(db || {}),
    licenses: db?.licenses || {},
    activations: db?.activations || {},
    deviceAuthorizations: db?.deviceAuthorizations || {},
    orders: db?.orders || {},
    releases: db?.releases || {},
    batches: db?.batches || {},
    downloadCodes: db?.downloadCodes || {},
    downloads: db?.downloads || {},
    securityEvents: db?.securityEvents || {},
    audit: Array.isArray(db?.audit) ? db.audit : []
  };
}

export class Store {
  constructor(dataDir = getDataDir()) {
    this.dataDir = dataDir;
    this.dbFile = path.join(dataDir, 'db.json');
    this.queue = Promise.resolve();
  }

  async read() {
    return normalizeDatabase(await readJson(this.dbFile, emptyDatabase()));
  }

  async write(db) {
    await writeJsonAtomic(this.dbFile, db);
  }

  async init() {
    const db = await this.read();
    await this.write(db);
    return db;
  }

  async mutate(fn) {
    const run = async () => {
      const db = await this.read();
      const result = await fn(db);
      await this.write(db);
      return result;
    };
    const next = this.queue.then(run, run);
    this.queue = next.catch(() => {});
    return next;
  }
}

export function appendAudit(db, event, details = {}) {
  db.audit.push({
    id: `evt_${String(db.audit.length + 1).padStart(6, '0')}`,
    at: nowIso(),
    event,
    details
  });
  if (db.audit.length > 5000) db.audit = db.audit.slice(-5000);
}
