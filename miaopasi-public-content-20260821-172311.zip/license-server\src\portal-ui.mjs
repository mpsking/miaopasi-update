import { listProducts } from './products.mjs';

export function renderPublicPortal({ config, release, releases = [] }) {
  const availableReleaseItems = (releases.length ? releases : [release]).filter((item) => item?.available);
  const products = listProducts(config, releases);
  const productOptionsHtml = renderProductOptions(products, release?.publicGroup || release?.productId || config.productId);
  const productSelectHtml = products.length > 1
    ? `<label>选择插件<select name="productId">${productOptionsHtml}</select></label>`
    : `<input type="hidden" name="productId" value="${escapeHtml(products[0]?.productId || config.productId || '')}">`;
  return page({
    title: '妙妙工具',
    active: 'store',
    body: `
      <section class="hero">
        <div>
          <p class="eyebrow">妙妙工具</p>
          <h1>妙妙工具</h1>
          <p class="lead">下载更新小助手、购买授权码、提交续费申请都在这里完成。站长发布新版后，小助手会自动领取、校验并更新插件。</p>
          <div class="actions">
            <a class="btn primary" href="/喵帕斯解压版更新小助手.zip?v=loadfolder-20260807">下载更新小助手</a>
            <a class="btn" href="#buy">购买授权码</a>
            <a class="btn" href="#renew">续费</a>
          </div>
        </div>
        <aside class="panel release">
          <p class="eyebrow">使用方式</p>
          <h2>用小助手安装和更新</h2>
          <dl>
            <div><dt>最新版本</dt><dd>${escapeHtml(release?.version || '待发布')}</dd></div>
            <div><dt>可用插件</dt><dd>${escapeHtml(String(availableReleaseItems.length || 0))} 个</dd></div>
            <div><dt>安装目录</dt><dd>Flow 选【把这个放进去】；即梦双击启动器</dd></div>
            <div><dt>更新方式</dt><dd>再次运行小助手</dd></div>
          </dl>
        </aside>
      </section>

      <section class="split">
        <form class="panel form" id="buy" data-order-form>
          <p class="eyebrow">购买授权</p>
          <h2>购买授权码</h2>
          <input type="hidden" name="type" value="purchase">
          ${productSelectHtml}
          <label>客户名<input name="customerName" required placeholder="例如：张三 / 某某公司"></label>
          <label>联系方式<input name="contact" required placeholder="微信 / 手机 / 邮箱"></label>
          <div class="two">
            <label>授权天数<select name="days"><option value="30">30 天</option><option value="90">90 天</option><option value="365">365 天</option></select></label>
            <label>设备数<input name="maxDevices" type="number" min="1" value="1" required></label>
          </div>
          <label>备注<textarea name="notes" placeholder="订单号、付款截图说明、需要绑定的客户信息"></textarea></label>
          <button class="btn primary" type="submit">提交购买订单</button>
          <div class="result" data-result></div>
        </form>

        <form class="panel form" id="renew" data-order-form>
          <p class="eyebrow">授权续费</p>
          <h2>授权续费</h2>
          <input type="hidden" name="type" value="renew">
          <label>授权码<input name="activationCode" required placeholder="MM-XXXXX-XXXXX-XXXXX-XXXXX"></label>
          <label>联系方式<input name="contact" required placeholder="微信 / 手机 / 邮箱"></label>
          <div class="two">
            <label>续费天数<select name="days"><option value="30">30 天</option><option value="90">90 天</option><option value="365">365 天</option></select></label>
            <label>客户名<input name="customerName" placeholder="可选"></label>
          </div>
          <label>备注<textarea name="notes" placeholder="付款信息或续费说明"></textarea></label>
          <button class="btn primary" type="submit">提交续费申请</button>
          <div class="result" data-result></div>
        </form>
      </section>

      <section class="panel steps">
        <article><span>01</span><h3>下载小助手</h3><p>下载并解压更新小助手，双击对应插件的更新脚本。</p></article>
        <article><span>02</span><h3>输入下载码</h3><p>输入 DL 开头的下载码，小助手会自动下载、校验并放好插件。</p></article>
        <article><span>03</span><h3>启动插件</h3><p>Flow 在扩展管理页选择【把这个放进去】；即梦打开【双击打开这个文件夹】，双击【启动即梦独立窗口.cmd】，不要拖进扩展页。</p></article>
        <article><span>04</span><h3>输入授权码</h3><p>在插件侧边栏输入 MM 开头的授权码。后续更新只需要再次运行小助手。</p></article>
      </section>

      <script>
        const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        document.querySelectorAll('[data-order-form]').forEach(form => {
          form.addEventListener('submit', async event => {
            event.preventDefault();
            const result = form.querySelector('[data-result]');
            const body = Object.fromEntries(new FormData(form).entries());
            body.days = Number(body.days || 30);
            body.maxDevices = Number(body.maxDevices || 1);
            result.textContent = '提交中...';
            try {
              const res = await fetch('/api/v1/orders', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
              });
              const data = await res.json();
              if (!res.ok || data.ok === false) throw new Error(data.error || data.code || '提交失败');
              result.innerHTML = '已提交，订单号：<strong>' + h(data.order.orderId) + '</strong><br>后台确认后会处理授权。';
              form.reset();
            } catch (error) {
              result.textContent = '提交失败：' + error.message;
            }
          });
        });
      </script>`
  });
}

export function renderOwnerLogin() {
  return page({
    title: '站长后台登录',
    active: 'owner',
    body: `
      <section class="login panel">
        <p class="eyebrow">仅限站长</p>
        <h1>站长后台</h1>
        <p class="lead">输入站长账号和密码进入后台。登录成功后浏览器会保存一个后台会话凭据。</p>
        <form id="login-form" class="form">
          <label>管理员<input id="owner-username" name="username" autocomplete="username" required></label>
          <label>密码<input id="owner-password" name="password" type="password" autocomplete="current-password" required></label>
          <details>
            <summary>管理令牌应急入口</summary>
            <label>管理令牌<input id="owner-token" type="password" autocomplete="off"></label>
          </details>
          <button class="btn primary" type="submit">进入后台</button>
          <div class="result" id="login-result"></div>
        </form>
      </section>
      <script>
        document.getElementById('login-form').addEventListener('submit', async event => {
          event.preventDefault();
          const result = document.getElementById('login-result');
          result.textContent = '验证中...';
          try {
            const res = await fetch('/api/v1/admin/login', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                username: document.getElementById('owner-username').value,
                password: document.getElementById('owner-password').value,
                token: document.getElementById('owner-token').value
              })
            });
            const data = await res.json();
            if (!res.ok || data.ok === false) throw new Error(data.error || data.code || '登录失败');
            location.href = '/owner';
          } catch (error) {
            result.textContent = '登录失败：' + error.message;
          }
        });
      </script>`
  });
}

export function renderOwnerConsole({ config }) {
  const products = listProducts(config);
  const productOptionsHtml = renderProductOptions(products, config.productId);
  const productNames = Object.fromEntries(products.map((product) => [product.productId, product.name]));
  return page({
    title: '妙妙站长后台',
    active: 'owner',
    body: `
      <section class="owner">
        <div class="owner-head">
          <div>
            <p class="eyebrow">站长控制台</p>
            <h1>站长后台</h1>
          </div>
          <div class="actions">
            <a class="btn" href="/">公开页</a>
            <button class="btn" id="logout" type="button">退出</button>
          </div>
        </div>
        <div class="stats" id="stats"></div>

        <section class="split">
          <form class="panel form" id="upload-form">
            <label>所属插件<select name="publicGroup">${productOptionsHtml}</select></label>
            <p class="eyebrow">插件版本</p>
            <h2>上传插件</h2>
            <label>插件安装包<input name="file" type="file" accept=".zip,.crx,application/zip,application/x-chrome-extension" required></label>
            <div class="two">
              <label>版本<input name="version" value="${escapeHtml(config.minExtensionVersion || '2.17.2')}" required></label>
              <label>渠道<input name="channel" value="喵帕斯授权版" required></label>
            </div>
            <label>展示名称<input name="name" value="${escapeHtml(config.productName || '妙妙工具')}" required></label>
            <label>构建号<input name="buildId" placeholder="从 .build.json 的 buildId 复制，告警会用它追踪安装包"></label>
            <label>备注<textarea name="notes" placeholder="这次上传的变更说明"></textarea></label>
            <label class="check"><input name="setMinimumVersion" type="checkbox"> 上传后设为最低可用版本</label>
            <button class="btn primary" type="submit">上传并设为最新</button>
            <div class="result" id="upload-result"></div>
          </form>

          <form class="panel form" id="issue-form">
            <label>授权插件<select name="productId">${productOptionsHtml}</select></label>
            <p class="eyebrow">手动授权</p>
            <h2>生成授权码与下载码</h2>
            <p class="form-note">这里会同时生成两串码：MM 授权码用于插件激活，DL 下载码用于网页登录下载安装包。闲鱼成交后，两串都发给客户。</p>
            <label>客户名<input name="customerName" required></label>
            <label>联系方式<input name="contact" placeholder="微信 / 手机 / 邮箱"></label>
            <div class="two">
              <label>天数<input name="days" type="number" min="1" value="30" required></label>
              <label>设备数<input name="maxDevices" type="number" min="1" value="1" required></label>
            </div>
            <label>每台设备账号入口数<input name="maxProfilesPerDevice" type="number" min="1" value="20" required></label>
            <label>备注<textarea name="notes"></textarea></label>
            <button class="btn primary" type="submit">生成并发码</button>
            <div class="result-row">
              <div class="result" id="issue-result"></div>
              <button class="btn mini" id="issue-copy-code" type="button" disabled>复制两码</button>
            </div>
          </form>
        </section>

          <section class="panel form" id="batch-form-section">
            <p class="eyebrow">批量发码</p>
            <h2>批量生成授权码 + 下载码</h2>
            <p class="form-note">输入批次名称和数量后自动命名，例如「闲鱼」生成 99 组就是 闲鱼1～闲鱼99。每组都包含 1 个下载码和 1 个授权码；授权码未激活前不计时，首次激活才开始计算时长。</p>
            <form id="batch-form" class="form">
              <label>授权插件<select name="productId">${productOptionsHtml}</select></label>
              <div class="two">
                <label>批次名称<input name="name" required placeholder="例如：闲鱼"></label>
                <label>数量<input name="count" type="number" min="1" max="5000" value="99" required></label>
              </div>
              <label>使用时长<select name="plan">
                <option value="trial7">7 天体验</option>
                <option value="month1" selected>1 个月</option>
                <option value="month2">2 个月</option>
                <option value="month3">3 个月</option>
                <option value="month4">4 个月</option>
                <option value="month5">5 个月</option>
                <option value="month6">6 个月</option>
                <option value="month7">7 个月</option>
                <option value="month8">8 个月</option>
                <option value="month9">9 个月</option>
                <option value="month10">10 个月</option>
                <option value="month11">11 个月</option>
                <option value="month12">12 个月</option>
              </select></label>
              <div class="two">
                <label>设备数<input name="maxDevices" type="number" min="1" value="1" required></label>
                <label>每台设备账号入口数<input name="maxProfilesPerDevice" type="number" min="1" value="20" required></label>
              </div>
              <label>备注<textarea name="notes" placeholder="批次备注，例如渠道名称"></textarea></label>
              <button class="btn primary" type="submit">生成批次</button>
              <div class="result" id="batch-result"></div>
              <a class="btn mini" id="batch-download" style="display:none" href="#">下载文本</a>
            </form>
          </section>

          <div id="batches"></div>

        ${tableShell('orders', '订单与续费申请', '<th>状态</th><th>类型</th><th>客户</th><th>申请内容</th><th>时间</th><th>操作</th>')}
        ${tableShell('licenses', '授权用户', '<th>状态</th><th>插件</th><th>客户</th><th>授权码</th><th>设备 / 账号入口</th><th>到期</th><th>操作</th>')}
        ${tableShell('devices', '设备绑定概览', '<th>状态</th><th>设备</th><th>插件</th><th>客户</th><th>账号入口</th><th>最近在线</th><th>新增记录</th>')}
        ${tableShell('releases', '插件版本', '<th>版本</th><th>文件</th><th>构建号</th><th>大小</th><th>校验值</th><th>时间</th><th>链接</th>')}
        ${tableShell('download-codes', '下载码', '<th>状态</th><th>下载码</th><th>插件</th><th>客户</th><th>关联授权</th><th>下载</th><th>到期</th><th>操作</th>')}
        ${tableShell('downloads', '下载记录', '<th>时间</th><th>客户</th><th>安装包</th><th>下载码</th><th>来源</th><th>状态</th>')}
        ${tableShell('activations', '设备激活', '<th>状态</th><th>激活编号</th><th>授权编号</th><th>设备 / 入口</th><th>扩展</th><th>最近在线</th><th>操作</th>')}
        ${tableShell('security-events', '安全告警', '<th>时间</th><th>级别</th><th>插件</th><th>扩展 ID</th><th>安装包</th><th>机器码</th><th>事件</th><th>来源</th>')}
      </section>

      <script>
        const productNames = ${JSON.stringify(productNames)};
        const el = id => document.getElementById(id);
        const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        const productLabel = id => productNames[id] || id || '-';
        const fmt = value => {
          if (!value) return '-';
          const date = new Date(value);
          return Number.isFinite(date.getTime()) ? date.toLocaleString('zh-CN', { hour12:false }) : String(value);
        };
        const size = bytes => !bytes ? '-' : (Number(bytes) / 1024 / 1024).toFixed(2) + ' MB';
        const statusText = { active:'有效', expired:'已过期', revoked:'已吊销', banned:'已封禁', pending:'待处理', fulfilled:'已完成', cancelled:'已取消', offline:'未开放', issued:'已发链接', downloaded:'已下载' };
        const tag = value => '<span class="tag ' + h(value) + '">' + h(statusText[value] || value || '-') + '</span>';
        const licenseFilterText = { active:'在期/未激活', expired:'已过期', banned:'已封禁', revoked:'已吊销', all:'全部' };
        let licenseFilter = 'active';
        let cachedLicenses = [];

        async function api(path, options = {}) {
          const headers = options.headers || {};
          if (options.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
          const res = await fetch(path, { ...options, headers });
          const data = await res.json().catch(() => ({}));
          if (!res.ok || data.ok === false) throw new Error(data.error || data.code || ('HTTP ' + res.status));
          return data;
        }

        async function loadState() {
          const state = await api('/api/v1/admin/state');
          renderStats(state.summary);
          renderOrders(state.orders || []);
          renderLicenses(state.licenses || []);
          renderBatches(state.batches || []);
          renderDevices(state.devices || []);
          renderReleases(state.releases || []);
          renderDownloadCodes(state.downloadCodes || []);
          renderDownloads(state.downloads || []);
          renderActivations(state.activations || []);
          renderSecurityEvents(state.securityEvents || []);
        }

        function renderBatches(batches) {
          const list = Array.isArray(batches) ? batches : [];
          el('batches').innerHTML = list.length ? list.map(batch => {
            const head = '<div class="table-head"><h2>批量授权 · ' + h(batch.name) + '</h2><span class="muted">' + h(batch.planLabel || '-') + ' · ' + h(batch.count) + ' 组</span><div class="table-head-actions"><a class="btn mini" href="/api/v1/admin/batches/export?batchId=' + h(batch.batchId) + '">导出文本</a><button class="btn mini" type="button" data-toggle-table>展开</button></div></div>';
            const summary = '<div class="license-tools batch-summary"><span>未激活 ' + h(batch.pendingCount || 0) + '</span><span>已激活 ' + h(batch.activatedCount || 0) + '</span><span>封禁 ' + h(batch.bannedCount || 0) + '</span><span>吊销 ' + h(batch.revokedCount || 0) + '</span></div>';
            const rows = (batch.items || []).map(item => {
              const code = h(item.activationCode || '');
              const downloadCode = h((item.downloadCode && item.downloadCode.code) || '');
              const expires = item.status === 'pending' ? ('激活后 ' + h(item.planLabel || (item.days + '天'))) : h(fmt(item.expiresAt));
              return '<tr>' +
                '<td>' + tag(item.status === 'pending' ? '未激活' : licenseStatus(item)) + '</td>' +
                '<td><strong>' + h(item.customerName || '-') + '</strong><br><span class="muted mono">' + h(item.batchName || '') + ' #' + h(item.batchIndex || '-') + '</span></td>' +
                '<td><span class="mono">' + code + '</span></td>' +
                '<td><span class="mono">' + downloadCode + '</span></td>' +
                '<td>' + h(item.planLabel || '-') + '</td>' +
                '<td>' + expires + '</td>' +
                '<td>' + h(item.activeDeviceCount || 0) + ' / ' + h(item.maxDevices || 1) + ' 设备</td>' +
                '<td><div class="row-actions">' +
                  '<button class="btn mini" data-copy="' + code + '">复制授权码</button>' +
                  (downloadCode ? '<button class="btn mini" data-copy="' + downloadCode + '">复制下载码</button>' : '') +
                  '<button class="btn mini" data-extend-license="' + h(item.licenseId) + '" data-days="30">续 30 天</button>' +
                  (item.status !== 'banned' ? '<button class="btn mini danger" data-ban-license="' + h(item.licenseId) + '">封禁</button>' : '') +
                '</div></td>' +
              '</tr>';
            }).join('');
            return '<section class="panel table-card collapsed" data-table-card="batch-' + h(batch.batchId) + '">' + head + '<div class="table-wrap">' + summary + '<table><thead><tr><th>状态</th><th>编号/名称</th><th>授权码（体验码）</th><th>下载码</th><th>时长</th><th>到期</th><th>设备</th><th>操作</th></tr></thead><tbody>' + (rows || '<tr><td colspan="8">空批次</td></tr>') + '</tbody></table></div></section>';
          }).join('') : '<section class="panel table-card"><div class="table-head"><h2>批量授权</h2><span class="muted">暂无批量批次</span></div></section>';
        }

        function renderStats(summary) {
          const cards = [
            ['待处理订单', summary.pendingOrderCount],
            ['授权总数', summary.licenseCount],
            ['有效授权', summary.activeLicenseCount],
            ['过期授权', summary.expiredLicenseCount || 0],
              ['未激活授权', summary.pendingLicenseCount || 0],
              ['批量批次', summary.batchCount || 0],
            ['封禁授权', summary.bannedLicenseCount],
            ['活跃设备', summary.activeDeviceGroupCount || 0],
            ['账号入口', summary.activeProfileCount || 0],
            ['下载码', summary.downloadCodeCount || 0],
            ['下载记录', summary.downloadCount || 0],
            ['插件版本', summary.releaseCount],
            ['安全告警', summary.securityEventCount || 0]
          ];
          el('stats').innerHTML = cards.map(([label, value]) => '<div class="stat panel"><span>' + h(label) + '</span><strong>' + h(value) + '</strong></div>').join('');
        }

        function renderOrders(orders) {
          el('orders-body').innerHTML = orders.length ? orders.map(order =>
            '<tr>' +
              '<td>' + tag(order.status) + '</td>' +
              '<td>' + h(order.type === 'renew' ? '续费' : '购买') + '</td>' +
              '<td><strong>' + h(order.customerName || '-') + '</strong><br><span class="muted">' + h(order.contact || '-') + '</span></td>' +
              '<td>' + h(order.planDays) + ' 天 / ' + h(order.maxDevices || 1) + ' 设备 / 每设备 ' + h(order.maxProfilesPerDevice || 20) + ' 入口<br><span class="mono">' + h(order.activationCode || order.licenseId || '') + '</span><br><span class="muted">' + h(order.notes || '') + '</span></td>' +
              '<td>' + h(fmt(order.createdAt)) + '</td>' +
              '<td><div class="row-actions">' + (order.status === 'pending' ? '<button class="btn mini primary" data-approve-order="' + h(order.orderId) + '">确认处理</button><button class="btn mini danger" data-cancel-order="' + h(order.orderId) + '">取消</button>' : '-') + '</div></td>' +
            '</tr>'
          ).join('') : '<tr><td colspan="6">暂无订单。</td></tr>';
        }

        function renderLicenses(licenses) {
          cachedLicenses = Array.isArray(licenses) ? licenses : [];
          const grouped = { active:0, expired:0, banned:0, revoked:0, all:cachedLicenses.length };
          const rows = cachedLicenses.map(license => ({ ...license, computedStatus: licenseStatus(license) }));
          rows.forEach(license => {
            if (license.computedStatus === 'pending') {
              grouped.active += 1;
            } else if (grouped[license.computedStatus] !== undefined) {
              grouped[license.computedStatus] += 1;
            }
          });
          renderLicenseFilters(grouped);
          const visible = licenseFilter === 'all'
            ? rows
            : rows.filter(license => license.computedStatus === licenseFilter || (licenseFilter === 'active' && license.computedStatus === 'pending'));
          el('licenses-body').innerHTML = visible.length ? visible.map(license => {
            const code = h(license.activationCode);
            const product = h(productLabel(license.productId));
            const expires = license.status === 'pending'
              ? ('激活后 ' + h(license.days + '天'))
              : h(fmt(license.expiresAt));
            const expiresNote = license.computedStatus === 'expired' ? '<br><span class="danger">已过期</span>' : '';
            return '<tr>' +
              '<td>' + tag(license.computedStatus) + '</td>' +
              '<td><strong>' + product + '</strong><br><span class="muted mono">' + h(license.productId || '-') + '</span></td>' +
              '<td><strong>' + h(license.customerName || '-') + '</strong><br><span class="muted">' + h(license.contact || license.customerId || '-') + '</span></td>' +
              '<td><span class="mono">' + code + '</span></td>' +
              '<td>' + h(license.activeDeviceCount || 0) + ' / ' + h(license.maxDevices || 1) + ' 设备<br><span class="muted">' + h(license.activeProfileCount || 0) + ' 个入口，单设备最多 ' + h(license.maxProfilesPerDevice || 20) + '</span></td>' +
              '<td>' + expires + expiresNote + '</td>' +
              '<td><div class="row-actions">' +
                '<button class="btn mini" data-copy="' + code + '">复制</button>' +
                '<button class="btn mini" data-issue-download-code="' + h(license.licenseId) + '">生成下载码</button>' +
                '<button class="btn mini" data-extend-license="' + h(license.licenseId) + '" data-days="30">续 30 天</button>' +
                '<button class="btn mini" data-extend-license="' + h(license.licenseId) + '" data-days="365">续 1 年</button>' +
                (license.status !== 'banned' ? '<button class="btn mini danger" data-ban-license="' + h(license.licenseId) + '">封禁</button>' : '') +
                (license.status === 'banned' ? '<button class="btn mini danger" data-delete-banned-license="' + h(license.licenseId) + '">删除</button>' : '') +
              '</div></td>' +
            '</tr>';
          }).join('') : '<tr><td colspan="7">暂无' + h(licenseFilterText[licenseFilter] || '') + '授权。</td></tr>';
        }

        function licenseStatus(license) {
          if (license.status === 'banned') return 'banned';
          if (license.status === 'revoked') return 'revoked';
          if (license.status === 'pending') return 'pending';
          if (license.status === 'active') {
            const expiresAt = Date.parse(license.expiresAt || '');
            return Number.isFinite(expiresAt) && expiresAt <= Date.now() ? 'expired' : 'active';
          }
          return license.status || 'unknown';
        }

        function renderLicenseFilters(grouped) {
          const box = el('license-filters');
          if (!box) return;
          const keys = ['active', 'expired', 'banned', 'revoked', 'all'];
          box.innerHTML = keys.map(key =>
            '<button class="btn mini license-filter ' + (licenseFilter === key ? 'active' : '') + '" type="button" data-license-filter="' + h(key) + '">' +
              h(licenseFilterText[key]) + ' <span>' + h(grouped[key] || 0) + '</span>' +
            '</button>'
          ).join('');
        }

        function renderDevices(devices) {
          el('devices-body').innerHTML = devices.length ? devices.map(device => {
            const entries = (device.entries || []).map(entry =>
              '<div class="profile-entry">' +
                '<strong>' + h(entry.profileLabel || entry.profileKey || '入口') + '</strong>' +
                '<span>' + h(entry.extensionVersion || '-') + ' / ' + h(fmt(entry.createdAt)) + '</span>' +
              '</div>'
            ).join('');
            return '<tr>' +
              '<td>' + tag(device.status) + '</td>' +
              '<td><strong>' + h(device.deviceLabel || '-') + '</strong><br><span class="muted mono">' + h(device.licenseId || '-') + '</span></td>' +
              '<td><strong>' + h(productLabel(device.productId)) + '</strong><br><span class="muted mono">' + h(device.productId || '-') + '</span></td>' +
              '<td><strong>' + h(device.customerName || '-') + '</strong><br><span class="muted mono">' + h(device.customerId || '-') + '</span></td>' +
              '<td>' + h(device.activeProfileCount || 0) + ' / ' + h(device.maxProfilesPerDevice || 20) + '<br><span class="muted">累计 ' + h(device.profileCount || 0) + ' 个入口</span></td>' +
              '<td>' + h(fmt(device.lastSeenAt)) + '</td>' +
              '<td><div class="profile-list">' + (entries || '<span class="muted">暂无入口</span>') + '</div></td>' +
            '</tr>';
          }).join('') : '<tr><td colspan="7">暂无设备绑定。</td></tr>';
        }

        function renderReleases(releases) {
          el('releases-body').innerHTML = releases.length ? releases.map(release =>
            '<tr>' +
              '<td>' + h(release.version) + '<br><span class="muted">' + h(release.channel || '') + '</span></td>' +
              '<td>' + h(release.fileName) + '<br><span class="muted">' + h((release.packageType || 'zip').toUpperCase()) + '</span></td>' +
              '<td class="mono">' + h(release.buildId || '-') + '</td>' +
              '<td>' + h(size(release.sizeBytes)) + '</td>' +
              '<td class="mono">' + h(release.sha256) + '</td>' +
              '<td>' + h(fmt(release.createdAt || release.updatedAt)) + '</td>' +
              '<td><a class="btn mini" href="' + h(release.downloadPath) + '">下载</a></td>' +
            '</tr>'
          ).join('') : '<tr><td colspan="7">暂无上传版本。</td></tr>';
        }

        function renderDownloadCodes(downloadCodes) {
          el('download-codes-body').innerHTML = downloadCodes.length ? downloadCodes.map(downloadCode => {
            const code = h(downloadCode.code || '');
            return '<tr>' +
              '<td>' + tag(downloadCode.status || '-') + '</td>' +
              '<td class="mono">' + code + '</td>' +
              '<td><strong>' + h(productLabel(downloadCode.productId)) + '</strong><br><span class="muted mono">' + h(downloadCode.productId || '-') + '</span></td>' +
              '<td><strong>' + h(downloadCode.customerName || '-') + '</strong><br><span class="muted">' + h(downloadCode.contact || downloadCode.customerId || '-') + '</span></td>' +
              '<td class="mono">' + h(downloadCode.licenseId || '-') + '<br><span class="muted">授权尾号 ' + h(downloadCode.licenseActivationCodeSuffix || '-') + '</span></td>' +
              '<td>' + h(downloadCode.downloadCount || 0) + ' 次<br><span class="muted">' + h(downloadCode.lastDownloadedAt ? fmt(downloadCode.lastDownloadedAt) : '-') + '</span></td>' +
              '<td>' + h(fmt(downloadCode.expiresAt)) + '</td>' +
              '<td><div class="row-actions"><button class="btn mini" data-copy="' + code + '">复制</button></div></td>' +
            '</tr>';
          }).join('') : '<tr><td colspan="8">暂无下载码。</td></tr>';
        }

        function renderDownloads(downloads) {
          el('downloads-body').innerHTML = downloads.length ? downloads.map(download =>
            '<tr>' +
              '<td>' + h(fmt(download.createdAt)) + '<br><span class="muted">' + h(download.usedAt ? ('下载：' + fmt(download.usedAt)) : ('过期：' + fmt(download.expiresAt))) + '</span></td>' +
              '<td><strong>' + h(download.customerName || '-') + '</strong><br><span class="muted">' + h(download.contact || download.customerId || '-') + '</span></td>' +
              '<td><strong>' + h(download.releaseName || '-') + '</strong><br><span class="muted">' + h(download.version || '-') + ' / ' + h(download.packageType || '-') + '</span><br><span class="mono muted">' + h(download.buildId || download.releaseId || '-') + '</span></td>' +
              '<td class="mono">尾号 ' + h(download.downloadCodeSuffix || download.activationCodeSuffix || '-') + '<br><span class="muted">' + h(download.downloadCodeId || download.licenseId || '-') + '</span></td>' +
              '<td class="mono">' + h(download.usedIp || download.ip || '-') + '<br><span class="muted">' + h(download.usedUserAgent || download.userAgent || '') + '</span></td>' +
              '<td>' + tag(download.status || '-') + '</td>' +
            '</tr>'
          ).join('') : '<tr><td colspan="6">暂无下载记录。</td></tr>';
        }

        function renderActivations(activations) {
          el('activations-body').innerHTML = activations.length ? activations.map(activation =>
            '<tr>' +
              '<td>' + tag(activation.status) + '</td>' +
              '<td class="mono">' + h(activation.activationId) + '</td>' +
              '<td class="mono">' + h(activation.licenseId) + '</td>' +
              '<td>' + h(activation.deviceLabel || '-') + '<br><span class="muted">' + h(activation.profileLabel || activation.profileKey || '-') + '</span></td>' +
              '<td>' + h(activation.extensionVersion) + '<br><span class="muted mono">' + h(activation.extensionId) + '</span></td>' +
              '<td>' + h(fmt(activation.lastSeenAt || activation.createdAt)) + '</td>' +
              '<td>' + (activation.status === 'active' ? '<button class="btn mini danger" data-revoke-activation="' + h(activation.activationId) + '">吊销设备</button>' : '-') + '</td>' +
            '</tr>'
          ).join('') : '<tr><td colspan="7">暂无设备激活。</td></tr>';
        }

        function renderSecurityEvents(events) {
          el('security-events-body').innerHTML = events.length ? events.map(event =>
            '<tr>' +
              '<td>' + h(fmt(event.createdAt)) + '</td>' +
              '<td>' + h(event.severity || '-') + '</td>' +
              '<td>' + h(productLabel(event.productId)) + '<br><span class="muted mono">' + h(event.productId || '-') + '</span></td>' +
              '<td class="mono">' + h(event.extensionId || '-') + '<br><span class="muted">' + h(event.extensionVersion || '-') + '</span></td>' +
              '<td class="mono">' + h(event.buildId || event.releaseId || '-') + '<br><span class="muted">' + h(event.sourcePackage || event.packageSha256 || '') + '</span></td>' +
              '<td class="mono">' + h(event.machineId || '-') + '</td>' +
              '<td><strong>' + h(event.eventType || '-') + '</strong><br><span class="muted">' + h(event.code || '') + ' ' + h(event.message || '') + '</span><br><span class="danger">' + h(event.warning || '') + '</span></td>' +
              '<td class="mono">' + h(event.ip || '-') + '<br><span class="muted">' + h(event.userAgent || '') + '</span></td>' +
            '</tr>'
          ).join('') : '<tr><td colspan="8">暂无安全告警。</td></tr>';
        }

        function fileToBase64(file) {
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result).split(',').pop());
            reader.onerror = () => reject(reader.error || new Error('读取文件失败'));
            reader.readAsDataURL(file);
          });
        }

        el('upload-form').addEventListener('submit', async event => {
          event.preventDefault();
          const result = el('upload-result');
          const form = event.currentTarget;
          const file = form.file.files[0];
          result.textContent = '上传中...';
          try {
            const body = Object.fromEntries(new FormData(form).entries());
            body.fileName = file.name;
            body.contentBase64 = await fileToBase64(file);
            delete body.file;
            const data = await api('/api/v1/admin/releases/upload', { method:'POST', body:JSON.stringify(body) });
            result.textContent = '上传成功：' + data.release.downloadPath;
            form.reset();
            await loadState();
          } catch (error) {
            result.textContent = '上传失败：' + error.message;
          }
        });

        el('issue-form').addEventListener('submit', async event => {
          event.preventDefault();
          const result = el('issue-result');
          const copyButton = el('issue-copy-code');
          const body = Object.fromEntries(new FormData(event.currentTarget).entries());
          body.days = Number(body.days || 30);
          body.maxDevices = Number(body.maxDevices || 1);
          body.maxProfilesPerDevice = Number(body.maxProfilesPerDevice || 20);
          result.textContent = '生成中...';
          copyButton.disabled = true;
          copyButton.dataset.code = '';
          copyButton.textContent = '复制两码';
          try {
            const data = await api('/api/v1/admin/issue', { method:'POST', body:JSON.stringify(body) });
            const activationCode = data.license.activationCode;
            const downloadCode = data.downloadCode?.code || '';
            const copyText = '授权码：' + activationCode + '\\n下载码：' + downloadCode;
            result.textContent = copyText + '\\n到期：' + (data.license.status === 'pending' ? '激活后开始计时' : fmt(data.license.expiresAt));
            copyButton.dataset.code = copyText;
            copyButton.disabled = false;
            await navigator.clipboard.writeText(copyText).catch(() => {});
            await loadState();
          } catch (error) {
            result.textContent = '生成失败：' + error.message;
          }
        });

        el('batch-form').addEventListener('submit', async event => {
          event.preventDefault();
          const result = el('batch-result');
          const link = el('batch-download');
          const body = Object.fromEntries(new FormData(event.currentTarget).entries());
          body.count = Number(body.count || 1);
          body.maxDevices = Number(body.maxDevices || 1);
          body.maxProfilesPerDevice = Number(body.maxProfilesPerDevice || 20);
          result.textContent = '生成中...';
          link.style.display = 'none';
          try {
            const data = await api('/api/v1/admin/batch-issue', { method:'POST', body:JSON.stringify(body) });
            result.textContent = '批次「' + data.batch.name + '」生成完成：' + data.itemCount + ' 组（授权码 + 下载码）。';
            link.href = '/api/v1/admin/batches/export?batchId=' + encodeURIComponent(data.batch.batchId);
            link.style.display = 'inline-flex';
            link.textContent = '下载文本';
            await loadState();
          } catch (error) {
            result.textContent = '生成失败：' + error.message;
          }
        });

        el('issue-copy-code').addEventListener('click', async event => {
          const button = event.currentTarget;
          const code = button.dataset.code || '';
          if (!code) return;
          await navigator.clipboard.writeText(code);
          button.textContent = '已复制';
          setTimeout(() => button.textContent = '复制两码', 1000);
        });

        document.addEventListener('click', async event => {
          const toggleTable = event.target.closest('[data-toggle-table]');
          if (toggleTable) {
            const card = toggleTable.closest('[data-table-card]');
            const collapsed = !card.classList.contains('collapsed');
            card.classList.toggle('collapsed', collapsed);
            toggleTable.textContent = collapsed ? '展开' : '收起';
            return;
          }
          const licenseFilterButton = event.target.closest('[data-license-filter]');
          if (licenseFilterButton) {
            licenseFilter = licenseFilterButton.dataset.licenseFilter || 'active';
            renderLicenses(cachedLicenses);
            return;
          }
          const copy = event.target.closest('[data-copy]');
          if (copy) {
            await navigator.clipboard.writeText(copy.dataset.copy);
            copy.textContent = '已复制';
            setTimeout(() => copy.textContent = '复制', 1000);
            return;
          }
          const issueDownloadCode = event.target.closest('[data-issue-download-code]');
          if (issueDownloadCode) {
            issueDownloadCode.disabled = true;
            const oldText = issueDownloadCode.textContent;
            issueDownloadCode.textContent = '生成中';
            try {
              const data = await api('/api/v1/admin/download-codes/issue', { method:'POST', body:JSON.stringify({ licenseId: issueDownloadCode.dataset.issueDownloadCode }) });
              const code = data.downloadCode?.code || '';
              if (code) await navigator.clipboard.writeText(code).catch(() => {});
              alert('下载码：' + code + '\\n已复制到剪贴板。');
              await loadState();
            } finally {
              issueDownloadCode.disabled = false;
              issueDownloadCode.textContent = oldText;
            }
            return;
          }
          const approve = event.target.closest('[data-approve-order]');
          if (approve) {
            const data = await api('/api/v1/admin/orders/approve', { method:'POST', body:JSON.stringify({ orderId: approve.dataset.approveOrder }) });
            if (data.downloadCode?.code) {
              const text = '授权码：' + (data.license?.activationCode || '') + '\\n下载码：' + data.downloadCode.code;
              await navigator.clipboard.writeText(text).catch(() => {});
              alert(text + '\\n已复制到剪贴板。');
            }
            await loadState();
            return;
          }
          const cancel = event.target.closest('[data-cancel-order]');
          if (cancel && confirm('确认取消这个订单？')) {
            await api('/api/v1/admin/orders/cancel', { method:'POST', body:JSON.stringify({ orderId: cancel.dataset.cancelOrder, reason:'owner-cancel' }) });
            await loadState();
            return;
          }
          const extend = event.target.closest('[data-extend-license]');
          if (extend) {
            await api('/api/v1/admin/extend', { method:'POST', body:JSON.stringify({ licenseId: extend.dataset.extendLicense, days: Number(extend.dataset.days || 30) }) });
            await loadState();
            return;
          }
          const ban = event.target.closest('[data-ban-license]');
          if (ban && confirm('确认封禁这个授权？封禁后对应设备也会停用。')) {
            await api('/api/v1/admin/ban', { method:'POST', body:JSON.stringify({ licenseId: ban.dataset.banLicense, reason:'owner-ban' }) });
            await loadState();
            return;
          }
          const deleteBanned = event.target.closest('[data-delete-banned-license]');
          if (deleteBanned && confirm('确认删除这个已封禁授权？删除后授权和关联设备记录都会从列表移除。')) {
            await api('/api/v1/admin/licenses/delete', { method:'POST', body:JSON.stringify({ licenseId: deleteBanned.dataset.deleteBannedLicense }) });
            await loadState();
            return;
          }
          const revokeActivation = event.target.closest('[data-revoke-activation]');
          if (revokeActivation && confirm('确认吊销这个设备？')) {
            await api('/api/v1/admin/revoke', { method:'POST', body:JSON.stringify({ activationId: revokeActivation.dataset.revokeActivation, reason:'owner-revoke-device' }) });
            await loadState();
          }
        });

        el('logout').addEventListener('click', async () => {
          await fetch('/api/v1/admin/logout', { method:'POST' });
          location.href = '/';
        });

        loadState().catch(error => {
          document.body.innerHTML = '<main class="login panel"><h1>后台已锁定</h1><p class="lead">' + h(error.message) + '</p><a class="btn primary" href="/owner">重新登录</a></main>';
        });
      </script>`
  });
}

function tableShell(id, title, head) {
  const colspan = (String(head).match(/<th/g) || []).length || 6;
  const tools = id === 'licenses' ? '<div class="license-tools" id="license-filters"></div>' : '';
  return `<section class="panel table-card collapsed" data-table-card="${escapeHtml(id)}"><div class="table-head"><h2>${escapeHtml(title)}</h2><div class="table-head-actions"><button class="btn mini" onclick="location.reload()">刷新</button><button class="btn mini" type="button" data-toggle-table="${escapeHtml(id)}">展开</button></div></div>${tools}<div class="table-wrap"><table><thead><tr>${head}</tr></thead><tbody id="${id}-body"><tr><td colspan="${colspan}">加载中...</td></tr></tbody></table></div></section>`;
}

function renderProductOptions(products, selectedProductId = '') {
  return products.map((product) => {
    const selected = product.productId === selectedProductId ? ' selected' : '';
    const label = product.minExtensionVersion
      ? `${product.name}（最低 ${product.minExtensionVersion}）`
      : product.name;
    return `<option value="${escapeHtml(product.productId)}"${selected}>${escapeHtml(label)}</option>`;
  }).join('');
}

function page({ title, active, body }) {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>
    :root{--bg:#050606;--fg:#fff;--muted:#b7b7b7;--line:#3d4140;--soft:rgba(255,255,255,.06);--card:rgba(0,0,0,.6);--accent:#3b3f6a;--bad:#ff9b9b;--ok:#b9ffd9;--sans:"Inter","Segoe UI",Arial,sans-serif;--serif:"Times New Roman",Georgia,serif}
    *{box-sizing:border-box}
    html,body{margin:0;min-height:100%;background:#000;color:var(--fg);font-family:var(--sans);overflow-x:hidden}
    body::before{content:"";position:fixed;inset:0;background:radial-gradient(circle at 50% 18%,rgba(90,99,160,.34),transparent 24rem),radial-gradient(circle at 8% 5%,rgba(55,130,111,.22),transparent 20rem),#000;z-index:-2}
    body::after{content:"";position:fixed;inset:0;background-image:radial-gradient(rgba(210,214,255,.7) 1px,transparent 1px);background-size:96px 96px;opacity:.32;z-index:-1}
    .shell{min-height:100vh;padding:28px clamp(16px,4vw,56px) 42px}
    header{display:flex;justify-content:space-between;align-items:center;gap:18px;max-width:1180px;margin:0 auto}
    .brand{display:flex;gap:12px;align-items:center;color:#fff;text-decoration:none}.mark{width:36px;height:36px;border:1px solid #fff;border-radius:50%;display:grid;place-items:center}.mark::before{content:"";width:12px;height:12px;border:1px solid #fff;transform:rotate(45deg)}.brand strong{display:block;font-size:14px}.brand span span{font-size:10px;color:var(--muted)}
    nav{display:flex;gap:8px;flex-wrap:wrap}nav a{color:#fff;text-decoration:none;border:1px solid rgba(255,255,255,.55);border-radius:6px;padding:5px 10px;font-size:12px;background:rgba(0,0,0,.24)}nav a.active{background:rgba(255,255,255,.12)}
    main{width:100%;max-width:1180px;margin:0 auto;padding-top:84px}.hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(280px,380px);gap:18px;align-items:stretch}.hero h1,.login h1,.owner h1{font-family:var(--serif);font-size:clamp(52px,8vw,112px);line-height:.92;font-weight:400;margin:0 0 20px;letter-spacing:0}.lead{font-family:var(--serif);font-size:18px;line-height:1.9;color:#eee;max-width:680px}.eyebrow{margin:0 0 14px;color:var(--muted);font-size:10px;text-transform:uppercase;letter-spacing:.08em}
    .panel{border:1px solid var(--line);border-radius:12px;background:var(--card);backdrop-filter:blur(5px);padding:24px;min-width:0}.release h2,.form h2,.table-head h2{font-size:20px;margin:0 0 16px}.release dl{display:grid;gap:14px;margin:0}.release dl div{border-bottom:1px solid rgba(255,255,255,.12);padding-bottom:12px}.release dl div:last-child{border:0;padding:0}dt{font-size:10px;color:var(--muted);text-transform:uppercase}dd{margin:5px 0 0;word-break:break-word}.mono{font-family:Consolas,"SFMono-Regular",monospace;overflow-wrap:anywhere}
    .actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:28px}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:34px;border:1px solid rgba(255,255,255,.62);border-radius:999px;padding:7px 18px;background:rgba(0,0,0,.32);color:#fff;text-decoration:none;font-weight:700;font-size:14px;cursor:pointer}.btn.primary{background:var(--accent);border-color:var(--accent)}.btn.danger,.danger{border-color:rgba(255,120,120,.62);color:#ffd5d5}.btn.mini{min-height:28px;padding:4px 10px;font-size:12px}
    .split{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:16px}.form{display:grid;gap:12px}.form label{display:grid;gap:6px;color:var(--muted);font-size:11px;text-transform:uppercase}.form-note{margin:0;color:var(--muted);font-size:13px;line-height:1.7}.form .check{display:flex;align-items:center;gap:8px;text-transform:none;color:#eee}.form .check input{width:16px;min-height:16px;padding:0}.two{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}input,select,textarea{width:100%;min-height:40px;border:1px solid rgba(255,255,255,.24);border-radius:7px;background:rgba(255,255,255,.08);color:#fff;padding:9px 11px;font:14px/1.4 var(--sans);outline:none}textarea{min-height:88px;resize:vertical}option{background:#111}.result-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:stretch}.result-row .btn{min-height:42px;white-space:nowrap}.result{min-height:42px;border:1px solid rgba(255,255,255,.14);border-radius:8px;background:rgba(255,255,255,.05);padding:12px;color:#eee;font-size:13px;line-height:1.6;white-space:pre-wrap}
    .steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-top:16px}.steps article{padding:8px}.steps span{display:block;color:var(--muted);font-size:10px;margin-bottom:32px}.steps h3{margin:0 0 10px}.steps p{font-family:var(--serif);font-size:16px;line-height:1.75;color:#eee;margin:0}
    .release-list{margin-top:16px}.section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;margin-bottom:12px}.section-head h2{margin:0;font-size:24px}.release-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px}.release-item{display:grid;gap:14px}.release-item h3{margin:0;font-size:17px;line-height:1.35}.release-item dl{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:0}.release-item dl div{border-top:1px solid rgba(255,255,255,.12);padding-top:10px}.release-item .btn{width:100%}
    .download-gate{display:grid;grid-template-columns:minmax(0,1fr) minmax(260px,380px);gap:18px;align-items:end;margin-bottom:12px}.download-gate h3{margin:0 0 8px;font-size:20px}.download-gate p{margin:0}.download-code-row{display:grid;gap:8px}
    .login{max-width:620px;margin:0 auto}.owner-head{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:12px}.stat{padding:18px}.stat span{display:block;color:var(--muted);font-size:10px;text-transform:uppercase;margin-bottom:8px}.stat strong{font-size:28px;font-weight:400}
.batch-summary{display:flex;gap:18px;flex-wrap:wrap;font-size:12px}.tag.pending{color:#ffe3a3;border-color:rgba(255,210,90,.42)}
    .table-card{padding:0;margin-top:16px;overflow:hidden}.table-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.12)}.table-head-actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.table-wrap{overflow:auto}.table-card.collapsed .table-wrap,.table-card.collapsed .license-tools{display:none}.table-card.collapsed .table-head{border-bottom:0}.license-tools{display:flex;gap:8px;flex-wrap:wrap;padding:12px 20px;border-bottom:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03)}.license-filter.active{background:rgba(255,255,255,.14);border-color:rgba(255,255,255,.85)}.license-filter span{margin-left:6px;color:var(--muted)}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid rgba(255,255,255,.1);padding:12px 14px;text-align:left;font-size:12px;vertical-align:top}th{color:var(--muted);font-weight:400;text-transform:uppercase}tr:last-child td{border-bottom:0}.tag{display:inline-flex;border:1px solid rgba(255,255,255,.24);border-radius:999px;padding:3px 8px}.tag.active,.tag.fulfilled,.tag.issued,.tag.downloaded{color:var(--ok);border-color:rgba(146,255,205,.35)}.tag.expired{color:#ffe3a3;border-color:rgba(255,210,90,.42)}.tag.revoked,.tag.banned,.tag.cancelled{color:#ffc4c4;border-color:rgba(255,120,120,.38)}.row-actions{display:flex;flex-wrap:wrap;gap:6px}.profile-list{display:grid;gap:6px}.profile-entry{display:grid;gap:2px;padding:6px 8px;border:1px solid rgba(255,255,255,.1);border-radius:8px;background:rgba(255,255,255,.035)}.profile-entry span{color:var(--muted)}.muted{color:var(--muted)}
    footer{max-width:1180px;margin:40px auto 0;color:var(--muted);font-size:10px;display:flex;justify-content:space-between;gap:16px}
    @media(max-width:900px){.shell{padding:20px 16px 32px}header{align-items:flex-start;flex-direction:column}main{padding-top:42px}.hero,.split,.steps,.two,.result-row,.download-gate{grid-template-columns:minmax(0,1fr)}.hero h1,.login h1,.owner h1{font-size:46px}.actions{display:grid}.section-head{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.table-card{overflow:auto}table{min-width:900px}footer{flex-direction:column}}
  </style>
</head>
<body>
  <div class="shell">
    <header>
      <a class="brand" href="/"><span class="mark" aria-hidden="true"></span><span><strong>妙妙工具</strong><span>授权网关</span></span></a>
      <nav>
        <a class="${active === 'store' ? 'active' : ''}" href="/">公开页</a>
        ${active === 'owner' ? '<a class="active" href="/owner">站长后台</a>' : ''}
      </nav>
    </header>
    <main>${body}</main>
    <footer><span>喵帕斯.top</span><span>授权私钥只保存在服务端</span></footer>
  </div>
</body>
</html>`;
}

function formatSize(bytes) {
  const value = Number(bytes || 0);
  if (!value) return '-';
  return `${(value / 1024 / 1024).toFixed(2)} MB`;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
