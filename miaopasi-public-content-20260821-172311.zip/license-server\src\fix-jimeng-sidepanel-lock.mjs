#!/usr/bin/env node
import { promises as fs } from 'node:fs';
import path from 'node:path';

const extensionDir = path.resolve(process.argv[2] || '');
const nextVersion = String(process.argv[3] || '').trim();
if (!extensionDir) {
  console.error('Usage: node src/fix-jimeng-sidepanel-lock.mjs <locked-extension-dir> [version]');
  process.exit(1);
}

const manifestPath = path.join(extensionDir, 'manifest.json');
const sidepanelPath = path.join(extensionDir, 'sidepanel.js');
const licenseClientPath = path.join(extensionDir, 'license-online-global.js');

await patchManifest();
await patchLicenseClient();
await patchSidepanel();

console.log(JSON.stringify({
  ok: true,
  extensionDir,
  version: nextVersion || null
}, null, 2));

async function patchManifest() {
  if (!nextVersion) return;
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
  manifest.version = nextVersion;
  await fs.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
}

async function patchLicenseClient() {
  if (!nextVersion) return;
  let text = await fs.readFile(licenseClientPath, 'utf8');
  text = text.replace(/extensionVersion:\s*"[^"]+"/, `extensionVersion: "${nextVersion}"`);
  await fs.writeFile(licenseClientPath, text, 'utf8');
}

async function patchSidepanel() {
  let text = await fs.readFile(sidepanelPath, 'utf8');

  if (!text.includes('setTimeout(() => init().catch')) {
    text = replaceOnce(
      text,
      'init().catch(error => {',
      'setTimeout(() => init().catch(error => {',
      'defer sidepanel init start'
    );
    text = replaceOnce(
      text,
      '}).catch(() => {});\n});\n\nconst LICENSE_PANEL_ID',
      '}).catch(() => {});\n}), 0);\n\nconst LICENSE_PANEL_ID',
      'defer sidepanel init end'
    );
  }

  text = text.replace(
    /async function initializeLicenseGate\(\) \{\s*installLicensePanel\(\);\s*await refreshLicensePanel\(\{ silent: true \}\);\s*\}/,
    [
      'function initializeLicenseGate() {',
      '  try {',
      '    installLicensePanel();',
      '    refreshLicensePanel({ silent: true }).catch(() => {});',
      '  } catch (error) {',
      '    console.warn("license panel init failed", error);',
      '  }',
      '}'
    ].join('\n')
  );

  text = text.replace(
    'async function init() {\n  await initializeLicenseGate();',
    'async function init() {\n  initializeLicenseGate();'
  );

  text = text.replace(
    /  panel\.innerHTML = `[\s\S]*?  `;\n  document\.querySelector\("main"\)\.prepend\(panel\);/,
    [
      '  panel.innerHTML = [',
      '    \'<div class="license-card__head"><div><strong>\\u6388\\u6743</strong><span>\\u5728\\u7ebf\\u6821\\u9a8c\\u540e\\u624d\\u80fd\\u5f00\\u59cb\\u8dd1\\u56fe</span></div><button id="licenseRefreshButton" class="secondary" type="button">\\u5237\\u65b0</button></div>\',',
      '    \'<div id="licenseStatus" class="license-status">\\u6b63\\u5728\\u8bfb\\u53d6\\u6388\\u6743\\u72b6\\u6001...</div>\',',
      '    \'<div class="license-row"><input id="licenseCodeInput" type="text" placeholder="\\u8f93\\u5165 MM- \\u5f00\\u5934\\u7684\\u6388\\u6743\\u7801" autocomplete="off"><button id="licenseActivateButton" class="primary" type="button">\\u6fc0\\u6d3b</button></div>\',',
      '    \'<div class="license-actions"><button id="licenseCopyMachineButton" class="secondary" type="button">\\u590d\\u5236\\u673a\\u5668\\u7801</button><button id="licenseClearButton" class="secondary" type="button">\\u6e05\\u9664\\u672c\\u673a\\u6388\\u6743</button></div>\'',
      '  ].join("");',
      '  document.querySelector("main").prepend(panel);'
    ].join('\n')
  );

  text = text.replace(
    'async function refreshLicensePanel(options = {}) {\n  const statusEl = document.getElementById("licenseStatus");',
    'async function refreshLicensePanel(options = {}) {\n  const statusEl = document.getElementById("licenseStatus");\n  if (!statusEl) return { ok: false, error: "\\u6388\\u6743\\u9762\\u677f\\u672a\\u52a0\\u8f7d" };'
  );

  text = text.replace(
    'function renderLicenseStatus(status) {\n  const statusEl = document.getElementById("licenseStatus");',
    'function renderLicenseStatus(status) {\n  const statusEl = document.getElementById("licenseStatus");\n  if (!statusEl) return;'
  );

  await fs.writeFile(sidepanelPath, text, 'utf8');
}

function replaceOnce(text, oldText, newText, label) {
  const count = text.split(oldText).length - 1;
  if (count !== 1) throw new Error(`${label}: expected 1 match, found ${count}`);
  return text.replace(oldText, newText);
}
