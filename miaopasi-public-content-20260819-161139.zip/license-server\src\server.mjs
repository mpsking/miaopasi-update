#!/usr/bin/env node
import http from 'node:http';
import { createReadStream } from 'node:fs';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { loadConfig, saveConfig } from './config.mjs';
import { appendAudit, Store } from './store.mjs';
import { ensureSigningKeyPair, loadPrivateJwk, loadPublicJwk } from './signing.mjs';
import { addSecondsIso, assertVersionAtLeast, getDataDir, isExpired, nowIso, randomDownloadCode, randomId, sha256Hex } from './util.mjs';
import {
  activateLicense,
  banLicenseOrCustomer,
  deleteBannedLicense,
  extendLicense,
  issueLicense,
  maxProfilesPerDeviceForLicense,
  refreshRunToken,
  revokeLicenseOrActivation,
  validateRunToken
} from './license-core.mjs';
import { renderPublicKey, wantsHtml } from './public-key-ui.mjs';
import { renderPublicPortal } from './public-portal-ui.mjs';
import { listProducts, normalizeProductId } from './products.mjs';

const port = Number(process.env.PORT || 8788);
const host = process.env.HOST || '127.0.0.1';
const publicRuntimeOnly = process.env.MIAOPASI_PUBLIC_RUNTIME !== '0';
const SECURITY_EVENT_DEDUPE_MS = 15 * 60 * 1000;
const DOWNLOAD_TICKET_TTL_SECONDS = 10 * 60;
const store = new Store(getDataDir());
let config = await loadConfig();
await store.init();
await ensureSigningKeyPair(getDataDir());
const privateJwk = await loadPrivateJwk(getDataDir());
const publicJwk = await loadPublicJwk(getDataDir());
const adminToken = publicRuntimeOnly ? '' : await ensureAdminToken();
const ownerAccount = publicRuntimeOnly ? { username: '', passwordSalt: '', passwordHash: '' } : await ensureOwnerAccount();
const ownerEntry = publicRuntimeOnly ? { pathToken: '' } : await ensureOwnerEntry();

const server = http.createServer(async (req, res) => {
  setCors(res);
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }
  try {
    const url = new URL(req.url, `http://${req.headers.host || `${host}:${port}`}`);
    if (publicRuntimeOnly && isOwnerOrAdminPath(url.pathname)) {
      sendNotFound(res);
      return;
    }
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/download' || url.pathname === '/store')) {
      const releases = publicDownloadReleases((await buildReleaseList()).map(publicReleaseView));
      sendHtml(res, 200, renderPublicPortal({
        config,
        release: releases.find((release) => release.available) || publicReleaseView(emptyRelease()),
        releases
      }));
      return;
    }
    if (req.method === 'GET' && url.pathname === '/updates.xml') {
      sendXml(res, 200, renderUpdateManifest(await buildLatestCrxReleases()));
      return;
    }
    if (req.method === 'GET' && url.pathname === `/_miao-owner/${ownerEntry.pathToken}`) {
      unlockOwnerEntry(res);
      return;
    }
    if (req.method === 'GET' && url.pathname.startsWith('/_miao-owner/')) {
      sendNotFound(res);
      return;
    }
    if (req.method === 'GET' && url.pathname === '/admin') {
      sendNotFound(res);
      return;
    }
    if (req.method === 'GET' && url.pathname === '/owner') {
      sendNotFound(res);
      return;
    }
    if (req.method === 'GET' && url.pathname === '/health') {
      sendJson(res, 200, {
        ok: true,
        productId: config.productId,
        minExtensionVersion: config.minExtensionVersion,
        tokenTtlSeconds: config.tokenTtlSeconds
      });
      return;
    }
    if (req.method === 'GET' && isUpdaterKitPath(url.pathname)) {
      try {
        await sendFile(
          res,
          path.join(process.cwd(), 'public', 'tools', '喵帕斯解压版更新小助手.zip'),
          '喵帕斯解压版更新小助手.zip',
          'no-store'
        );
      } catch (error) {
        if (error?.code === 'ENOENT') {
          sendJson(res, 404, { ok: false, code: 'updater_kit_not_found', error: 'updater kit not found' });
          return;
        }
        throw error;
      }
      return;
    }
    if (req.method === 'GET' && url.pathname === '/api/v1/releases/latest') {
      const releases = publicDownloadReleases((await buildReleaseList()).map(publicReleaseView));
      sendJson(res, 200, { ok: true, release: releases[0] || publicReleaseView(emptyRelease()) });
      return;
    }
    if (req.method === 'GET' && url.pathname === '/api/v1/releases') {
      sendJson(res, 200, { ok: true, releases: publicDownloadReleases((await buildReleaseList()).map(publicReleaseView)) });
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/downloads/authorize') {
      sendJson(res, 200, await authorizeDownload(req, await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/updater/check') {
      sendJson(res, 200, await checkUpdater(req, await readBody(req)));
      return;
    }
    if (req.method === 'GET' && url.pathname.startsWith('/auto-updates/')) {
      const release = await findReleaseByUpdatePath(url.pathname);
      if (!release?.available) {
        sendJson(res, 404, { ok: false, code: 'release_not_found', error: 'release not found' });
        return;
      }
      await sendFile(res, release.filePath, release.downloadName || release.fileName);
      return;
    }
    if (req.method === 'GET' && url.pathname.startsWith('/downloads/')) {
      const release = await findReleaseByPath(url.pathname);
      if (!release?.available) {
        sendJson(res, 404, { ok: false, code: 'release_not_found', error: 'release not found' });
        return;
      }
      if (!isAdminRequest(req)) await consumeDownloadTicket(req, release, url.searchParams.get('ticket'));
      await sendFile(res, release.filePath, release.downloadName || release.fileName, isAdminRequest(req) ? 'public, max-age=300' : 'no-store');
      return;
    }
    if (req.method === 'GET' && url.pathname === '/api/v1/public-key') {
      if (url.searchParams.get('format') !== 'json' && wantsHtml(req)) {
        sendHtml(res, 200, renderPublicKey({ config, publicJwk }));
        return;
      }
      sendJson(res, 200, { ok: true, publicJwk });
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/activate') {
      sendJson(res, 200, await activateLicense({ store, privateJwk, config, body: await readBody(req) }));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/refresh') {
      sendJson(res, 200, await refreshRunToken({ store, privateJwk, config, body: await readBody(req) }));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/validate') {
      sendJson(res, 200, await validateRunToken({ store, publicJwk, config, body: await readBody(req) }));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/security-events') {
      sendJson(res, 200, await recordSecurityEvent(req, await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/orders') {
      sendJson(res, 200, await createOrder(await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/login') {
      await loginOwner(req, res);
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/logout') {
      logoutOwner(res);
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/revoke') {
      requireAdmin(req);
      sendJson(res, 200, await revokeLicenseOrActivation(store, await readBody(req)));
      return;
    }
    if (req.method === 'GET' && url.pathname === '/api/v1/admin/state') {
      requireAdmin(req);
      sendJson(res, 200, await buildAdminState());
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/issue') {
      requireAdmin(req);
      const body = await readBody(req);
      const license = await issueLicense(store, {
        customerName: body.customerName || body.customer || '',
        customerId: body.customerId || '',
        contact: body.contact || '',
        days: Number(body.days || 30),
        maxDevices: Number(body.maxDevices || 1),
        maxProfilesPerDevice: Number(body.maxProfilesPerDevice || config.defaultMaxProfilesPerDevice || 20),
        notes: body.notes || '',
        productId: normalizeProductId(config, body.productId)
      }, config);
      const downloadCode = await issueDownloadCodeForLicense(license, {
        notes: [body.notes || '', `license:${license.licenseId}`].filter(Boolean).join('\n')
      });
      sendJson(res, 200, { ok: true, license, downloadCode });
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/download-codes/issue') {
      requireAdmin(req);
      sendJson(res, 200, await issueDownloadCode(await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/revoke') {
      requireAdmin(req);
      sendJson(res, 200, await revokeLicenseOrActivation(store, await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/extend') {
      requireAdmin(req);
      sendJson(res, 200, await extendLicense(store, await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/ban') {
      requireAdmin(req);
      sendJson(res, 200, await banLicenseOrCustomer(store, await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/licenses/delete') {
      requireAdmin(req);
      sendJson(res, 200, await deleteBannedLicense(store, await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/releases/upload') {
      requireAdmin(req);
      sendJson(res, 200, await uploadRelease(await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/settings/min-version') {
      requireAdmin(req);
      sendJson(res, 200, await updateMinimumVersion(await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/orders/approve') {
      requireAdmin(req);
      sendJson(res, 200, await approveOrder(await readBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/admin/orders/cancel') {
      requireAdmin(req);
      sendJson(res, 200, await cancelOrder(await readBody(req)));
      return;
    }
    sendJson(res, 404, { ok: false, code: 'not_found', error: 'not found' });
  } catch (error) {
    sendJson(res, error.status || 500, {
      ok: false,
      code: error.code || 'server_error',
      error: error.message || String(error)
    });
  }
});

server.listen(port, host, () => {
  console.log(`LICENSE_SERVER_READY http://${host}:${port}`);
});

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', process.env.CORS_ORIGIN || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
  res.setHeader('Cache-Control', 'no-store');
}

function sendJson(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(`${JSON.stringify(body)}\n`);
}

function sendNotFound(res) {
  sendJson(res, 404, { ok: false, code: 'not_found', error: 'not found' });
}

function sendHtml(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(body);
}

function sendXml(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/xml; charset=utf-8',
    'Cache-Control': 'public, max-age=300'
  });
  res.end(body);
}

function redirect(res, location) {
  res.writeHead(302, { Location: location });
  res.end();
}

async function sendFile(res, filePath, downloadName, cacheControl = 'public, max-age=300') {
  const stat = await fs.stat(filePath);
  const contentType = String(downloadName || filePath).toLowerCase().endsWith('.crx')
    ? 'application/x-chrome-extension'
    : 'application/zip';
  res.writeHead(200, {
    'Content-Type': contentType,
    'Content-Length': stat.size,
    'Content-Disposition': contentDisposition(downloadName),
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': cacheControl
  });
  createReadStream(filePath).pipe(res);
}

function contentDisposition(downloadName) {
  const name = String(downloadName || 'download.zip');
  let fallback = name.replace(/[^\x20-\x7e]+/g, '-').replace(/["\\]/g, '').replace(/-+/g, '-').replace(/^-|-$/g, '') || 'download.zip';
  if (fallback.startsWith('.')) fallback = `download${fallback}`;
  if (fallback === name) return `attachment; filename="${fallback}"`;
  return `attachment; filename="${fallback}"; filename*=UTF-8''${encodeURIComponent(name)}`;
}

async function readBody(req) {
  let text = '';
  for await (const chunk of req) text += chunk;
  if (!text.trim()) return {};
  try {
    return JSON.parse(text);
  } catch {
    const error = new Error('request body must be JSON');
    error.status = 400;
    error.code = 'invalid_json';
    throw error;
  }
}

function requireAdmin(req) {
  if (!isAdminRequest(req)) {
    const error = new Error('admin token required');
    error.status = 403;
    error.code = 'admin_required';
    throw error;
  }
}

function isAdminRequest(req) {
  if (publicRuntimeOnly) return false;
  const bearer = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (adminToken && bearer === adminToken) return true;
  return parseCookies(req).mm_owner_session === ownerSessionValue();
}

function isOwnerOrAdminPath(pathname) {
  return pathname === '/admin'
    || pathname === '/owner'
    || pathname === '/api/v1/revoke'
    || pathname.startsWith('/api/v1/admin/')
    || pathname.startsWith('/_miao-owner/');
}

function isOwnerEntryRequest(req) {
  return parseCookies(req).mm_owner_entry === ownerEntryValue();
}

function unlockOwnerEntry(res) {
  res.setHeader('Set-Cookie', `mm_owner_entry=${ownerEntryValue()}; Path=/; Max-Age=604800; HttpOnly; SameSite=Lax`);
  redirect(res, '/owner');
}

async function loginOwner(req, res) {
  const body = await readBody(req);
  const token = String(body.token || '').trim();
  const username = String(body.username || '').trim();
  const password = String(body.password || '');
  const tokenOk = token && token === adminToken;
  const passwordOk = username && password && verifyOwnerPassword(username, password);
  if (!tokenOk && !isOwnerEntryRequest(req)) {
    sendNotFound(res);
    return;
  }
  if (!tokenOk && !passwordOk) {
    sendJson(res, 403, { ok: false, code: 'admin_required', error: 'admin token required' });
    return;
  }
  res.setHeader('Set-Cookie', [
    `mm_owner_session=${ownerSessionValue()}; Path=/; Max-Age=604800; HttpOnly; SameSite=Lax`,
    `mm_owner_entry=${ownerEntryValue()}; Path=/; Max-Age=604800; HttpOnly; SameSite=Lax`
  ]);
  sendJson(res, 200, { ok: true });
}

function logoutOwner(res) {
  res.setHeader('Set-Cookie', [
    'mm_owner_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax',
    'mm_owner_entry=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax'
  ]);
  sendJson(res, 200, { ok: true });
}

function parseCookies(req) {
  return String(req.headers.cookie || '')
    .split(';')
    .map((item) => item.trim())
    .filter(Boolean)
    .reduce((cookies, item) => {
      const index = item.indexOf('=');
      if (index === -1) return cookies;
      cookies[decodeURIComponent(item.slice(0, index))] = decodeURIComponent(item.slice(index + 1));
      return cookies;
    }, {});
}

function ownerSessionValue() {
  return createHash('sha256').update(`owner:${adminToken}:${ownerAccount.passwordHash}`).digest('base64url');
}

function ownerEntryValue() {
  return createHash('sha256')
    .update(`entry:${adminToken}:${ownerAccount.passwordHash}:${ownerEntry.pathToken}`)
    .digest('base64url');
}

function verifyOwnerPassword(username, password) {
  if (username !== ownerAccount.username) return false;
  const expected = Buffer.from(ownerAccount.passwordHash, 'hex');
  const actual = scryptSync(password, ownerAccount.passwordSalt, expected.length);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

async function ensureOwnerAccount() {
  const file = path.join(getDataDir(), 'owner-account.json');
  try {
    const account = JSON.parse(await fs.readFile(file, 'utf8'));
    if (account?.username && account?.passwordSalt && account?.passwordHash) return account;
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
  }
  const error = new Error(`owner account is missing: ${file}`);
  error.status = 500;
  error.code = 'owner_account_missing';
  throw error;
}

async function ensureOwnerEntry() {
  const file = path.join(getDataDir(), 'owner-entry.json');
  try {
    const entry = JSON.parse(await fs.readFile(file, 'utf8'));
    if (entry?.pathToken) return entry;
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
  }
  const entry = {
    pathToken: `miao-${randomBytes(18).toString('base64url')}`,
    createdAt: nowIso()
  };
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, `${JSON.stringify(entry, null, 2)}\n`, 'utf8');
  return entry;
}

async function ensureAdminToken() {
  const envToken = String(process.env.LICENSE_ADMIN_TOKEN || '').trim();
  if (envToken && envToken !== 'change-this-before-production') return envToken;
  const file = path.join(getDataDir(), 'admin-token.txt');
  try {
    const existing = (await fs.readFile(file, 'utf8')).trim();
    if (existing) return existing;
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
  }
  const token = `mm_admin_${randomBytes(24).toString('base64url')}`;
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, `${token}\n`, 'utf8');
  console.log(`ADMIN_TOKEN_FILE=${file}`);
  return token;
}

async function buildLatestRelease() {
  const releases = await buildReleaseList();
  const latest = releases.find((release) => release.available);
  return latest || emptyRelease();
}

async function buildLatestCrxRelease() {
  const releases = await buildReleaseList();
  return releases.find((release) => release.available && release.packageType === 'crx') || null;
}

async function buildLatestCrxReleases() {
  const releases = await buildReleaseList();
  const latestByExtensionId = new Map();
  for (const release of releases) {
    if (!release.available || release.packageType !== 'crx' || !release.extensionId) continue;
    if (!latestByExtensionId.has(release.extensionId)) latestByExtensionId.set(release.extensionId, release);
  }
  return [...latestByExtensionId.values()];
}

async function buildReleaseList() {
  const db = await store.read();
  return Object.values(db.releases || {})
    .sort((a, b) => String(b.createdAt || b.updatedAt || '').localeCompare(String(a.createdAt || a.updatedAt || '')))
    .map(decorateRelease);
}

async function findReleaseByPath(downloadPath) {
  return (await buildReleaseList()).find((release) => pathMatches(release.downloadPath, downloadPath)) || null;
}

async function findReleaseByUpdatePath(downloadPath) {
  return (await buildReleaseList()).find((release) => pathMatches(release.updateDownloadPath, downloadPath)) || null;
}

function pathMatches(left, right) {
  if (left === right) return true;
  return safeDecodePath(left) === safeDecodePath(right);
}

function safeDecodePath(value) {
  const text = String(value || '');
  try {
    return decodeURI(text);
  } catch {
    return text;
  }
}

function emptyRelease() {
  return {
    releaseId: null,
    productId: config.productId,
    name: config.productName || '妙妙工具',
    version: '',
    channel: '暂未开放下载',
    fileName: '',
    downloadName: '',
    filePath: '',
    downloadPath: '',
    downloadUrl: '',
    packageType: '',
    pageUrl: `${publicBaseUrl()}/download`,
    sizeBytes: 0,
    sha256: '',
    status: 'offline',
    available: false,
    createdAt: null,
    updatedAt: null,
    minExtensionVersion: config.minExtensionVersion,
    apiBase: publicBaseUrl()
  };
}

function decorateRelease(release) {
  const fileName = release.fileName;
  const encodedFileName = encodeURIComponent(fileName || '');
  const downloadPath = release.downloadPath || `/downloads/${encodedFileName}`;
  const updateDownloadPath = release.updateDownloadPath || `/auto-updates/${encodeURIComponent(release.releaseId || '')}/${encodedFileName}`;
  const filePath = path.join(process.cwd(), 'public', 'downloads', fileName);
  const packageType = release.packageType || (String(fileName || '').toLowerCase().endsWith('.crx') ? 'crx' : 'zip');
  return {
    ...release,
    packageType,
    filePath,
    downloadPath,
    updateDownloadPath,
    downloadName: release.downloadName || fileName,
    downloadUrl: `${publicBaseUrl()}${downloadPath}`,
    updateDownloadUrl: `${publicBaseUrl()}${updateDownloadPath}`,
    pageUrl: `${publicBaseUrl()}/download`,
    updateManifestUrl: `${publicBaseUrl()}/updates.xml`,
    apiBase: publicBaseUrl(),
    available: release.status === 'active'
  };
}

function publicReleaseView(release) {
  if (!release) return null;
  const { filePath, sha256, buildId, updateDownloadPath, updateDownloadUrl, ...publicRelease } = release;
  return publicRelease;
}

function publicDownloadReleases(releases) {
  const available = releases.filter((release) => release?.available);
  const groups = new Map();
  for (const release of available) {
    const key = publicReleaseGroupKey(release);
    const group = groups.get(key) || { zip: null, fallback: null };
    if (!group.fallback) group.fallback = release;
    if (release.packageType === 'zip' && !group.zip) group.zip = release;
    groups.set(key, group);
  }
  return [...groups.values()]
    .map((group) => group.zip || group.fallback)
    .filter(Boolean);
}

async function authorizeDownload(req, body) {
  const code = requiredText(body.downloadCode || body.code, 'downloadCode').toUpperCase();
  const db = await store.read();
  const downloadCode = Object.values(db.downloadCodes || {}).find((item) => item.code === code);
  const license = downloadCode?.licenseId ? db.licenses?.[downloadCode.licenseId] : null;
  assertDownloadCodeActive(downloadCode, license);
  const releases = publicDownloadReleases(await buildReleaseList());
  const requestedReleaseId = String(body.releaseId || '').trim();
  const release = requestedReleaseId
    ? releases.find((item) => item.releaseId === requestedReleaseId)
    : releases.find((item) => releaseMatchesLicense(item, downloadCode));
  if (!release?.available) throw httpError(404, 'release_not_found', 'release not found');
  if (!releaseMatchesLicense(release, downloadCode)) {
    throw httpError(403, 'product_mismatch', 'download code is not for this plugin');
  }
  const ticket = await createDownloadTicket(req, license, downloadCode, release, { purpose: 'manual' });
  return {
    ok: true,
    download: ticket.download,
    downloadUrl: ticket.downloadUrl
  };
}

async function checkUpdater(req, body) {
  const code = requiredText(body.downloadCode || body.code, 'downloadCode').toUpperCase();
  const requestedProductId = String(body.productId || '').trim();
  const currentVersion = String(body.currentVersion || '').trim();
  const currentBuildId = String(body.currentBuildId || '').trim();
  const currentReleaseId = String(body.currentReleaseId || '').trim();
  const forceDownload = truthy(body.forceDownload || body.force);
  const db = await store.read();
  const downloadCode = Object.values(db.downloadCodes || {}).find((item) => item.code === code);
  const license = downloadCode?.licenseId ? db.licenses?.[downloadCode.licenseId] : null;
  assertDownloadCodeActive(downloadCode, license);
  const productId = requestedProductId || downloadCode.productId || license.productId;
  if (productId && String(downloadCode.productId || license.productId || '') !== productId) {
    throw httpError(403, 'product_mismatch', 'download code is not for this plugin');
  }
  const release = pickLatestZipReleaseForProduct(await buildReleaseList(), downloadCode);
  if (!release?.available) throw httpError(404, 'release_not_found', 'release not found');

  const updateAvailable = releaseIsNewer(release, {
    currentVersion,
    currentBuildId,
    currentReleaseId
  });
  let ticket = null;
  if (updateAvailable || forceDownload) {
    ticket = await createDownloadTicket(req, license, downloadCode, release, {
      purpose: 'updater',
      currentVersion,
      currentBuildId,
      currentReleaseId
    });
  }
  return {
    ok: true,
    productId: release.publicGroup || release.productId,
    updateAvailable,
    forceDownload,
    release: updaterReleaseView(release),
    download: ticket?.download || null,
    downloadUrl: ticket?.downloadUrl ? absolutePublicUrl(ticket.downloadUrl) : ''
  };
}

async function createDownloadTicket(req, license, downloadCode, release, extra = {}) {
  const token = randomId('dlt_', 24);
  const now = nowIso();
  const download = {
    downloadId: randomId('dl_', 8),
    tokenHash: sha256Hex(token),
    status: 'issued',
    purpose: String(extra.purpose || 'manual').trim(),
    licenseId: license.licenseId,
    downloadCodeId: downloadCode.downloadCodeId,
    downloadCodeSuffix: downloadCode.code.slice(-4),
    customerId: license.customerId || '',
    customerName: license.customerName || '',
    contact: license.contact || '',
    productId: license.productId || release.productId || '',
    releaseId: release.releaseId,
    releaseName: release.name || '',
    version: release.version || '',
    buildId: release.buildId || '',
    fileName: release.fileName || '',
    packageType: release.packageType || '',
    ip: requestIp(req),
    userAgent: clampText(req.headers['user-agent'] || '', 300),
    createdAt: now,
    expiresAt: addSecondsIso(DOWNLOAD_TICKET_TTL_SECONDS),
    usedAt: '',
    downloadCount: 0,
    clientCurrentVersion: clampText(extra.currentVersion || '', 40),
    clientCurrentBuildId: clampText(extra.currentBuildId || '', 120),
    clientCurrentReleaseId: clampText(extra.currentReleaseId || '', 80)
  };
  await store.mutate((current) => {
    current.downloads[download.downloadId] = download;
    pruneDownloads(current);
    appendAudit(current, 'download.ticket_issued', {
      downloadId: download.downloadId,
      licenseId: download.licenseId,
      downloadCodeId: download.downloadCodeId,
      releaseId: download.releaseId,
      buildId: download.buildId,
      purpose: download.purpose
    });
  });
  return {
    download: publicDownloadTicketView(download),
    downloadUrl: `${release.downloadPath}?ticket=${encodeURIComponent(token)}`
  };
}

function pickLatestZipReleaseForProduct(releases, licenseLike) {
  return releases
    .filter((release) => release.available && release.packageType === 'zip' && releaseMatchesLicense(release, licenseLike))
    .sort(compareReleasesForUpdater)[0] || null;
}

function compareReleasesForUpdater(a, b) {
  const versionCompare = compareVersions(b.version, a.version);
  if (versionCompare !== 0) return versionCompare;
  return String(b.createdAt || b.updatedAt || '').localeCompare(String(a.createdAt || a.updatedAt || ''));
}

function compareVersions(a, b) {
  const left = String(a || '').split(/[.-]/).map((part) => Number.parseInt(part, 10) || 0);
  const right = String(b || '').split(/[.-]/).map((part) => Number.parseInt(part, 10) || 0);
  const max = Math.max(left.length, right.length);
  for (let i = 0; i < max; i += 1) {
    if ((left[i] || 0) > (right[i] || 0)) return 1;
    if ((left[i] || 0) < (right[i] || 0)) return -1;
  }
  return 0;
}

function releaseIsNewer(release, current = {}) {
  if (!current.currentVersion && !current.currentBuildId && !current.currentReleaseId) return true;
  if (current.currentReleaseId && release.releaseId === current.currentReleaseId) return false;
  if (current.currentVersion && !assertVersionAtLeast(current.currentVersion, release.version)) return true;
  if (release.buildId && current.currentBuildId && release.buildId !== current.currentBuildId) return true;
  if (!current.currentVersion && !current.currentBuildId) return true;
  return false;
}

function updaterReleaseView(release) {
  return {
    releaseId: release.releaseId,
    productId: release.publicGroup || release.productId,
    name: release.name || '',
    version: release.version || '',
    channel: release.channel || '',
    packageType: release.packageType || '',
    fileName: release.fileName || '',
    downloadName: release.downloadName || release.fileName || '',
    sizeBytes: release.sizeBytes || 0,
    sha256: release.sha256 || '',
    buildId: release.buildId || '',
    createdAt: release.createdAt || '',
    updatedAt: release.updatedAt || ''
  };
}

async function consumeDownloadTicket(req, release, tokenValue) {
  const token = String(tokenValue || '').trim();
  if (!token) throw httpError(403, 'download_code_required', 'download code required');
  const tokenHash = sha256Hex(token);
  return store.mutate((db) => {
    const download = Object.values(db.downloads || {}).find((item) => item.tokenHash === tokenHash);
    if (!download) throw httpError(403, 'download_ticket_invalid', 'download ticket invalid');
    if (download.releaseId !== release.releaseId) throw httpError(403, 'download_release_mismatch', 'download ticket does not match this release');
    if (Date.parse(download.expiresAt || '') <= Date.now()) {
      download.status = 'expired';
      download.updatedAt = nowIso();
      throw httpError(403, 'download_ticket_expired', 'download ticket expired');
    }
    if (download.status !== 'issued') {
      throw httpError(403, 'download_ticket_used', 'download ticket already used');
    }
    const downloadCode = db.downloadCodes?.[download.downloadCodeId];
    const license = db.licenses?.[download.licenseId];
    assertDownloadCodeActive(downloadCode, license);
    download.status = 'downloaded';
    download.usedAt = nowIso();
    download.updatedAt = download.usedAt;
    download.usedIp = requestIp(req);
    download.usedUserAgent = clampText(req.headers['user-agent'] || '', 300);
    download.downloadCount = Number(download.downloadCount || 0) + 1;
    if (downloadCode) {
      downloadCode.downloadCount = Number(downloadCode.downloadCount || 0) + 1;
      downloadCode.lastDownloadedAt = download.usedAt;
      downloadCode.updatedAt = download.usedAt;
    }
    appendAudit(db, 'download.file_served', {
      downloadId: download.downloadId,
      licenseId: download.licenseId,
      downloadCodeId: download.downloadCodeId,
      releaseId: download.releaseId,
      buildId: download.buildId
    });
    return publicDownloadTicketView(download);
  });
}

function assertDownloadLicenseActive(license) {
  if (!license) throw httpError(404, 'license_not_found', 'license not found');
  if (license.status === 'pending') return;
  if (license.status !== 'active') throw httpError(403, 'license_inactive', 'license is not active');
  if (isExpired(license.expiresAt)) throw httpError(403, 'license_expired', 'license expired');
}

function assertDownloadCodeActive(downloadCode, license) {
  if (!downloadCode) throw httpError(404, 'download_code_not_found', 'download code not found');
  if (downloadCode.status !== 'active') throw httpError(403, 'download_code_inactive', 'download code is not active');
  if (license?.status === 'pending') return;
  if (isExpired(downloadCode.expiresAt || license?.expiresAt)) throw httpError(403, 'download_code_expired', 'download code expired');
  assertDownloadLicenseActive(license);
}

function releaseMatchesLicense(release, license) {
  const releaseProductId = String(release.publicGroup || release.productId || '').trim();
  return releaseProductId && releaseProductId === String(license.productId || '').trim();
}

function publicDownloadTicketView(download) {
  const { tokenHash, ...view } = download || {};
  return view;
}

function adminDownloadView(download) {
  return publicDownloadTicketView(download);
}

function adminDownloadCodeView(downloadCode, license = null) {
  const status = downloadCodeStatus(downloadCode, license);
  return {
    ...downloadCode,
    status,
    customerName: downloadCode.customerName || license?.customerName || '',
    contact: downloadCode.contact || license?.contact || license?.customerId || '',
    productId: downloadCode.productId || license?.productId || '',
    licenseActivationCodeSuffix: license?.activationCode ? license.activationCode.slice(-6) : ''
  };
}

function downloadCodeStatus(downloadCode, license = null) {
  if (!downloadCode) return 'unknown';
  if (downloadCode.status !== 'active') return downloadCode.status || 'revoked';
  if (license?.status === 'pending') return 'active';
  if (isExpired(downloadCode.expiresAt || license?.expiresAt)) return 'expired';
  if (!license || license.status !== 'active') return 'revoked';
  if (isExpired(license.expiresAt)) return 'expired';
  return 'active';
}

async function issueDownloadCode(body) {
  const db = await store.read();
  const license = body.licenseId
    ? db.licenses?.[String(body.licenseId).trim()]
    : Object.values(db.licenses || {}).find((item) => item.activationCode === String(body.activationCode || '').trim().toUpperCase());
  if (!license) throw httpError(404, 'license_not_found', 'license not found');
  return { ok: true, downloadCode: await issueDownloadCodeForLicense(license, body) };
}

async function issueDownloadCodeForLicense(license, options = {}) {
  return store.mutate((db) => {
    const currentLicense = db.licenses?.[license.licenseId];
    if (!currentLicense) throw httpError(404, 'license_not_found', 'license not found');
    let code = String(options.code || '').trim().toUpperCase();
    for (let attempt = 0; attempt < 10; attempt += 1) {
      if (!code) code = randomDownloadCode();
      const exists = Object.values(db.downloadCodes || {}).some((item) => item.code === code);
      if (!exists) break;
      code = '';
    }
    if (!code || Object.values(db.downloadCodes || {}).some((item) => item.code === code)) {
      throw httpError(409, 'download_code_collision', 'download code collision');
    }
    const downloadCode = {
      downloadCodeId: randomId('dcode_', 8),
      code,
      status: 'active',
      licenseId: currentLicense.licenseId,
      customerId: currentLicense.customerId || '',
      customerName: currentLicense.customerName || '',
      contact: currentLicense.contact || '',
      productId: currentLicense.productId || normalizeProductId(config, options.productId),
      notes: String(options.notes || '').trim(),
      downloadCount: 0,
      createdAt: nowIso(),
      updatedAt: nowIso(),
      expiresAt: options.expiresAt || currentLicense.expiresAt || ''
    };
    db.downloadCodes[downloadCode.downloadCodeId] = downloadCode;
    appendAudit(db, 'download_code.issued', {
      downloadCodeId: downloadCode.downloadCodeId,
      licenseId: downloadCode.licenseId,
      productId: downloadCode.productId
    });
    return adminDownloadCodeView(downloadCode, currentLicense);
  });
}

function pruneDownloads(db) {
  const downloads = Object.values(db.downloads || {})
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
  db.downloads = Object.fromEntries(downloads.slice(0, 2000).map((item) => [item.downloadId, item]));
}

function publicReleaseGroupKey(release) {
  return String(release.publicGroup || release.name || release.extensionId || release.releaseId || '')
    .trim()
    .toLowerCase();
}

async function uploadRelease(body) {
  const originalName = path.basename(String(body.fileName || 'plugin.zip'));
  const extension = path.extname(originalName).toLowerCase();
  if (!['.zip', '.crx'].includes(extension)) {
    throw httpError(400, 'invalid_release_file', 'release file must be a zip or crx');
  }
  const base64 = String(body.contentBase64 || '').split(',').pop();
  if (!base64) throw httpError(400, 'release_content_missing', 'release content is required');
  const buffer = Buffer.from(base64, 'base64');
  const packageType = extension.slice(1);
  if (packageType === 'zip' && !isZipBuffer(buffer)) {
    throw httpError(400, 'invalid_zip', 'release content must be a zip');
  }
  const crxExtensionId = packageType === 'crx'
    ? (String(body.extensionId || '').trim() || extensionIdFromCrxBuffer(buffer))
    : '';
  if (packageType === 'crx' && !crxExtensionId) {
    throw httpError(400, 'invalid_crx', 'release content must be a signed crx');
  }
  if (buffer.length > 80 * 1024 * 1024) {
    throw httpError(413, 'release_too_large', 'release package is too large');
  }
  const fileName = `${Date.now()}-${safeFileName(originalName)}`;
  const downloadsDir = path.join(process.cwd(), 'public', 'downloads');
  const filePath = path.join(downloadsDir, fileName);
  await fs.mkdir(downloadsDir, { recursive: true });
  await fs.writeFile(filePath, buffer, { flag: 'wx' });
  const now = nowIso();
  const release = {
    releaseId: randomId('rel_', 8),
    buildId: String(body.buildId || body.packageBuildId || '').trim(),
    productId: String(body.productId || body.publicGroup || config.productId).trim(),
    publicGroup: String(body.publicGroup || '').trim(),
    name: String(body.name || config.productName || '妙妙工具').trim(),
    version: String(body.version || config.minExtensionVersion || '1.0.0').trim(),
    channel: String(body.channel || '正式版').trim(),
    fileName,
    originalName,
    packageType,
    extensionId: crxExtensionId,
    sizeBytes: buffer.length,
    sha256: createHash('sha256').update(buffer).digest('hex').toUpperCase(),
    notes: String(body.notes || '').trim(),
    status: 'active',
    createdAt: now,
    updatedAt: now
  };
  await store.mutate((db) => {
    db.releases[release.releaseId] = release;
    appendAudit(db, 'release.uploaded', {
      releaseId: release.releaseId,
      buildId: release.buildId,
      fileName: release.fileName,
      version: release.version,
      packageType: release.packageType,
      extensionId: release.extensionId || '',
      sha256: release.sha256
    });
  });
  if (truthy(body.setMinimumVersion) || truthy(body.setMinVersion)) {
    await setMinimumVersion(release.version, `release:${release.releaseId}`);
  }
  return { ok: true, release: decorateRelease(release) };
}

async function updateMinimumVersion(body) {
  const version = requiredText(body.version, 'version');
  await setMinimumVersion(version, 'owner');
  return { ok: true, minExtensionVersion: config.minExtensionVersion };
}

async function setMinimumVersion(version, reason = 'manual') {
  config = {
    ...config,
    minExtensionVersion: String(version || '').trim()
  };
  await saveConfig(config);
  await store.mutate((db) => {
    appendAudit(db, 'settings.min_version_updated', {
      minExtensionVersion: config.minExtensionVersion,
      reason
    });
  });
}

function renderUpdateManifest(releases) {
  const items = (Array.isArray(releases) ? releases : [releases])
    .filter((release) => release?.extensionId && (release?.updateDownloadUrl || release?.downloadUrl) && release?.version);
  if (!items.length) {
    return '<?xml version="1.0" encoding="UTF-8"?>\n<gupdate xmlns="http://www.google.com/update2/response" protocol="2.0">\n</gupdate>\n';
  }
  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<gupdate xmlns="http://www.google.com/update2/response" protocol="2.0">',
    ...items.flatMap((release) => [
      `  <app appid="${escapeXml(release.extensionId)}">`,
      `    <updatecheck codebase="${escapeXml(release.updateDownloadUrl || release.downloadUrl)}" version="${escapeXml(release.version)}" />`,
      '  </app>'
    ]),
    '</gupdate>',
    ''
  ].join('\n');
}

function isZipBuffer(buffer) {
  return buffer.length >= 4 && buffer[0] === 0x50 && buffer[1] === 0x4b;
}

function extensionIdFromCrxBuffer(buffer) {
  try {
    if (buffer.length < 16 || buffer.subarray(0, 4).toString('utf8') !== 'Cr24') return '';
    const version = buffer.readUInt32LE(4);
    if (version !== 3) return '';
    const headerSize = buffer.readUInt32LE(8);
    const header = buffer.subarray(12, 12 + headerSize);
    const publicKey = firstCrxPublicKey(header);
    if (!publicKey) return '';
    return extensionIdFromPublicKey(publicKey);
  } catch {
    return '';
  }
}

function firstCrxPublicKey(buffer) {
  let offset = 0;
  while (offset < buffer.length) {
    const key = readVarint(buffer, offset);
    if (!key) return null;
    offset = key.next;
    const field = Number(key.value >> 3n);
    const wire = Number(key.value & 7n);
    if (wire !== 2) return null;
    const length = readVarint(buffer, offset);
    if (!length) return null;
    offset = length.next;
    const end = offset + Number(length.value);
    if (end > buffer.length) return null;
    if (field === 2 || field === 3) {
      const nested = buffer.subarray(offset, end);
      const publicKey = publicKeyFromProof(nested);
      if (publicKey) return publicKey;
    }
    offset = end;
  }
  return null;
}

function publicKeyFromProof(buffer) {
  let offset = 0;
  while (offset < buffer.length) {
    const key = readVarint(buffer, offset);
    if (!key) return null;
    offset = key.next;
    const field = Number(key.value >> 3n);
    const wire = Number(key.value & 7n);
    if (wire !== 2) return null;
    const length = readVarint(buffer, offset);
    if (!length) return null;
    offset = length.next;
    const end = offset + Number(length.value);
    if (end > buffer.length) return null;
    if (field === 1) return buffer.subarray(offset, end);
    offset = end;
  }
  return null;
}

function readVarint(buffer, offset) {
  let value = 0n;
  let shift = 0n;
  for (let index = offset; index < buffer.length && index < offset + 10; index += 1) {
    const byte = BigInt(buffer[index]);
    value |= (byte & 0x7fn) << shift;
    if ((byte & 0x80n) === 0n) return { value, next: index + 1 };
    shift += 7n;
  }
  return null;
}

function extensionIdFromPublicKey(publicKey) {
  const digest = createHash('sha256').update(publicKey).digest();
  const alphabet = 'abcdefghijklmnop';
  return Array.from(digest.subarray(0, 16))
    .map((byte) => alphabet[byte >> 4] + alphabet[byte & 15])
    .join('');
}

async function recordSecurityEvent(req, body) {
  const nowMs = Date.now();
  const now = new Date(nowMs).toISOString();
  const event = {
    eventId: randomId('sec_', 8),
    eventType: clampText(body.eventType || body.type || 'license_security_event', 80),
    severity: clampText(body.severity || 'warning', 24),
    productId: clampText(body.productId || '', 80),
    extensionId: clampText(body.extensionId || '', 80),
    extensionVersion: clampText(body.extensionVersion || '', 40),
    buildId: clampText(body.buildId || body.packageBuildId || '', 120),
    releaseId: clampText(body.releaseId || '', 80),
    sourcePackage: clampText(body.sourcePackage || body.packageName || '', 180),
    packageSha256: clampText(body.packageSha256 || '', 80),
    machineId: clampText(body.machineId || '', 160),
    action: clampText(body.action || '', 80),
    code: clampText(body.code || '', 80),
    message: clampText(body.message || body.error || '', 600),
    warning: clampText(body.warning || '', 400),
    activationCodeSuffix: clampText(body.activationCodeSuffix || '', 20),
    userAgent: clampText(req.headers['user-agent'] || '', 300),
    ip: requestIp(req),
    createdAt: now
  };
  const fingerprint = securityEventFingerprint(event);

  const result = await store.mutate((db) => {
    const duplicate = Object.values(db.securityEvents || {}).find((item) => {
      if (securityEventFingerprint(item) !== fingerprint) return false;
      const createdAt = Date.parse(item.createdAt || '');
      return Number.isFinite(createdAt) && nowMs - createdAt < SECURITY_EVENT_DEDUPE_MS;
    });
    if (duplicate) {
      return { ok: true, eventId: duplicate.eventId, deduped: true };
    }
    db.securityEvents[event.eventId] = event;
    const events = Object.values(db.securityEvents)
      .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
    db.securityEvents = Object.fromEntries(events.slice(0, 1000).map((item) => [item.eventId, item]));
    appendAudit(db, 'security.event', {
      eventId: event.eventId,
      eventType: event.eventType,
      productId: event.productId,
      extensionId: event.extensionId,
      extensionVersion: event.extensionVersion,
      buildId: event.buildId,
      releaseId: event.releaseId,
      code: event.code
    });
    return { ok: true, eventId: event.eventId, deduped: false };
  });

  if (!result.deduped) await appendSecurityEventLog(event);
  return result;
}

async function appendSecurityEventLog(event) {
  const file = path.join(process.cwd(), 'logs', 'security-events.jsonl');
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.appendFile(file, `${JSON.stringify(event)}\n`, 'utf8');
}

function securityEventFingerprint(event) {
  return [
    event.eventType,
    event.productId,
    event.extensionId,
    event.extensionVersion,
    event.buildId,
    event.releaseId,
    event.machineId,
    event.action,
    event.code,
    event.activationCodeSuffix,
    event.ip
  ].map((value) => String(value || '')).join('|');
}

function clampText(value, maxLength) {
  return String(value ?? '').trim().slice(0, maxLength);
}

function requestIp(req) {
  return clampText(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '', 120);
}

async function createOrder(body) {
  const type = body.type === 'renew' ? 'renew' : 'purchase';
  const contact = requiredText(body.contact, 'contact');
  const planDays = Math.max(1, Number(body.days || body.planDays || 30));
  const order = {
    orderId: randomId('ord_', 8),
    type,
    status: 'pending',
    productId: type === 'purchase' ? normalizeProductId(config, body.productId) : config.productId,
    customerName: String(body.customerName || '').trim(),
    contact,
    planDays,
    maxDevices: Math.max(1, Number(body.maxDevices || 1)),
    maxProfilesPerDevice: Math.max(1, Number(body.maxProfilesPerDevice || config.defaultMaxProfilesPerDevice || 20)),
    activationCode: String(body.activationCode || '').trim().toUpperCase(),
    notes: String(body.notes || '').trim(),
    createdAt: nowIso(),
    updatedAt: nowIso()
  };
  if (type === 'purchase') requiredText(order.customerName, 'customerName');
  if (type === 'renew') requiredText(order.activationCode, 'activationCode');
  await store.mutate((db) => {
    if (type === 'renew') {
      const license = Object.values(db.licenses || {}).find((item) => item.activationCode === order.activationCode);
      if (license) {
        order.licenseId = license.licenseId;
        order.productId = license.productId || order.productId;
      }
    }
    db.orders[order.orderId] = order;
    appendAudit(db, 'order.created', {
      orderId: order.orderId,
      type: order.type,
      contact: order.contact,
      planDays: order.planDays
    });
  });
  return { ok: true, order };
}

async function approveOrder(body) {
  const orderId = requiredText(body.orderId, 'orderId');
  const order = (await store.read()).orders[orderId];
  if (!order) throw httpError(404, 'order_not_found', 'order not found');
  if (order.status !== 'pending') throw httpError(409, 'order_not_pending', 'order is not pending');
  let license;
  if (order.type === 'renew') {
    const result = await extendLicense(store, {
      licenseId: order.licenseId,
      activationCode: order.activationCode,
      days: order.planDays,
      reason: `order:${order.orderId}`
    });
    license = result.license;
  } else {
    license = await issueLicense(store, {
      customerName: order.customerName,
      contact: order.contact,
      days: order.planDays,
      maxDevices: order.maxDevices,
      maxProfilesPerDevice: order.maxProfilesPerDevice,
      notes: [order.notes, `order:${order.orderId}`].filter(Boolean).join('\n'),
      productId: order.productId || config.productId
    }, config);
  }
  const downloadCode = order.type === 'purchase'
    ? await issueDownloadCodeForLicense(license, { notes: `order:${order.orderId}` })
    : null;
  const updatedOrder = await store.mutate((db) => {
    const current = db.orders[orderId];
    current.status = 'fulfilled';
    current.licenseId = license.licenseId;
    current.activationCode = license.activationCode || current.activationCode;
    if (downloadCode) current.downloadCodeId = downloadCode.downloadCodeId;
    current.fulfilledAt = nowIso();
    current.updatedAt = nowIso();
    appendAudit(db, 'order.approved', {
      orderId,
      type: current.type,
      licenseId: license.licenseId,
      downloadCodeId: downloadCode?.downloadCodeId || ''
    });
    return current;
  });
  return { ok: true, order: updatedOrder, license, downloadCode };
}

async function cancelOrder(body) {
  const orderId = requiredText(body.orderId, 'orderId');
  return store.mutate((db) => {
    const order = db.orders[orderId];
    if (!order) throw httpError(404, 'order_not_found', 'order not found');
    order.status = 'cancelled';
    order.cancelReason = String(body.reason || 'manual').trim();
    order.updatedAt = nowIso();
    appendAudit(db, 'order.cancelled', { orderId, reason: order.cancelReason });
    return { ok: true, order };
  });
}

function safeFileName(value) {
  const cleaned = String(value)
    .normalize('NFKD')
    .replace(/[^\p{L}\p{N}._-]+/gu, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
  return cleaned || 'plugin.zip';
}

function publicBaseUrl() {
  return String(process.env.PUBLIC_BASE_URL || config.publicBaseUrl || 'https://xn--i2ru8q2qg.top').replace(/\/+$/, '');
}

function absolutePublicUrl(value) {
  return new URL(String(value || ''), `${publicBaseUrl()}/`).toString();
}

function isUpdaterKitPath(pathname) {
  if (pathname === '/updater-kit.zip') return true;
  try {
    return decodeURIComponent(pathname) === '/喵帕斯解压版更新小助手.zip';
  } catch {
    return false;
  }
}

function requiredText(value, field) {
  const text = String(value || '').trim();
  if (!text) throw httpError(400, `${field}_required`, `${field} is required`);
  return text;
}

function truthy(value) {
  if (value === true) return true;
  return ['1', 'true', 'on', 'yes'].includes(String(value || '').trim().toLowerCase());
}

function httpError(status, code, message) {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  return error;
}

function escapeXml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

async function buildAdminState() {
  const db = await store.read();
  const licenses = Object.values(db.licenses || {})
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
  const licenseById = new Map(licenses.map((license) => [license.licenseId, license]));
  const orders = Object.values(db.orders || {})
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
  const releases = await buildReleaseList();
  const downloadCodes = Object.values(db.downloadCodes || {})
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
    .slice(0, 500)
    .map((downloadCode) => adminDownloadCodeView(downloadCode, licenseById.get(downloadCode.licenseId)));
  const downloads = Object.values(db.downloads || {})
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
    .slice(0, 300)
    .map(adminDownloadView);
  const rawActivations = Object.values(db.activations || {})
    .sort((a, b) => String(b.lastSeenAt || b.createdAt || '').localeCompare(String(a.lastSeenAt || a.createdAt || '')));
  const deviceGroups = buildDeviceGroups(rawActivations, licenses);
  const licenseUsage = buildLicenseUsage(rawActivations);
  const activations = rawActivations
    .map((activation) => adminActivationView(activation))
    .sort((a, b) => String(b.lastSeenAt || b.createdAt || '').localeCompare(String(a.lastSeenAt || a.createdAt || '')));
  const securityEvents = Object.values(db.securityEvents || {})
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
    .slice(0, 200);
  const audit = (db.audit || []).slice(-80).reverse();
  const now = Date.now();
  const activeLicenses = licenses.filter((license) => license.status === 'active' && Date.parse(license.expiresAt || '') > now);
  const expiredLicenses = licenses.filter((license) => license.status === 'active' && Date.parse(license.expiresAt || '') <= now);
  const activeActivations = activations.filter((activation) => activation.status === 'active');
  const activeDevices = deviceGroups.filter((device) => device.status === 'active');
  const activeProfileCount = activeDevices.reduce((sum, device) => sum + Number(device.activeProfileCount || 0), 0);
  const activeDownloadCodes = downloadCodes.filter((downloadCode) => downloadCode.status === 'active');
  const licensesWithUsage = licenses.map((license) => ({
    ...license,
    maxProfilesPerDevice: maxProfilesPerDeviceForLicense(license, config),
    ...(licenseUsage.get(license.licenseId) || {
      deviceCount: 0,
      activeDeviceCount: 0,
      profileCount: 0,
      activeProfileCount: 0
    })
  }));
  return {
    ok: true,
    product: {
      productId: config.productId,
      productName: config.productName,
      minExtensionVersion: config.minExtensionVersion,
      tokenTtlSeconds: config.tokenTtlSeconds,
      offlineGraceSeconds: config.offlineGraceSeconds
    },
    products: listProducts(config, releases),
    summary: {
      licenseCount: licenses.length,
      activeLicenseCount: activeLicenses.length,
      expiredLicenseCount: expiredLicenses.length,
      activationCount: activations.length,
      activeActivationCount: activeActivations.length,
      deviceGroupCount: deviceGroups.length,
      activeDeviceGroupCount: activeDevices.length,
      activeProfileCount,
      revokedLicenseCount: licenses.filter((license) => license.status === 'revoked').length,
      bannedLicenseCount: licenses.filter((license) => license.status === 'banned').length,
      orderCount: orders.length,
      pendingOrderCount: orders.filter((order) => order.status === 'pending').length,
      downloadCodeCount: downloadCodes.length,
      activeDownloadCodeCount: activeDownloadCodes.length,
      downloadCount: downloads.length,
      releaseCount: releases.length,
      securityEventCount: securityEvents.length
    },
    licenses: licensesWithUsage,
    orders,
    releases,
    downloadCodes,
    downloads,
    devices: deviceGroups,
    activations,
    securityEvents,
    audit
  };
}

function buildDeviceGroups(activations, licenses) {
  const licenseById = new Map(licenses.map((license) => [license.licenseId, license]));
  const groups = new Map();
  for (const activation of activations || []) {
    const license = licenseById.get(activation.licenseId) || {};
    const deviceHash = activationDeviceKey(activation);
    const groupKey = `${activation.licenseId || ''}:${deviceHash}`;
    const group = groups.get(groupKey) || {
      deviceGroupId: groupKey,
      status: 'revoked',
      deviceLabel: shortHashLabel('设备', deviceHash),
      licenseId: activation.licenseId || '',
      productId: activation.productId || license.productId || '',
      customerId: activation.customerId || license.customerId || '',
      customerName: license.customerName || '',
      maxProfilesPerDevice: maxProfilesPerDeviceForLicense(license, config),
      activeProfileCount: 0,
      profileCount: 0,
      extensionVersions: [],
      firstSeenAt: activation.createdAt || '',
      lastSeenAt: activation.lastSeenAt || activation.createdAt || '',
      entries: []
    };
    const isActive = activation.status === 'active';
    group.status = isActive ? 'active' : group.status;
    group.profileCount += 1;
    if (isActive) group.activeProfileCount += 1;
    if (activation.extensionVersion && !group.extensionVersions.includes(activation.extensionVersion)) {
      group.extensionVersions.push(activation.extensionVersion);
    }
    if (String(activation.createdAt || '') < String(group.firstSeenAt || activation.createdAt || '')) {
      group.firstSeenAt = activation.createdAt || group.firstSeenAt;
    }
    if (String(activation.lastSeenAt || activation.createdAt || '') > String(group.lastSeenAt || '')) {
      group.lastSeenAt = activation.lastSeenAt || activation.createdAt || group.lastSeenAt;
    }
    group.entries.push({
      activationId: activation.activationId,
      profileLabel: activation.profileLabel || `入口 ${group.entries.length + 1}`,
      profileKey: shortHashLabel('入口', activationProfileKey(activation)),
      status: activation.status,
      extensionId: activation.extensionId || '',
      extensionVersion: activation.extensionVersion || '',
      createdAt: activation.createdAt || '',
      lastSeenAt: activation.lastSeenAt || activation.createdAt || ''
    });
    groups.set(groupKey, group);
  }
  return [...groups.values()]
    .map((group) => ({
      ...group,
      extensionVersions: group.extensionVersions.sort(),
      entries: group.entries.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
    }))
    .sort((a, b) => String(b.lastSeenAt || '').localeCompare(String(a.lastSeenAt || '')));
}

function buildLicenseUsage(activations) {
  const usage = new Map();
  for (const activation of activations || []) {
    const item = usage.get(activation.licenseId) || {
      deviceHashes: new Set(),
      activeDeviceHashes: new Set(),
      profileCount: 0,
      activeProfileCount: 0
    };
    const deviceHash = activationDeviceKey(activation);
    item.deviceHashes.add(deviceHash);
    item.profileCount += 1;
    if (activation.status === 'active') {
      item.activeDeviceHashes.add(deviceHash);
      item.activeProfileCount += 1;
    }
    usage.set(activation.licenseId, item);
  }
  return new Map([...usage.entries()].map(([licenseId, item]) => [licenseId, {
    deviceCount: item.deviceHashes.size,
    activeDeviceCount: item.activeDeviceHashes.size,
    profileCount: item.profileCount,
    activeProfileCount: item.activeProfileCount
  }]));
}

function adminActivationView(activation) {
  const { refreshTokenHash, machineHash, deviceHash, profileHash, ...view } = activation;
  return {
    ...view,
    deviceLabel: shortHashLabel('设备', activationDeviceKey(activation)),
    profileLabel: activation.profileLabel || '',
    profileKey: shortHashLabel('入口', activationProfileKey(activation))
  };
}

function activationDeviceKey(activation) {
  return activation?.deviceHash || activation?.machineHash || '';
}

function activationProfileKey(activation) {
  return activation?.profileHash || activation?.machineHash || activation?.activationId || '';
}

function shortHashLabel(prefix, hash) {
  const text = String(hash || '').replace(/[^A-Fa-f0-9]/g, '');
  return `${prefix}-${(text || '00000000').slice(0, 8).toUpperCase()}`;
}
