export function wantsHtml(req) {
  return String(req.headers.accept || '').includes('text/html');
}

export function renderPublicKey({ config, publicJwk }) {
  const body = JSON.stringify({ ok: true, publicJwk }, null, 2);
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>授权公钥</title></head><body><main><h1>授权公钥</h1><pre>${escapeHtml(body)}</pre><p><a href="/">返回首页</a></p></main></body></html>`;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}