import { listProducts } from './products.mjs';

export function renderPublicPortal({ config, release, releases = [] }) {
  const availableReleaseItems = (releases.length ? releases : [release]).filter((item) => item?.available);
  const products = listProducts(config, releases);
  const productOptionsHtml = renderProductOptions(products, release?.publicGroup || release?.productId || config.productId);
  const productSelectHtml = products.length > 1
    ? `<label>选择插件<select name="productId">${productOptionsHtml}</select></label>`
    : `<input type="hidden" name="productId" value="${escapeHtml(products[0]?.productId || config.productId || '')}">`;
  return page({
    title: '妙妙工具',
    active: 'store',
    body: `
      <section class="hero">
        <div>
          <p class="eyebrow">妙妙工具</p>
          <h1>妙妙工具</h1>
          <p class="lead">下载更新小助手、购买授权码、提交续费申请都在这里完成。站长发布新版后，小助手会自动领取、校验并更新插件。</p>
          <div class="actions">
            <a class="btn primary" href="/喵帕斯解压版更新小助手.zip?v=loadfolder-20260807">下载更新小助手</a>
            <a class="btn" href="#buy">购买授权码</a>
            <a class="btn" href="#renew">续费</a>
          </div>
        </div>
        <aside class="panel release">
          <p class="eyebrow">使用方式</p>
          <h2>用小助手安装和更新</h2>
          <dl>
            <div><dt>最新版本</dt><dd>${escapeHtml(release?.version || '待发布')}</dd></div>
            <div><dt>可用插件</dt><dd>${escapeHtml(String(availableReleaseItems.length || 0))} 个</dd></div>
            <div><dt>安装目录</dt><dd>Flow 选【把这个放进去】；即梦双击启动器</dd></div>
            <div><dt>更新方式</dt><dd>再次运行小助手</dd></div>
          </dl>
        </aside>
      </section>

      <section class="split">
        <form class="panel form" id="buy" data-order-form>
          <p class="eyebrow">购买授权</p>
          <h2>购买授权码</h2>
          <input type="hidden" name="type" value="purchase">
          ${productSelectHtml}
          <label>客户名<input name="customerName" required placeholder="例如：张三 / 某某公司"></label>
          <label>联系方式<input name="contact" required placeholder="微信 / 手机 / 邮箱"></label>
          <div class="two">
            <label>授权天数<select name="days"><option value="30">30 天</option><option value="90">90 天</option><option value="365">365 天</option></select></label>
            <label>设备数<input name="maxDevices" type="number" min="1" value="1" required></label>
          </div>
          <label>备注<textarea name="notes" placeholder="订单号、付款截图说明、需要绑定的客户信息"></textarea></label>
          <button class="btn primary" type="submit">提交购买订单</button>
          <div class="result" data-result></div>
        </form>

        <form class="panel form" id="renew" data-order-form>
          <p class="eyebrow">授权续费</p>
          <h2>授权续费</h2>
          <input type="hidden" name="type" value="renew">
          <label>授权码<input name="activationCode" required placeholder="MM-XXXXX-XXXXX-XXXXX-XXXXX"></label>
          <label>联系方式<input name="contact" required placeholder="微信 / 手机 / 邮箱"></label>
          <div class="two">
            <label>续费天数<select name="days"><option value="30">30 天</option><option value="90">90 天</option><option value="365">365 天</option></select></label>
            <label>客户名<input name="customerName" placeholder="可选"></label>
          </div>
          <label>备注<textarea name="notes" placeholder="付款信息或续费说明"></textarea></label>
          <button class="btn primary" type="submit">提交续费申请</button>
          <div class="result" data-result></div>
        </form>
      </section>

      <section class="panel steps">
        <article><span>01</span><h3>下载小助手</h3><p>下载并解压更新小助手，双击对应插件的更新脚本。</p></article>
        <article><span>02</span><h3>输入下载码</h3><p>输入 DL 开头的下载码，小助手会自动下载、校验并放好插件。</p></article>
        <article><span>03</span><h3>启动插件</h3><p>Flow 在扩展管理页选择【把这个放进去】；即梦打开【双击打开这个文件夹】，双击【启动即梦独立窗口.cmd】，不要拖进扩展页。</p></article>
        <article><span>04</span><h3>输入授权码</h3><p>在插件侧边栏输入 MM 开头的授权码。后续更新只需要再次运行小助手。</p></article>
      </section>

      <script>
        const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        document.querySelectorAll('[data-order-form]').forEach(form => {
          form.addEventListener('submit', async event => {
            event.preventDefault();
            const result = form.querySelector('[data-result]');
            const body = Object.fromEntries(new FormData(form).entries());
            body.days = Number(body.days || 30);
            body.maxDevices = Number(body.maxDevices || 1);
            result.textContent = '提交中...';
            try {
              const res = await fetch('/api/v1/orders', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
              });
              const data = await res.json();
              if (!res.ok || data.ok === false) throw new Error(data.error || data.code || '提交失败');
              result.innerHTML = '已提交，订单号：<strong>' + h(data.order.orderId) + '</strong><br>后台确认后会处理授权。';
              form.reset();
            } catch (error) {
              result.textContent = '提交失败：' + error.message;
            }
          });
        });
      </script>`
  });
}

function renderProductOptions(products, selectedProductId = '') {
  return products.map((product) => {
    const selected = product.productId === selectedProductId ? ' selected' : '';
    const label = product.minExtensionVersion
      ? `${product.name}（最低 ${product.minExtensionVersion}）`
      : product.name;
    return `<option value="${escapeHtml(product.productId)}"${selected}>${escapeHtml(label)}</option>`;
  }).join('');
}

function page({ title, active, body }) {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>
    :root{--bg:#050606;--fg:#fff;--muted:#b7b7b7;--line:#3d4140;--soft:rgba(255,255,255,.06);--card:rgba(0,0,0,.6);--accent:#3b3f6a;--bad:#ff9b9b;--ok:#b9ffd9;--sans:"Inter","Segoe UI",Arial,sans-serif;--serif:"Times New Roman",Georgia,serif}
    *{box-sizing:border-box}
    html,body{margin:0;min-height:100%;background:#000;color:var(--fg);font-family:var(--sans);overflow-x:hidden}
    body::before{content:"";position:fixed;inset:0;background:radial-gradient(circle at 50% 18%,rgba(90,99,160,.34),transparent 24rem),radial-gradient(circle at 8% 5%,rgba(55,130,111,.22),transparent 20rem),#000;z-index:-2}
    body::after{content:"";position:fixed;inset:0;background-image:radial-gradient(rgba(210,214,255,.7) 1px,transparent 1px);background-size:96px 96px;opacity:.32;z-index:-1}
    .shell{min-height:100vh;padding:28px clamp(16px,4vw,56px) 42px}
    header{display:flex;justify-content:space-between;align-items:center;gap:18px;max-width:1180px;margin:0 auto}
    .brand{display:flex;gap:12px;align-items:center;color:#fff;text-decoration:none}.mark{width:36px;height:36px;border:1px solid #fff;border-radius:50%;display:grid;place-items:center}.mark::before{content:"";width:12px;height:12px;border:1px solid #fff;transform:rotate(45deg)}.brand strong{display:block;font-size:14px}.brand span span{font-size:10px;color:var(--muted)}
    nav{display:flex;gap:8px;flex-wrap:wrap}nav a{color:#fff;text-decoration:none;border:1px solid rgba(255,255,255,.55);border-radius:6px;padding:5px 10px;font-size:12px;background:rgba(0,0,0,.24)}nav a.active{background:rgba(255,255,255,.12)}
    main{width:100%;max-width:1180px;margin:0 auto;padding-top:84px}.hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(280px,380px);gap:18px;align-items:stretch}.hero h1,.login h1,.owner h1{font-family:var(--serif);font-size:clamp(52px,8vw,112px);line-height:.92;font-weight:400;margin:0 0 20px;letter-spacing:0}.lead{font-family:var(--serif);font-size:18px;line-height:1.9;color:#eee;max-width:680px}.eyebrow{margin:0 0 14px;color:var(--muted);font-size:10px;text-transform:uppercase;letter-spacing:.08em}
    .panel{border:1px solid var(--line);border-radius:12px;background:var(--card);backdrop-filter:blur(5px);padding:24px;min-width:0}.release h2,.form h2,.table-head h2{font-size:20px;margin:0 0 16px}.release dl{display:grid;gap:14px;margin:0}.release dl div{border-bottom:1px solid rgba(255,255,255,.12);padding-bottom:12px}.release dl div:last-child{border:0;padding:0}dt{font-size:10px;color:var(--muted);text-transform:uppercase}dd{margin:5px 0 0;word-break:break-word}.mono{font-family:Consolas,"SFMono-Regular",monospace;overflow-wrap:anywhere}
    .actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:28px}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:34px;border:1px solid rgba(255,255,255,.62);border-radius:999px;padding:7px 18px;background:rgba(0,0,0,.32);color:#fff;text-decoration:none;font-weight:700;font-size:14px;cursor:pointer}.btn.primary{background:var(--accent);border-color:var(--accent)}.btn.danger,.danger{border-color:rgba(255,120,120,.62);color:#ffd5d5}.btn.mini{min-height:28px;padding:4px 10px;font-size:12px}
    .split{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:16px}.form{display:grid;gap:12px}.form label{display:grid;gap:6px;color:var(--muted);font-size:11px;text-transform:uppercase}.form-note{margin:0;color:var(--muted);font-size:13px;line-height:1.7}.form .check{display:flex;align-items:center;gap:8px;text-transform:none;color:#eee}.form .check input{width:16px;min-height:16px;padding:0}.two{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}input,select,textarea{width:100%;min-height:40px;border:1px solid rgba(255,255,255,.24);border-radius:7px;background:rgba(255,255,255,.08);color:#fff;padding:9px 11px;font:14px/1.4 var(--sans);outline:none}textarea{min-height:88px;resize:vertical}option{background:#111}.result-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:stretch}.result-row .btn{min-height:42px;white-space:nowrap}.result{min-height:42px;border:1px solid rgba(255,255,255,.14);border-radius:8px;background:rgba(255,255,255,.05);padding:12px;color:#eee;font-size:13px;line-height:1.6;white-space:pre-wrap}
    .steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-top:16px}.steps article{padding:8px}.steps span{display:block;color:var(--muted);font-size:10px;margin-bottom:32px}.steps h3{margin:0 0 10px}.steps p{font-family:var(--serif);font-size:16px;line-height:1.75;color:#eee;margin:0}
    .release-list{margin-top:16px}.section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;margin-bottom:12px}.section-head h2{margin:0;font-size:24px}.release-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px}.release-item{display:grid;gap:14px}.release-item h3{margin:0;font-size:17px;line-height:1.35}.release-item dl{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:0}.release-item dl div{border-top:1px solid rgba(255,255,255,.12);padding-top:10px}.release-item .btn{width:100%}
    .download-gate{display:grid;grid-template-columns:minmax(0,1fr) minmax(260px,380px);gap:18px;align-items:end;margin-bottom:12px}.download-gate h3{margin:0 0 8px;font-size:20px}.download-gate p{margin:0}.download-code-row{display:grid;gap:8px}
    .login{max-width:620px;margin:0 auto}.owner-head{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:12px}.stat{padding:18px}.stat span{display:block;color:var(--muted);font-size:10px;text-transform:uppercase;margin-bottom:8px}.stat strong{font-size:28px;font-weight:400}
.batch-summary{display:flex;gap:18px;flex-wrap:wrap;font-size:12px}.tag.pending{color:#ffe3a3;border-color:rgba(255,210,90,.42)}
    .table-card{padding:0;margin-top:16px;overflow:hidden}.table-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.12)}.table-head-actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.table-wrap{overflow:auto}.table-card.collapsed .table-wrap,.table-card.collapsed .license-tools{display:none}.table-card.collapsed .table-head{border-bottom:0}.license-tools{display:flex;gap:8px;flex-wrap:wrap;padding:12px 20px;border-bottom:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03)}.license-filter.active{background:rgba(255,255,255,.14);border-color:rgba(255,255,255,.85)}.license-filter span{margin-left:6px;color:var(--muted)}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid rgba(255,255,255,.1);padding:12px 14px;text-align:left;font-size:12px;vertical-align:top}th{color:var(--muted);font-weight:400;text-transform:uppercase}tr:last-child td{border-bottom:0}.tag{display:inline-flex;border:1px solid rgba(255,255,255,.24);border-radius:999px;padding:3px 8px}.tag.active,.tag.fulfilled,.tag.issued,.tag.downloaded{color:var(--ok);border-color:rgba(146,255,205,.35)}.tag.expired{color:#ffe3a3;border-color:rgba(255,210,90,.42)}.tag.revoked,.tag.banned,.tag.cancelled{color:#ffc4c4;border-color:rgba(255,120,120,.38)}.row-actions{display:flex;flex-wrap:wrap;gap:6px}.profile-list{display:grid;gap:6px}.profile-entry{display:grid;gap:2px;padding:6px 8px;border:1px solid rgba(255,255,255,.1);border-radius:8px;background:rgba(255,255,255,.035)}.profile-entry span{color:var(--muted)}.muted{color:var(--muted)}
    footer{max-width:1180px;margin:40px auto 0;color:var(--muted);font-size:10px;display:flex;justify-content:space-between;gap:16px}
    @media(max-width:900px){.shell{padding:20px 16px 32px}header{align-items:flex-start;flex-direction:column}main{padding-top:42px}.hero,.split,.steps,.two,.result-row,.download-gate{grid-template-columns:minmax(0,1fr)}.hero h1,.login h1,.owner h1{font-size:46px}.actions{display:grid}.section-head{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.table-card{overflow:auto}table{min-width:900px}footer{flex-direction:column}}
  </style>
</head>
<body>
  <div class="shell">
    <header>
      <a class="brand" href="/"><span class="mark" aria-hidden="true"></span><span><strong>妙妙工具</strong><span>授权网关</span></span></a>
      <nav>
        <a class="${active === 'store' ? 'active' : ''}" href="/">公开页</a>
        
      </nav>
    </header>
    <main>${body}</main>
    <footer><span>喵帕斯.top</span><span>授权私钥只保存在服务端</span></footer>
  </div>
</body>
</html>`;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}